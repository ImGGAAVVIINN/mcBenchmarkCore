package net.minecraft.commands.arguments;

import com.google.gson.JsonObject;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.Dynamic3CommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.mojang.datafixers.util.Either;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.synchronization.ArgumentTypeInfo;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;

public class ResourceOrTagArgument<T> implements ArgumentType<ResourceOrTagArgument.Result<T>> {
	private static final Collection<String> EXAMPLES = Arrays.asList("foo", "foo:bar", "012", "#skeletons", "#minecraft:skeletons");
	private static final Dynamic2CommandExceptionType ERROR_UNKNOWN_TAG = new Dynamic2CommandExceptionType(
		(object, object2) -> Component.translatableEscape("argument.resource_tag.not_found", object, object2)
	);
	private static final Dynamic3CommandExceptionType ERROR_INVALID_TAG_TYPE = new Dynamic3CommandExceptionType(
		(object, object2, object3) -> Component.translatableEscape("argument.resource_tag.invalid_type", object, object2, object3)
	);
	private final HolderLookup<T> registryLookup;
	final ResourceKey<? extends Registry<T>> registryKey;

	public ResourceOrTagArgument(CommandBuildContext commandBuildContext, ResourceKey<? extends Registry<T>> resourceKey) {
		this.registryKey = resourceKey;
		this.registryLookup = commandBuildContext.lookupOrThrow(resourceKey);
	}

	public static <T> ResourceOrTagArgument<T> resourceOrTag(CommandBuildContext commandBuildContext, ResourceKey<? extends Registry<T>> resourceKey) {
		return new ResourceOrTagArgument<>(commandBuildContext, resourceKey);
	}

	public static <T> ResourceOrTagArgument.Result<T> getResourceOrTag(
		CommandContext<CommandSourceStack> commandContext, String string, ResourceKey<Registry<T>> resourceKey
	) throws CommandSyntaxException {
		ResourceOrTagArgument.Result<?> result = commandContext.getArgument(string, ResourceOrTagArgument.Result.class);
		Optional<ResourceOrTagArgument.Result<T>> optional = result.cast(resourceKey);
		return optional.orElseThrow(() -> result.unwrap().map(reference -> {
			ResourceKey<?> resourceKey2 = reference.key();
			return ResourceArgument.ERROR_INVALID_RESOURCE_TYPE.create(resourceKey2.identifier(), resourceKey2.registry(), resourceKey.identifier());
		}, named -> {
			TagKey<?> tagKey = named.key();
			return ERROR_INVALID_TAG_TYPE.create(tagKey.location(), tagKey.registry(), resourceKey.identifier());
		}));
	}

	public ResourceOrTagArgument.Result<T> parse(StringReader stringReader) throws CommandSyntaxException {
		if (stringReader.canRead() && stringReader.peek() == '#') {
			int i = stringReader.getCursor();

			try {
				stringReader.skip();
				Identifier identifier = Identifier.read(stringReader);
				TagKey<T> tagKey = TagKey.create(this.registryKey, identifier);
				HolderSet.Named<T> named = this.registryLookup
					.get(tagKey)
					.orElseThrow(() -> ERROR_UNKNOWN_TAG.createWithContext(stringReader, identifier, this.registryKey.identifier()));
				return new ResourceOrTagArgument.TagResult<>(named);
			} catch (CommandSyntaxException commandSyntaxException) {
				stringReader.setCursor(i);
				throw commandSyntaxException;
			}
		} else {
			Identifier identifier2 = Identifier.read(stringReader);
			ResourceKey<T> resourceKey = ResourceKey.create(this.registryKey, identifier2);
			Holder.Reference<T> reference = this.registryLookup
				.get(resourceKey)
				.orElseThrow(() -> ResourceArgument.ERROR_UNKNOWN_RESOURCE.createWithContext(stringReader, identifier2, this.registryKey.identifier()));
			return new ResourceOrTagArgument.ResourceResult<>(reference);
		}
	}

	@Override
	public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
		return SharedSuggestionProvider.listSuggestions(commandContext, suggestionsBuilder, this.registryKey, SharedSuggestionProvider.ElementSuggestionType.ALL);
	}

	@Override
	public Collection<String> getExamples() {
		return EXAMPLES;
	}

	public static class Info<T> implements ArgumentTypeInfo<ResourceOrTagArgument<T>, ResourceOrTagArgument.Info<T>.Template> {
		public void serializeToNetwork(ResourceOrTagArgument.Info<T>.Template template, FriendlyByteBuf friendlyByteBuf) {
			friendlyByteBuf.writeResourceKey(template.registryKey);
		}

		public ResourceOrTagArgument.Info<T>.Template deserializeFromNetwork(FriendlyByteBuf friendlyByteBuf) {
			return new ResourceOrTagArgument.Info.Template(friendlyByteBuf.readRegistryKey());
		}

		public void serializeToJson(ResourceOrTagArgument.Info<T>.Template template, JsonObject jsonObject) {
			jsonObject.addProperty("registry", template.registryKey.identifier().toString());
		}

		public ResourceOrTagArgument.Info<T>.Template unpack(ResourceOrTagArgument<T> resourceOrTagArgument) {
			return new ResourceOrTagArgument.Info.Template(resourceOrTagArgument.registryKey);
		}

		public final class Template implements ArgumentTypeInfo.Template<ResourceOrTagArgument<T>> {
			final ResourceKey<? extends Registry<T>> registryKey;

			Template(final ResourceKey<? extends Registry<T>> resourceKey) {
				this.registryKey = resourceKey;
			}

			public ResourceOrTagArgument<T> instantiate(CommandBuildContext commandBuildContext) {
				return new ResourceOrTagArgument<>(commandBuildContext, this.registryKey);
			}

			@Override
			public ArgumentTypeInfo<ResourceOrTagArgument<T>, ?> type() {
				return Info.this;
			}
		}
	}

	record ResourceResult<T>(Holder.Reference<T> value) implements ResourceOrTagArgument.Result<T> {
		@Override
		public Either<Holder.Reference<T>, HolderSet.Named<T>> unwrap() {
			return Either.left(this.value);
		}

		@Override
		public <E> Optional<ResourceOrTagArgument.Result<E>> cast(ResourceKey<? extends Registry<E>> resourceKey) {
			return this.value.key().isFor(resourceKey) ? Optional.of((ResourceOrTagArgument.Result<E>)this) : Optional.empty();
		}

		public boolean test(Holder<T> holder) {
			return holder.equals(this.value);
		}

		@Override
		public String asPrintable() {
			return this.value.key().identifier().toString();
		}
	}

	public interface Result<T> extends Predicate<Holder<T>> {
		Either<Holder.Reference<T>, HolderSet.Named<T>> unwrap();

		<E> Optional<ResourceOrTagArgument.Result<E>> cast(ResourceKey<? extends Registry<E>> resourceKey);

		String asPrintable();
	}

	record TagResult<T>(HolderSet.Named<T> tag) implements ResourceOrTagArgument.Result<T> {
		@Override
		public Either<Holder.Reference<T>, HolderSet.Named<T>> unwrap() {
			return Either.right(this.tag);
		}

		@Override
		public <E> Optional<ResourceOrTagArgument.Result<E>> cast(ResourceKey<? extends Registry<E>> resourceKey) {
			return this.tag.key().isFor(resourceKey) ? Optional.of((ResourceOrTagArgument.Result<E>)this) : Optional.empty();
		}

		public boolean test(Holder<T> holder) {
			return this.tag.contains(holder);
		}

		@Override
		public String asPrintable() {
			return "#" + this.tag.key().location();
		}
	}
}
