package net.minecraft.core;

import com.mojang.datafixers.util.Either;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import org.jspecify.annotations.Nullable;

public interface Holder<T> {
	T value();

	boolean isBound();

	boolean is(Identifier identifier);

	boolean is(ResourceKey<T> resourceKey);

	boolean is(Predicate<ResourceKey<T>> predicate);

	boolean is(TagKey<T> tagKey);

	@Deprecated
	boolean is(Holder<T> holder);

	Stream<TagKey<T>> tags();

	Either<ResourceKey<T>, T> unwrap();

	Optional<ResourceKey<T>> unwrapKey();

	Holder.Kind kind();

	boolean canSerializeIn(HolderOwner<T> holderOwner);

	default String getRegisteredName() {
		return this.unwrapKey().map(resourceKey -> resourceKey.identifier().toString()).orElse("[unregistered]");
	}

	static <T> Holder<T> direct(T object) {
		return new Holder.Direct<>(object);
	}

	record Direct<T>(T value) implements Holder<T> {
		@Override
		public boolean isBound() {
			return true;
		}

		@Override
		public boolean is(Identifier identifier) {
			return false;
		}

		@Override
		public boolean is(ResourceKey<T> resourceKey) {
			return false;
		}

		@Override
		public boolean is(TagKey<T> tagKey) {
			return false;
		}

		@Override
		public boolean is(Holder<T> holder) {
			return this.value.equals(holder.value());
		}

		@Override
		public boolean is(Predicate<ResourceKey<T>> predicate) {
			return false;
		}

		@Override
		public Either<ResourceKey<T>, T> unwrap() {
			return Either.right(this.value);
		}

		@Override
		public Optional<ResourceKey<T>> unwrapKey() {
			return Optional.empty();
		}

		@Override
		public Holder.Kind kind() {
			return Holder.Kind.DIRECT;
		}

		@Override
		public String toString() {
			return "Direct{" + this.value + "}";
		}

		@Override
		public boolean canSerializeIn(HolderOwner<T> holderOwner) {
			return true;
		}

		@Override
		public Stream<TagKey<T>> tags() {
			return Stream.of();
		}
	}

	enum Kind {
		REFERENCE,
		DIRECT;
	}

	class Reference<T> implements Holder<T> {
		private final HolderOwner<T> owner;
		private @Nullable Set<TagKey<T>> tags;
		private final Holder.Reference.Type type;
		private @Nullable ResourceKey<T> key;
		private @Nullable T value;

		protected Reference(Holder.Reference.Type type, HolderOwner<T> holderOwner, @Nullable ResourceKey<T> resourceKey, @Nullable T object) {
			this.owner = holderOwner;
			this.type = type;
			this.key = resourceKey;
			this.value = object;
		}

		public static <T> Holder.Reference<T> createStandAlone(HolderOwner<T> holderOwner, ResourceKey<T> resourceKey) {
			return new Holder.Reference<>(Holder.Reference.Type.STAND_ALONE, holderOwner, resourceKey, null);
		}

		@Deprecated
		public static <T> Holder.Reference<T> createIntrusive(HolderOwner<T> holderOwner, @Nullable T object) {
			return new Holder.Reference<>(Holder.Reference.Type.INTRUSIVE, holderOwner, null, object);
		}

		public ResourceKey<T> key() {
			if (this.key == null) {
				throw new IllegalStateException("Trying to access unbound value '" + this.value + "' from registry " + this.owner);
			} else {
				return this.key;
			}
		}

		@Override
		public T value() {
			if (this.value == null) {
				throw new IllegalStateException("Trying to access unbound value '" + this.key + "' from registry " + this.owner);
			} else {
				return this.value;
			}
		}

		@Override
		public boolean is(Identifier identifier) {
			return this.key().identifier().equals(identifier);
		}

		@Override
		public boolean is(ResourceKey<T> resourceKey) {
			return this.key() == resourceKey;
		}

		private Set<TagKey<T>> boundTags() {
			if (this.tags == null) {
				throw new IllegalStateException("Tags not bound");
			} else {
				return this.tags;
			}
		}

		@Override
		public boolean is(TagKey<T> tagKey) {
			return this.boundTags().contains(tagKey);
		}

		@Override
		public boolean is(Holder<T> holder) {
			return holder.is(this.key());
		}

		@Override
		public boolean is(Predicate<ResourceKey<T>> predicate) {
			return predicate.test(this.key());
		}

		@Override
		public boolean canSerializeIn(HolderOwner<T> holderOwner) {
			return this.owner.canSerializeIn(holderOwner);
		}

		@Override
		public Either<ResourceKey<T>, T> unwrap() {
			return Either.left(this.key());
		}

		@Override
		public Optional<ResourceKey<T>> unwrapKey() {
			return Optional.of(this.key());
		}

		@Override
		public Holder.Kind kind() {
			return Holder.Kind.REFERENCE;
		}

		@Override
		public boolean isBound() {
			return this.key != null && this.value != null;
		}

		void bindKey(ResourceKey<T> resourceKey) {
			if (this.key != null && resourceKey != this.key) {
				throw new IllegalStateException("Can't change holder key: existing=" + this.key + ", new=" + resourceKey);
			}

			this.key = resourceKey;
		}

		protected void bindValue(T object) {
			if (this.type == Holder.Reference.Type.INTRUSIVE && this.value != object) {
				throw new IllegalStateException("Can't change holder " + this.key + " value: existing=" + this.value + ", new=" + object);
			}

			this.value = object;
		}

		void bindTags(Collection<TagKey<T>> collection) {
			this.tags = Set.copyOf(collection);
		}

		@Override
		public Stream<TagKey<T>> tags() {
			return this.boundTags().stream();
		}

		@Override
		public String toString() {
			return "Reference{" + this.key + "=" + this.value + "}";
		}

		protected enum Type {
			STAND_ALONE,
			INTRUSIVE;
		}
	}
}
