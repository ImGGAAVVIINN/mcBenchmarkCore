#version 330 compatibility

#include "/programs/deferred/Deferred15.frag"
