#version 330 compatibility

#include "/programs/deferred/Deferred7.frag"
