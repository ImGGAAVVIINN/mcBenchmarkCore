vec3 reflectionWeight(vec3 viewDir, vec3 lightDir, vec3 f0, vec3 f82) {
    float LdotH2 = clamp(dot(-viewDir, lightDir) * 0.5 + 0.5, 0.0, 1.0);
    if (f0.x < 0.0) {
        f0 = vec3(0.02);
        LdotH2 = clamp(1.777777 * LdotH2 - 0.777777, 0.0, 1.0);
    }
    vec3 F = F_AdobeF82(f0, f82, sqrt(LdotH2));
    return F;
}

// https://www.shadertoy.com/view/MX3XDf MIT Licence
// Did some trick to prevent NaN when normal is vec3(0.0, 0.0, -1.0)
vec3 IsotropicGGX(vec2 u, vec3 wi, float alpha, vec3 n, float NdotV, out float pdfRatio)
{
    //preliminary variables
    float a2 = alpha * alpha;
    float z2 = NdotV * NdotV;
    // warp to the hemisphere configuration
    vec3 wiStd = mix(wi, NdotV * n, vec3(1.0 + alpha));
    float t = inversesqrt((1.0 - z2) * a2 + z2);
    wiStd *= t;
    NdotV *= t;
    //compute lower bound for scaling
    float s = 1. + sqrt(1.0 - z2);
    float s2 = s * s;
    float k = (s2 - a2 * s2) / (s2 + a2 * z2);
    //calculate ratio of bounded and unbounded vndf
    pdfRatio = (k * NdotV + 1.0) / (NdotV + 1.0);
    //construct spherical cap
    vec3 cStd;
    float b = k * dot(wiStd, n); //z axis
    float inversed = signI(n.z);
    cStd.z = (1.0 - u.y - u.y * b) * inversed;
    const float tau = 6.2831853; // 2 * pi
    float phi = tau * u.x;
    cStd.x = cos(phi);
    cStd.y = sin(phi);
    cStd.xy *= sqrt(clamp(1. - cStd.z * cStd.z, 0.0, 1.0));
    //reflect sample to align with normal
    vec3 wr = vec3(n.xy, n.z + inversed);
    vec3 c = (dot(wr, cStd) / abs(wr.z)) * wr - cStd;
    // compute halfway direction as standard normal
    vec3 wmStd = c + wiStd;
    vec3 wmStd_z = n * dot(n, wmStd);
    vec3 wmStd_xy = wmStd_z - wmStd;
    // warp back to the ellipsoid configuration
    return normalize(wmStd_z + alpha * wmStd_xy);
}

vec3 directionDistribution(vec2 noise, vec3 normal, vec3 viewDir, float roughness, float NdotV, out float pdfRatio) {
    vec3 direction;
    #ifdef FULL_REFLECTION
        vec3 distributedNormal = IsotropicGGX(noise, -viewDir, roughness, normal, NdotV, pdfRatio);
        direction = reflect(viewDir, distributedNormal);
    #else
        vec3 rayDir = reflect(viewDir, normal);
        float distributionAngle = 2 * PI * noise.x;
        vec3 distributionDir1 = normalize(cross(rayDir, viewDir));
        vec3 distributionDir2 = sin(distributionAngle) * cross(rayDir, distributionDir1);
        vec3 distributionDir = cos(distributionAngle) * distributionDir1 + distributionDir2 * NdotV;
        float distributionStrength = noise.y * roughness;
        direction = normalize(distributionDir * distributionStrength + rayDir);
        pdfRatio = 1.0;
    #endif
    return direction;
}

#ifdef MC_NORMAL_MAP
    vec3 calculateReflectionNormal(
        sampler2D normalSampler, vec2 coord, vec4 normalData, mat3 tbnMatrix, vec2 normalTexSize, vec2 atlasTiles,
        float textureResolution, vec3 geoNormal, vec3 rayDir, float lod
    ) {
        vec2 normalTexelSize = 1.0 / normalTexSize;
        vec2 baseCoord = floor(coord * atlasTiles) / atlasTiles;
        vec4 coordRange = vec4(baseCoord, vec2(textureResolution) * normalTexelSize);
        vec2 quadSize = 1.0 / coordRange.zw;
        vec2 quadTexelSize = normalTexelSize * quadSize;

        vec3 normal;
        #if defined PARALLAX_BASED_NORMAL && defined PARALLAX && defined SMOOTH_PARALLAX && !defined VOXEL_PARALLAX
            normalData.w = bilinearHeightSample(normalSampler, (coord - coordRange.xy) * quadSize, coordRange, quadTexelSize, normalTexSize);
            if (normalData.w < 1.0) {
                vec3 parallaxNormal = heightBasedNormal(normalSampler, coord, coordRange, quadTexelSize, normalTexSize, vec2(1.0 / textureResolution));
                normal = normalize(tbnMatrix * parallaxNormal);
            }
            else
        #endif
        {
            #ifdef SMOOTH_NORMAL
                normalData = bilinearNormalSample(normalSampler, coord, coordRange, quadTexelSize, normalTexSize);
            #endif
            normalData.xyz = NORMAL_FORMAT(normalData.xyz);
            normalData.xy *= NORMAL_STRENGTH;
            normal = normalize(tbnMatrix * normalData.xyz);
            float NdotV = dot(normal, -rayDir);
            vec3 edgeNormal = normal + rayDir * NdotV;
            float curveStart = dot(-rayDir, geoNormal);
            float weight = clamp(curveStart - curveStart * exp(NdotV / curveStart - 1.0), 0.0, 1.0);
            weight = max(NdotV, curveStart) - weight;
            normal = -rayDir * weight + edgeNormal * max(0.0, inversesqrt(dot(edgeNormal, edgeNormal) / (1.0 - weight * weight)));
        }
        return normal;
    }
#endif

vec3 getIrradianceCacheSmoothed(vec3 voxelPos, vec3 targetNormal, vec3 targetTexNormal, vec3 skyColorUp, float skyLight) {
    voxelPos += targetNormal * 0.01;
    vec3 voxelIndex = floor(voxelPos);
    voxelPos = voxelPos - voxelIndex;
    voxelIndex.y += voxelOriginY;
    vec3 irCachePos = voxelIndex - voxelizationRadius;
    vec3 result = clamp(skyLight * 1.5, 0.0, 1.0) * skyColorUp * (targetNormal.y * 0.5 + 0.5);
    if (all(lessThan(abs(irCachePos + 0.5), vec3(irCacheRadius - 1.0)))) {
        vec3 absNormal = abs(targetNormal);
        vec3 surfaceNormal = step(vec3(max(absNormal.x, max(absNormal.y, absNormal.z))), absNormal);
        vec3 sampleOffsetX = vec3(1.0 - surfaceNormal.x, surfaceNormal.x, 0.0),
            sampleOffsetY = vec3(0.0, surfaceNormal.z, 1.0 - surfaceNormal.z),
            samplePosition = (0.5 - voxelPos) * (sampleOffsetX + sampleOffsetY);
        irCachePos += irCacheRadius;

        vec3 totalIrCacheColor = vec3(0.0);
        float totalWeight = 0.0;

        vec4 sampleIrCacheColor = sampleIrradianceCache(irCachePos, targetTexNormal);
        float sampleWeight = sampleIrCacheColor.w * clamp(1.0 - length(samplePosition) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor.rgb * sampleWeight;
        totalWeight += sampleWeight;
        vec4 sampleIrCacheColor0X = sampleIrradianceCache(irCachePos - sampleOffsetX, targetTexNormal);
        float sampleWeight0X = sampleIrCacheColor0X.w * clamp(1.0 - length(samplePosition - sampleOffsetX) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor0X.rgb * sampleWeight0X;
        totalWeight += sampleWeight0X;
        vec4 sampleIrCacheColor1X = sampleIrradianceCache(irCachePos + sampleOffsetX, targetTexNormal);
        float sampleWeight1X = sampleIrCacheColor1X.w * clamp(1.0 - length(samplePosition + sampleOffsetX) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor1X.rgb * sampleWeight1X;
        totalWeight += sampleWeight1X;
        vec4 sampleIrCacheColor0Y = sampleIrradianceCache(irCachePos - sampleOffsetY, targetTexNormal);
        float sampleWeight0Y = sampleIrCacheColor0Y.w * clamp(1.0 - length(samplePosition - sampleOffsetY) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor0Y.rgb * sampleWeight0Y;
        totalWeight += sampleWeight0Y;
        vec4 sampleIrCacheColor1Y = sampleIrradianceCache(irCachePos + sampleOffsetY, targetTexNormal);
        float sampleWeight1Y = sampleIrCacheColor1Y.w * clamp(1.0 - length(samplePosition + sampleOffsetY) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor1Y.rgb * sampleWeight1Y;
        totalWeight += sampleWeight1Y;

        vec4 sampleIrCacheColor0X0Y = sampleIrradianceCache(irCachePos - sampleOffsetX - sampleOffsetY, targetTexNormal);
        float sampleWeight0X0Y = sampleIrCacheColor0X0Y.w * step(1e-5, sampleIrCacheColor0X.w + sampleIrCacheColor0Y.w) * clamp(1.0 - length(samplePosition - sampleOffsetX - sampleOffsetY) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor0X0Y.rgb * sampleWeight0X0Y;
        totalWeight += sampleWeight0X0Y;
        vec4 sampleIrCacheColor0X1Y = sampleIrradianceCache(irCachePos - sampleOffsetX + sampleOffsetY, targetTexNormal);
        float sampleWeight0X1Y = sampleIrCacheColor0X1Y.w * step(1e-5, sampleIrCacheColor0X.w + sampleIrCacheColor1Y.w) * clamp(1.0 - length(samplePosition - sampleOffsetX + sampleOffsetY) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor0X1Y.rgb * sampleWeight0X1Y;
        totalWeight += sampleWeight0X1Y;
        vec4 sampleIrCacheColor1X0Y = sampleIrradianceCache(irCachePos + sampleOffsetX - sampleOffsetY, targetTexNormal);
        float sampleWeight1X0Y = sampleIrCacheColor1X0Y.w * step(1e-5, sampleIrCacheColor1X.w + sampleIrCacheColor0Y.w) * clamp(1.0 - length(samplePosition + sampleOffsetX - sampleOffsetY) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor1X0Y.rgb * sampleWeight1X0Y;
        totalWeight += sampleWeight1X0Y;
        vec4 sampleIrCacheColor1X1Y = sampleIrradianceCache(irCachePos + sampleOffsetX + sampleOffsetY, targetTexNormal);
        float sampleWeight1X1Y = sampleIrCacheColor1X1Y.w * step(1e-5, sampleIrCacheColor1X.w + sampleIrCacheColor1Y.w) * clamp(1.0 - length(samplePosition + sampleOffsetX + sampleOffsetY) / 1.5, 0.0, 1.0);
        totalIrCacheColor += sampleIrCacheColor1X1Y.rgb * sampleWeight1X1Y;
        totalWeight += sampleWeight1X1Y;

        totalWeight = max(totalWeight, 1e-5);
        totalIrCacheColor /= totalWeight;

        result = totalIrCacheColor;
    }
    return result;
}

void reflection(
    GbufferData gbufferData, vec3 gbufferF0, vec3 gbufferF82, float firstWeight, sampler2D albedoSampler, sampler2D normalSampler, sampler2D specularSampler,
    inout float reflectionDepth, inout vec3 mirrorColor, inout vec4 reflectionColor, out vec3 reflectionNormal, inout vec3 mirrorWeight
) {
    vec3 viewPos;
    #ifdef LOD
        if (gbufferData.depth > 1.0) {
            viewPos = screenToViewPosLod(texcoord, gbufferData.depth - 1.0 - 1e-7);
        } else
    #endif
    {
        viewPos = screenToViewPos(texcoord, gbufferData.depth - 1e-7);
    }
    vec3 worldPos = viewToWorldPos(viewPos);
    vec3 worldDir = worldPos - gbufferModelViewInverse[3].xyz;
    float worldDistance = inversesqrt(dot(worldDir, worldDir));
    worldDir *= worldDistance;
    float spreadSize = spreadAngle / worldDistance;
    reflectionNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.normal);
    vec3 worldGeoNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.geoNormal);
    vec3 voxelPos = worldToVoxelPos(worldPos + (1e-4 + uintBitsToFloat((floatBitsToUint(cameraPosition) & 0x7F800000u) - 0x0B800000u)) * worldGeoNormal);

    NoiseGenerator noiseGenerator = initNoiseGenerator(uvec2(gl_FragCoord.st), uint(frameCounter));

    float basicRoughness = pow2(1.0 - gbufferData.smoothness);
    float spreadBeta = spreadAngle + 0.2 * basicRoughness;
    vec2 noise = nextVec2(noiseGenerator);
    float gbufferNdotV = clamp(-dot(worldDir, reflectionNormal), 0.0, 1.0);
    float pdfRatio;
    vec3 rayDir = directionDistribution(noise, reflectionNormal, worldDir, basicRoughness, gbufferNdotV, pdfRatio);
    rayDir += worldGeoNormal * 2.0 * clamp(-dot(rayDir, worldGeoNormal), 0.0, 1.0);
    vec3 stainedColor = vec3(reflectionWeight(worldDir, rayDir, gbufferF0, gbufferF82)) * pdfRatio;
    mirrorWeight *= firstWeight;
    reflectionColor.w = gbufferData.smoothness;

    vec3 basicWeight = stainedColor * mirrorWeight;
    if (dot(basicWeight, basicWeight) > 1e-6) {
        float totalLength = 0.0;
        float prevRayLength = 0.0;
        float originSkyLight = gbufferData.lightmap.y;
        vec3 singleLight = vec3(0.0);
        vec3 roughWeight = vec3(1.0);
        vec2 atlasTexSize = vec2(textureSize(albedoSampler, 0));

        Ray tracedRay;
        tracedRay.origin = voxelPos;
        tracedRay.direction = rayDir;

        float rayLength = 0.0;
        float emissiveScale = 1.0;
        float targetSkyLight = 1.0;
        float textureResolution = TEXTURE_RESOLUTION;
        vec2 atlasTiles = atlasTexSize / textureResolution;
        vec4 targetAlbedo = vec4(1.0);

        float i = 1.0;
        bool hitSky = true;
        while (true) {
            tracedRay.dirSigned = signI(tracedRay.direction);
            hitSky = true;
            float prevID = 255.0;
            vec2 targetCoord = vec2(0.0);
            vec3 targetNormal = -tracedRay.direction;
            vec3 targetTangent = vec3(1.0);
            vec3 voxelIndex = tracedRay.dirSigned * floor(tracedRay.origin);
            vec3 stepLength = 1.0 / max(vec3(1e-6), abs(tracedRay.direction));
            tracedRay.dirInv = stepLength * tracedRay.dirSigned;
            vec3 nextLength = (voxelIndex - (tracedRay.origin - 0.5) * tracedRay.dirSigned + 0.5) * stepLength;
            ivec2 shadowTexel = ivec2(calcVoxelShadowTexel(tracedRay.dirSigned * voxelIndex));
            while (i < float(REFLECTION_MAX_STEP)) {
                vec4 voxelData0 = texelFetch(shadowcolor0, shadowTexel, 0);
                vec4 voxelData1 = texelFetch(shadowcolor1, shadowTexel, 0);
                i += 1.0;
                vec3 realVoxelIndex = tracedRay.dirSigned * voxelIndex;
                vec3 voxelDistance = abs(realVoxelIndex - voxelizationRadius + 0.5);
                rayLength = min(nextLength.x, min(nextLength.y, nextLength.z));
                vec3 nextBlock = clamp(1.0 - (nextLength - rayLength) * 1e+10, vec3(0.0), vec3(1.0));
                voxelIndex += nextBlock;
                nextLength += nextBlock * stepLength;
                shadowTexel = ivec2(calcVoxelShadowTexel(tracedRay.dirSigned * voxelIndex));
                float prevIDCopy = prevID;
                prevID = 255.0;
                if (any(greaterThan(voxelDistance, voxelizationRadius))) {
                    break;
                }
                if (voxelData0.w < 1.0) {
                    targetSkyLight = voxelData0.w;
                    voxelData1.z = round(voxelData1.z * 255.0);
                    #if TEXTURE_RESOLUTION == 0
	                    textureResolution = uintBitsToFloat((0x7Fu + (uint(round(voxelData1.w * 255.0)) & 0x7Fu)) << 23u);
                        atlasTiles = atlasTexSize / textureResolution;
                    #endif
                    if (isRayHitBlock(
                        tracedRay, albedoSampler, atlasTiles, voxelData0.rgb, voxelData1, realVoxelIndex, vec2(spreadSize, spreadBeta) * textureResolution,
                        targetAlbedo, targetCoord, rayLength, targetNormal, targetTangent, emissiveScale
                    )) {
                        emissiveScale *= step(0.4, voxelData1.w);
                        if (targetAlbedo.w > 0.999 && voxelData1.z != 168.0) {
                            hitSky = false;
                            prevID = emissiveScale;
                            // Lava
                            tracedRay.dirSigned.x = float(0.4 < voxelData1.w && (abs(voxelData1.z - 9.0) < 7.5 || voxelData1.z == 1.0));
                            break;
                        }
                        float fogAbsorptionLength = rayLength - prevRayLength;
                        if (voxelData1.z == 168.0) {
                            vec3 lightColor = pow(targetAlbedo.rgb, vec3(2.2)) * stainedColor;
                            if (isEyeInWater == 0) {
                                #ifdef NETHER
                                    lightColor *= netherFogAbsorption(fogAbsorptionLength);
                                #elif defined THE_END
                                    lightColor *= endFogAbsorption(fogAbsorptionLength);
                                #else
                                    lightColor *= airAbsorption(fogAbsorptionLength);
                                #endif
                            }
                            else if (isEyeInWater == 1) {
                                lightColor *= waterFogAbsorption(fogAbsorptionLength);
                            }
                            singleLight += lightColor * PI * BLOCK_LIGHT_BRIGHTNESS;
                        }
                        else if (targetAlbedo.w > 0.001) {
                            prevID *= step(100.0, voxelData1.z);
                            if (voxelData1.z + prevIDCopy > 100.0) {
                                SpecularData specularData = SpecularData(0.0, 0.0, 0.0, 0.0);
                                #ifdef MC_SPECULAR_MAP
                                    specularData = SPECULAR_FORMAT(textureLod(specularSampler, targetCoord, 0.0));
                                #endif
                                #ifndef SPECULAR_EMISSIVE
                                    specularData.emissive = 0.0;
                                #endif
                                #ifdef HARDCODED_EMISSIVE
                                    specularData.emissive += step(specularData.emissive, 1e-3) * emissiveScale;
                                #endif
                                specularData.emissive *= BLOCK_LIGHT_BRIGHTNESS;
                                if (isEyeInWater == 0) {
                                    #ifdef NETHER
                                        singleLight += netherFogScattering(fogAbsorptionLength) * stainedColor;
                                        stainedColor *= netherFogAbsorption(fogAbsorptionLength);
                                    #elif defined THE_END
                                        singleLight += endFogScattering(fogAbsorptionLength) * stainedColor;
                                        stainedColor *= endFogAbsorption(fogAbsorptionLength);
                                    #else
                                        #ifdef SHADOW_AND_SKY
                                            #ifdef ATMOSPHERE_SCATTERING_FOG
                                                float atmosphereDepth = fogAbsorptionLength * (1.0 + RF_GROUND_EXTRA_DENSITY * 3.0 * weatherStrength);
                                                singleLight += solidAtmosphereScattering(vec3(0.0), tracedRay.direction, skyColorUp, atmosphereDepth, originSkyLight) * stainedColor;
                                                stainedColor *= exp2(-atmosphereDepth * rainyMieBeta * 25.0 * 1.44269502);
                                            #endif
                                        #endif
                                        stainedColor *= airAbsorption(fogAbsorptionLength);
                                    #endif
                                    prevRayLength = rayLength;
                                }
                                else if (isEyeInWater == 1) {
                                    singleLight += waterFogScattering(tracedRay.direction, skyColorUp, fogAbsorptionLength, originSkyLight) * stainedColor;
                                    stainedColor *= waterFogAbsorption(fogAbsorptionLength);
                                    prevRayLength = rayLength;
                                }
                                targetAlbedo.rgb = 2.2 * log2(targetAlbedo.rgb);
                                singleLight += exp2(targetAlbedo.rgb) * specularData.emissive * stainedColor * targetAlbedo.w * PI;
                                targetAlbedo.rgb = exp2(sqrt(targetAlbedo.w * 1.5) * (targetAlbedo.rgb + log2(1.0 - 0.5 * targetAlbedo.w * targetAlbedo.w)));
                                float LdotH = clamp(dot(-tracedRay.direction, targetNormal), 0.0, 1.0);
                                float f0 = 0.04;
                                #ifdef LABPBR_F0
                                    f0 = mix(f0, specularData.metalness, step(0.001, specularData.metalness));
                                #endif
                                targetAlbedo.rgb *= sqrt(1.0 - fresnel(LdotH, vec3(f0)));
                                stainedColor *= targetAlbedo.rgb;
                            }
                        }
                    }
                    targetNormal = -tracedRay.direction;
                }
            }
            if (hitSky) break;
            tracedRay.origin += tracedRay.direction * rayLength;
            vec3 targetWorldPos = tracedRay.origin - voxelOffset - voxelizationRadius;
            #ifdef VIVECRAFT
                targetWorldPos += floor(cameraPositionFract + vivecraftShadowCameraOffset);
            #endif
            targetWorldPos.y += voxelOriginY;
            tracedRay.origin -= 1e-4 * tracedRay.direction;
            vec3 targetTexNormal = targetNormal;

            targetSkyLight = targetSkyLight * 255.0 / 128.0 - 32.0 / 128.0;
            SpecularData specularData = SpecularData(0.0, 0.0, 0.0, 0.0);
            spreadSize += spreadBeta * rayLength;
            #ifdef SCREEN_DATA_COVER
                #ifdef DEFERRED_REFLECTION
                    vec3 targetViewNormal = mat3(gbufferModelView) * targetNormal;
                    vec3 targetViewPos = worldToViewPos(targetWorldPos);
                    vec3 targetProjPos = vec3(gbufferProjection[0].x, gbufferProjection[1].y, gbufferProjection[2].z) * targetViewPos;
                    targetProjPos.z += gbufferProjection[3].z;
                    targetProjPos.xy += gbufferProjection[2].xy * targetViewPos.z;
                    targetProjPos /= -targetViewPos.z;
                    #ifdef TAA
                        targetProjPos.st += taaOffset;
                    #endif
                    bool screenDataUsable = all(lessThan(abs(targetProjPos.st), vec2(1.0)));
                    vec3 targetScreenPos = targetProjPos * 0.5 + 0.5;
                    #if SR_ENABLE
                        targetScreenPos.st *= renderScale;
                    #endif
                    targetScreenPos.st = (floor(targetScreenPos.st * screenSize) + 0.5) * texelSize;
                    ivec2 targetScreenTexel = ivec2(targetScreenPos.st * screenSize);
                    vec3 sampleNormal, sampleGeoNormal;
                    getBothNormalsTexel(targetScreenTexel, sampleNormal, sampleGeoNormal);
                    float sampleDepth = textureLod(depthtex1, targetScreenPos.st, 0.0).r;
                    vec3 sampleViewPos = screenToViewPos(targetScreenPos.st, sampleDepth);
                    float depthFactor = abs(dot(sampleViewPos - targetViewPos, targetViewNormal));
                    screenDataUsable = screenDataUsable && dot(sampleGeoNormal, targetViewNormal) > 0.9 && depthFactor < 0.02;
                    float blendWeight = clamp(dot(sampleViewPos, sampleGeoNormal) * inversesqrt(dot(sampleViewPos, sampleViewPos)) * -8.0 - 1.0, 0.0, 1.0);
                    blendWeight *= blendWeight * float(screenDataUsable);
                    if (blendWeight > 0.0) {
                        targetAlbedo = mix(targetAlbedo, texelFetch(colortex0, targetScreenTexel, 0), blendWeight);
                        targetAlbedo.rgb = log2(targetAlbedo.rgb);
                        sampleNormal = mat3(gbufferModelViewInverse) * sampleNormal;
                        vec4 texData2 = texelFetch(colortex2, targetScreenTexel, 0);
                        vec2 unpacked2g = unpack16Bit(texData2.g);
                        vec2 unpacked2b = unpack16Bit(texData2.b);
                        specularData.smoothness = unpacked2g.x;
                        specularData.metalness = unpacked2g.y;
                        specularData.porosity = unpacked2b.x;
                        specularData.emissive = unpacked2b.y;
                        float NdotV = dot(sampleNormal, -tracedRay.direction);
                        vec3 edgeNormal = sampleNormal + tracedRay.direction * NdotV;
                        float curveStart = dot(-tracedRay.direction, targetNormal);
                        float weight = clamp(curveStart - curveStart * exp(NdotV / curveStart - 1.0), 0.0, 1.0);
                        weight = max(NdotV, curveStart) - weight;
                        targetTexNormal = -tracedRay.direction * weight + edgeNormal * max(0.0, inversesqrt(dot(edgeNormal, edgeNormal) / (1.0 - weight * weight)));
                    }
                    else
                #endif
            #endif
            {
                #ifdef MC_SPECULAR_MAP
                    specularData = SPECULAR_FORMAT(textureLod(specularSampler, targetCoord, 0.0));
                #endif
                #ifndef SPECULAR_EMISSIVE
                    specularData.emissive = 0.0;
                #endif
                #ifdef HARDCODED_EMISSIVE
                    specularData.emissive += step(specularData.emissive, 1e-3) * prevID;
                #endif
                targetAlbedo.rgb = log2(targetAlbedo.rgb);

                #ifdef MC_NORMAL_MAP
                    float lod = log2(spreadSize * textureResolution);
                    vec4 normalData = textureLod(normalSampler, targetCoord, lod);
                    #ifdef LABPBR_TEXTURE_AO
                        targetAlbedo.rgb += log2(normalData.b) / 2.2;
                    #endif
                    mat3 tbnMatrix = mat3(targetTangent, cross(targetTangent, targetNormal), targetNormal);
                    targetTexNormal = calculateReflectionNormal(
                        normalSampler, targetCoord, normalData, tbnMatrix, atlasTexSize, atlasTiles, textureResolution, targetNormal, tracedRay.direction, lod
                    );
                #endif

                float metalness = specularData.metalness;
                #ifdef LABPBR_F0
                    metalness = step(229.5 / 255.0, metalness);
                #endif
                if (rainyStrength > 0.01 && tracedRay.dirSigned.x < 0.5) {
                    float porosity = step(specularData.porosity, 64.5 / 255.0) * (specularData.porosity * 255.0 / 64.0);
                    float outdoor = clamp(15.0 * targetSkyLight - 14.0, 0.0, 1.0);

                    float porosityDarkness = porosity * outdoor * rainyStrength;
                    targetAlbedo.rgb = max(0.0, 1.0 + porosityDarkness) * targetAlbedo.rgb + log2(1.0 - 0.2 * porosityDarkness);

                    #if RAIN_PUDDLE == 1
                        float rainWetness = clamp(targetNormal.y * 10.0 - 0.1, 0.0, 1.0) * outdoor * rainyStrength * (1.0 - porosity);
                        specularData.smoothness += (1.0 - metalness) * (rainWetness - specularData.smoothness * rainWetness);
                    #elif RAIN_PUDDLE == 2
                        specularData.smoothness += (1.0 - specularData.smoothness) * groundWetStrength(
                            targetWorldPos + cameraPosition, targetNormal.y, metalness, porosity, outdoor
                        );
                    #endif
                }
            }
            vec3 f0 = vec3(0.04);
            vec3 f82 = vec3(1.0);
            #ifdef LABPBR_F0
                f0 = mix(f0, vec3(specularData.metalness), step(0.001, specularData.metalness));
                f82 = hardcodedMetal(specularData.metalness);
                specularData.metalness = step(229.5 / 255.0, specularData.metalness);
            #endif
            targetAlbedo.rgb = exp2(2.2 * targetAlbedo.rgb);
            f0 = mix(f0, targetAlbedo.rgb, specularData.metalness);
            specularData.emissive *= BLOCK_LIGHT_BRIGHTNESS * PI;

            float fogAbsorptionLength = rayLength - prevRayLength;
            if (isEyeInWater == 0) {
                #ifdef THE_END
                    singleLight += endFogScattering(fogAbsorptionLength) * stainedColor;
                    stainedColor *= vec3(endFogAbsorption(fogAbsorptionLength));
                #elif defined NETHER
                    singleLight += netherFogScattering(fogAbsorptionLength) * stainedColor;
                    stainedColor *= vec3(netherFogAbsorption(fogAbsorptionLength));
                #else
                    #ifdef SHADOW_AND_SKY
                        #ifdef ATMOSPHERE_SCATTERING_FOG
                            float atmosphereDepth = fogAbsorptionLength * (1.0 + RF_GROUND_EXTRA_DENSITY * 3.0 * weatherStrength);
                            singleLight += solidAtmosphereScattering(vec3(0.0), tracedRay.direction, skyColorUp, atmosphereDepth, originSkyLight) * stainedColor;
                            stainedColor *= exp2(-atmosphereDepth * rainyMieBeta * 25.0 * 1.44269502);
                        #endif
                    #endif
                    stainedColor *= vec3(airAbsorption(fogAbsorptionLength));
                    singleLight *= vec3(airAbsorption(fogAbsorptionLength));
                #endif
            }
            else if (isEyeInWater == 1) {
                singleLight += waterFogScattering(tracedRay.direction, skyColorUp, fogAbsorptionLength, originSkyLight) * stainedColor;
                stainedColor *= waterFogAbsorption(fogAbsorptionLength);
            }
            else if (isEyeInWater == 2) {
                singleLight += lavaFogScattering(rayLength) * stainedColor;
                stainedColor *= vec3(lavaFogAbsorption(rayLength));
            }
            else if (isEyeInWater == 3) {
                singleLight += snowFogScattering(skyColorUp, rayLength, originSkyLight) * stainedColor;
                stainedColor *= vec3(snowFogAbsorption(rayLength));
            }

            float NdotV = clamp(dot(-tracedRay.direction, targetTexNormal), 0.0, 1.0);
            vec3 diffuseAbsorption = (1.0 - specularData.metalness) * diffuseAbsorptionWeight(NdotV, specularData.smoothness, f0, f82);

            #ifdef SHADOW_AND_SKY
                float shadowLightFactor = 1.0;
                #ifdef LIGHT_LEAKING_FIX
                    shadowLightFactor = clamp(targetSkyLight * 10.0, 0.0, 1.0);
                #endif
                float NdotL = clamp(dot(targetTexNormal, shadowDirection), 0.0, 1.0);
                vec3 shadow = vec3(1.0);
                vec3 subsurfaceScattering = vec3(float(specularData.porosity > 64.5 / 255.0));
                directShadow(
                    targetWorldPos, targetNormal, NdotL, shadowLightFactor, specularData.smoothness,
                    specularData.porosity, targetSkyLight, 0.0, shadow, subsurfaceScattering
                );
                shadow =
                    (shadow + subsurfaceScattering) * targetAlbedo.rgb * diffuseAbsorption +
                    shadow * sunlightSpecular(
                        tracedRay.direction, shadowDirection, targetTexNormal, specularData.smoothness * reflectionColor.w * 0.995, NdotL, NdotV, f0, f82
                    ) * airAbsorption(11.4 * specularData.smoothness) * clamp(19.0 - reflectionColor.w * specularData.smoothness * 20.0, 0.0, 1.0);
                #ifdef CLOUD_SHADOW
                    shadow *= cloudShadow(targetWorldPos, shadowDirection);
                #endif
                shadow *= sunColor;
                singleLight += shadow * stainedColor;
            #endif

            // They are moved from below, to reduce register usage in irradiance cache.
            vec3 viewRayDir = tracedRay.direction;
            float roughness = 1.0 - specularData.smoothness;
            spreadBeta = spreadBeta + roughness * roughness * (0.2 - spreadBeta);
            noise = nextVec2(noiseGenerator);
            float pdfRatio;
            tracedRay.direction = directionDistribution(noise, targetTexNormal, viewRayDir, roughness * roughness, NdotV, pdfRatio);
            tracedRay.direction += targetNormal * 2.0 * clamp(-dot(tracedRay.direction, targetNormal), 0.0, 1.0);
            vec3 nextReflectionWeight = reflectionWeight(viewRayDir, tracedRay.direction, f0, f82) * pdfRatio;

            vec3 targetLight = vec3(BASIC_LIGHT + NIGHT_VISION_BRIGHTNESS * nightVision);
            #ifdef HELD_LIGHT
                vec3 targetWorldPosNoOffset = targetWorldPos - gbufferModelViewInverse[3].xyz;
                float targetWorldDepth = dot(targetWorldPosNoOffset, targetWorldPosNoOffset);
                vec3 targetWorldDir = targetWorldPosNoOffset * inversesqrt(targetWorldDepth);

                targetLight += (heldBlockLightValue + heldBlockLightValue2) * clamp(dot(targetWorldDir, -targetTexNormal), 0.0, 1.0) / 6.0 / (targetWorldDepth + 0.5) * commonLightColor;
            #endif
            #ifdef SMOOTH_IRRADIANCE_CACHE
                targetLight += getIrradianceCacheSmoothed(tracedRay.origin, targetNormal, targetTexNormal, skyColorUp, targetSkyLight);
            #else
                targetLight += getIrradianceCache(tracedRay.origin, targetNormal, targetTexNormal, skyColorUp, targetSkyLight);
            #endif

            float diffuseWeight = pow(roughness, 5.0);
            #ifndef FULL_REFLECTION
                diffuseWeight = 1.0 - (1.0 - diffuseWeight) * sqrt(clamp(specularData.smoothness - roughness * (1.0 - 0.6666 * specularData.metalness), 0.0, 1.0));
            #endif

            targetLight = targetAlbedo.rgb * (
                (diffuseAbsorption + diffuseWeight / PI) * targetLight + specularData.emissive
            );

            singleLight += targetLight * stainedColor;
            stainedColor *= (1.0 - diffuseWeight);

            if (reflectionColor.w > 0.95) {
                mirrorColor += singleLight * mirrorWeight;
                mirrorWeight *= stainedColor;
                reflectionNormal = normalize(targetTexNormal * 1.5 + reflectionNormal);
            }
            else {
                reflectionColor.rgb += singleLight * roughWeight;
                roughWeight *= stainedColor;
            }
            totalLength += rayLength;

            stainedColor = nextReflectionWeight;

            vec3 totalWeight = mirrorWeight * roughWeight * stainedColor;
            if (dot(totalWeight, totalWeight) < 1e-6) {
                break;
            }
            reflectionColor.w *= pow(max(specularData.smoothness, 1e-6), pow(reflectionColor.w, 50.0));

            prevRayLength = 0.0;
            originSkyLight = targetSkyLight;
            singleLight = vec3(0.0);
        }
        if (hitSky) {
            vec3 hitWorldPos = tracedRay.origin - voxelOffset - voxelizationRadius;
            #ifdef VIVECRAFT
                hitWorldPos += floor(cameraPositionFract + vivecraftShadowCameraOffset);
            #endif
            hitWorldPos.y += voxelOriginY;
            vec3 finalLight = vec3(0.0);
            float atmosphereDepth = 0.0;
            #ifdef SCREEN_SPACE_REFLECTION
                vec3 missingWorldPos = hitWorldPos + tracedRay.direction * rayLength;
                vec3 originViewPos = worldToViewPos(missingWorldPos);
                vec4 originProjPos = vec4(vec3(gbufferProjection[0].x, gbufferProjection[1].y, gbufferProjection[2].z) * originViewPos, -originViewPos.z);
                originProjPos.z += gbufferProjection[3].z;
                originProjPos.xy += gbufferProjection[2].xy * originViewPos.z;
                #ifdef TAA
                    originProjPos.xy += taaOffset * originProjPos.w;
                #endif
                float originProjScale = 1.0 / originProjPos.w;
                vec4 originCoord = vec4(originProjPos.xyz * abs(originProjScale), 0.0);
                if (all(lessThan(abs(originCoord.st), vec2(1.0))) && originCoord.z > -1.0) {
                    originCoord = originCoord * 0.5 + 0.5;

                    vec3 viewRayDir = mat3(gbufferModelView) * tracedRay.direction;
                    vec4 projDirection = vec4(vec3(gbufferProjection[0].x, gbufferProjection[1].y, gbufferProjection[2].z) * viewRayDir, -viewRayDir.z);
                    projDirection.xy += gbufferProjection[2].xy * viewRayDir.z;
                    float traceLength = projIntersectionScreenEdge(originProjPos, projDirection);
                    vec4 targetProjPos = originProjPos + projDirection * traceLength;
                    float targetProjScale = 0.5 / targetProjPos.w;
                    vec4 targetCoord = vec4(targetProjPos.xyz * targetProjScale + 0.5, 0.0);

                    #ifdef LOD
                        projDirection.z = viewRayDir.z * projLod()[2].z;
                        float originProjDepthLod = originViewPos.z * projLod()[2].z + projLod()[3].z;
                        originCoord.w = originProjDepthLod * originProjScale * 0.5 + 0.5;
                        targetCoord.w = (originProjDepthLod + projDirection.z * traceLength) * targetProjScale + 0.5;
                    #endif
                    #if SR_ENABLE
                        originCoord.st *= renderScale;
                        targetCoord.st *= renderScale;
                    #endif

                    float noise = blueNoiseTemporal(texcoord).x + 0.1;
                    vec4 stepSize = (targetCoord - originCoord) / (SCREEN_SPACE_REFLECTION_STEP - 1.0);
                    float stepSizeLengthInv = texelSize.y * inversesqrt(dot(stepSize.xy, stepSize.xy));
                    originCoord += max(noise, stepSizeLengthInv) * stepSize;
                    stepSize *= max(1.0, stepSizeLengthInv);
                    float minimumThichness = max(0.0005 * originProjScale, abs(stepSize.z));
                    float minimumThichnessLod = max(0.005 * originProjScale, abs(stepSize.w));
                    for (int i = 0; i < SCREEN_SPACE_REFLECTION_STEP; i++) {
                        float sampleDepth = textureLod(depthtex1, originCoord.st, 0.0).x;
                        bool hitCheck = originCoord.z > sampleDepth && sampleDepth < 1.0;
                        #ifdef LOD
                            #ifdef DEFERRED_REFLECTION
                                float sampleDepthLod = getLodDepthSolidDeferred(originCoord.st);
                            #else
                                float sampleDepthLod = getLodDepthSolid(originCoord.st);
                            #endif
                            hitCheck = hitCheck || (sampleDepth == 1.0 && originCoord.w > sampleDepthLod && sampleDepthLod < 1.0);
                        #endif
                        if (hitCheck) {
                            float stepScale = 0.5;
                            vec4 refinementCoord = originCoord;
                            for (int j = 0; j < SCREEN_SPACE_REFLECTION_REFINEMENTS; j++) {
                                float stepDirection = sampleDepth - refinementCoord.z;
                                #ifdef LOD
                                    #ifdef DEFERRED_REFLECTION
                                        sampleDepthLod = getLodDepthSolidDeferred(refinementCoord.st);
                                    #else
                                        sampleDepthLod = getLodDepthSolid(refinementCoord.st);
                                    #endif
                                    float stepDirectionLod = sampleDepthLod - refinementCoord.w;
                                    stepDirection = mix(stepDirection, stepDirectionLod, float(sampleDepth == 1.0));
                                #endif
                                refinementCoord += signMul(stepScale, stepDirection) * stepSize;
                                sampleDepth = textureLod(depthtex1, refinementCoord.st, 0.0).x;
                                stepScale *= 0.5;
                            }
                            bool hitTerrain = abs(refinementCoord.z - sampleDepth) < minimumThichness && sampleDepth < 1.0;
                            #ifdef LOD
                                hitTerrain = hitTerrain || (sampleDepth == 1.0 && abs(refinementCoord.w - sampleDepthLod) < minimumThichnessLod && sampleDepthLod < 1.0);
                            #endif
                            if (hitTerrain && all(lessThan(floatBitsToUint(refinementCoord.st), floatBitsToUint(screenEdge)))) {
                                originCoord = refinementCoord;
                                hitSky = false;
                                break;
                            }
                        }
                        if (any(greaterThan(floatBitsToUint(originCoord.st), floatBitsToUint(screenEdge))) || originCoord.z < 0.0) break;
                        originCoord += stepSize;
                    }
                    if (!hitSky) {
                        vec3 sampleViewPos;
                        vec3 sampleProjPos = originCoord.xyw * 2.0 - 1.0;
                        #ifdef TAA
                            sampleProjPos.st -= taaOffset;
                        #endif
                        #if SR_ENABLE
                            sampleProjPos.xy = sampleProjPos.xy * upscaleRatio + upscaleRatio - 1.0;
                        #endif
                        sampleProjPos.xy *= vec2(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y);
                        sampleProjPos.xy += gbufferProjectionInverse[3].xy;
                        float projectionScale = sampleProjPos.z;
                        #ifdef LOD
                            if (originCoord.z >= 1.0) {
                                projectionScale = projLod()[3].z / (sampleProjPos.z + projLod()[2].z);
                            } else
                        #endif
                        {
                            projectionScale = gbufferProjection[3].z / (sampleProjPos.z + gbufferProjection[2].z);
                        }
                        sampleViewPos = vec3(sampleProjPos.xy * projectionScale, -projectionScale);
                        rayLength += distance(sampleViewPos, originViewPos);
                        totalLength += rayLength;
                        #ifndef DEFERRED_REFLECTION
                            rayLength = prevRayLength;
                        #endif
                        atmosphereDepth = rayLength * (1.0 + RF_GROUND_EXTRA_DENSITY * 3.0 * weatherStrength);
                        finalLight = texelFetch(colortex5, ivec2(originCoord.xy * screenSize), 0).rgb;
                    }
                }
                if (hitSky)
            #endif
            {
                totalLength += 2.0 * far;
                rayLength = 114514.0;
                #ifdef SHADOW_AND_SKY
                    vec3 skylightColor = renderSun(tracedRay.direction, sunDirection, vec3(300.0)) * clamp(reflectionColor.w * 20.0 - 18.0, 0.0, 1.0);
                    vec3 atmosphere;
                    vec4 intersectionData = planetIntersectionData(hitWorldPos, tracedRay.direction);
                    atmosphereDepth = 1600.0;
                    skylightColor = singleAtmosphereScattering(skylightColor, hitWorldPos, tracedRay.direction, sunDirection, intersectionData, skyColorUp, 30.0, atmosphere);
                    vec4 planeCloud = vec4(0.0);
                    #ifdef PLANE_CLOUD
                        planeCloud = planeClouds(hitWorldPos, tracedRay.direction, sunDirection, skyColorUp, intersectionData.xyz);
                        skylightColor = mix(skylightColor, planeCloud.rgb, planeCloud.a * float(hitWorldPos.y + cameraPosition.y < PLANE_CLOUD_HEIGHT));
                    #endif
                    #ifdef CLOUD_IN_REFLECTION
                        float cloudDepth;
                        skylightColor = sampleClouds(
                            skylightColor, atmosphere, hitWorldPos, tracedRay.direction, shadowDirection, sunDirection, skyColorUp, intersectionData.xyz, 0.0, cloudDepth
                        ).rgb;
                    #endif
                    if (hitWorldPos.y + cameraPosition.y >= PLANE_CLOUD_HEIGHT) {
                        skylightColor = mix(skylightColor, planeCloud.rgb, planeCloud.a);
                    }
                    #ifdef LIGHT_LEAKING_FIX
                        skylightColor *= clamp(originSkyLight, 0.0, 1.0);
                    #endif
                    finalLight = skylightColor;
                #endif
            }
            float fogAbsorptionLength = rayLength - prevRayLength;
            if (isEyeInWater == 0) {
                #ifdef THE_END
                    finalLight = endFogTotal(finalLight, fogAbsorptionLength);
                    if (hitSky) {
                        finalLight += endStars(tracedRay.direction) * exp2(50.0 * (reflectionColor.w - 1.0));
                    }
                #elif defined NETHER
                    finalLight = netherFogTotal(finalLight, fogAbsorptionLength);
                #else
                    #ifdef SHADOW_AND_SKY
                        #ifdef ATMOSPHERE_SCATTERING_FOG
                            finalLight = solidAtmosphereScattering(finalLight, tracedRay.direction, skyColorUp, atmosphereDepth, originSkyLight);
                        #endif
                    #endif
                    finalLight *= airAbsorption(fogAbsorptionLength);
                #endif
            }
            else if (isEyeInWater == 1) {
                finalLight = waterFogTotal(finalLight, tracedRay.direction, skyColorUp, fogAbsorptionLength, originSkyLight);
            }
            else if (isEyeInWater == 2) {
                finalLight = lavaFogTotal(finalLight, fogAbsorptionLength);
            }
            else if (isEyeInWater == 3) {
                finalLight = snowFogTotal(finalLight, skyColorUp, fogAbsorptionLength, originSkyLight);
            }
            finalLight *= stainedColor;
            finalLight = finalLight + singleLight;
            if (reflectionColor.w > 0.95) {
                mirrorColor += finalLight * mirrorWeight;
            }
            else {
                reflectionColor.rgb += finalLight * roughWeight;
            }
        }
        reflectionDepth = totalLength / far;

        reflectionColor.w = clamp(pow2(1.0 - reflectionColor.w), 0.0, 1.0);
    }
}
