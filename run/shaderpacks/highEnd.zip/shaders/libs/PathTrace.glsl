#ifdef SHADOW_AND_SKY
    const float voxelMapResolution = realShadowMapResolution - 2048;
#else
    const float voxelMapResolution = realShadowMapResolution;
#endif
#if MC_VERSION >= 11800
    const float chunkHeight = 384.0;
#else
    const float chunkHeight = 256.0;
#endif
const float maximumVoxelizationHeight = floor(pow(voxelMapResolution, 2.0 / 3.0));
const float voxelizationHeight = min(maximumVoxelizationHeight - mod(maximumVoxelizationHeight, 2.0), chunkHeight);
const float voxelizationDiameterRaw = voxelizationHeight == (chunkHeight) ? floor(sqrt(voxelMapResolution * voxelMapResolution / voxelizationHeight)) : voxelizationHeight;
const float voxelizationDiameter = voxelizationDiameterRaw - mod(voxelizationDiameterRaw, 2.0);
const vec3 voxelizationRadius = vec3(voxelizationDiameter / 2.0, voxelizationHeight / 2.0, voxelizationDiameter / 2.0);
const float maximumVoxelizationCenter = 128.0 + max(0.0, chunkHeight / 2.0 - floor(voxelizationHeight / 2.0));
const float minimumVoxelizationCenter = 128.0 - max(0.0, chunkHeight / 2.0 - floor(voxelizationHeight / 2.0));

#ifdef VOXELIZATION_HEIGHT_CLAMP
    float voxelOriginY = clamp(voxelOrigin, minimumVoxelizationCenter, maximumVoxelizationCenter) - voxelOrigin;
#else
    float voxelOriginY = 0.0;
#endif

struct SpecularData {
    float smoothness;
    float metalness;
    float porosity;
    float emissive;
};

SpecularData LabPBR(vec4 texData) {
    SpecularData specularData;
    specularData.smoothness = texData.r;
    specularData.metalness = texData.g;
    specularData.porosity = texData.b;
    #ifndef LABPBR_POROSITY
        specularData.porosity = 0.0;
    #endif
    specularData.emissive = texData.a * step(texData.a, 0.999);
    return specularData;
}

SpecularData ClassicPBR(vec4 texData) {
    SpecularData specularData;
    specularData.smoothness = texData.r;
    specularData.metalness = texData.g;
    specularData.porosity = 0.0;
    specularData.emissive = texData.b;
    return specularData;
}

SpecularData BedrockRTX(vec4 texData) {
    SpecularData specularData;
    specularData.smoothness = 1.0 - texData.b;
    specularData.metalness = texData.r;
    specularData.porosity = 0.0;
    specularData.emissive = texData.g;
    return specularData;
}

vec2 calcVoxelShadowTexel(vec3 voxelPos) {
    voxelPos.x = voxelPos.x + voxelPos.y * voxelizationDiameter;
    voxelPos.y = floor(voxelPos.x / voxelMapResolution);
    voxelPos.x = voxelPos.x - voxelMapResolution * voxelPos.y;
    voxelPos.y = voxelPos.y * voxelizationDiameter + voxelPos.z;
    return voxelPos.xy;
}

vec3 worldToVoxelPos(vec3 worldPos) {
    vec3 voxelPos = worldPos + voxelOffset + voxelizationRadius;
    #ifdef VIVECRAFT
        voxelPos -= floor(cameraPositionFract + vivecraftShadowCameraOffset);
    #endif
    voxelPos.y -= voxelOriginY;
    return voxelPos;
}

vec2 calcIrCacheTexel(vec3 voxelPos) {
    voxelPos.x = voxelPos.x + voxelPos.y * irCacheDiameter;
    voxelPos.y = floor(voxelPos.x * texelSize.x);
    voxelPos.x = voxelPos.x - screenSize.x * voxelPos.y;
    voxelPos.y = voxelPos.y * irCacheDiameter + voxelPos.z;
    return voxelPos.xy;
}

void irradianceCacheData(vec2 texel, out vec3 irCacheColor, out vec3 irCacheDir) {
    uvec3 prevIrradianceCache = texelFetch(colortex3, ivec2(texel), 0).rgb;
    vec2 dataX = unpackHalf2x16(prevIrradianceCache.x);
    vec2 dataY = unpackHalf2x16(prevIrradianceCache.y);
    vec2 dataZ = unpackHalf2x16(prevIrradianceCache.z);

    irCacheColor = vec3(dataX.x, dataY.x, dataZ.x);
    irCacheDir = vec3(dataX.y, dataY.y, dataZ.y);
}

vec4 sampleIrradianceCache(vec3 irCachePos, vec3 targetNormal) {
    vec2 irCacheCoord = calcIrCacheTexel(irCachePos);

    vec3 irCacheColor;
    vec3 irCacheDir;
    irradianceCacheData(irCacheCoord, irCacheColor, irCacheDir);

    float icCacheLuminance = dot(irCacheColor.rgb, vec3(0.333333));
    float sampleValid = step(1e-6, icCacheLuminance);

    irCacheColor = irCacheColor * max(0.0, 0.88622693 + 0.59081795 * dot(targetNormal, irCacheDir) / icCacheLuminance);

    return vec4(irCacheColor, sampleValid);
}

vec3 getIrradianceCache(vec3 voxelPos, vec3 targetNormal, vec3 targetTexNormal, vec3 skyColorUp, float skyLight) {
    vec3 voxelIndex = floor(voxelPos + targetNormal * 0.01);
    voxelIndex.y += voxelOriginY;
    vec3 irCachePos = voxelIndex - voxelizationRadius;
    vec3 result;
    if (all(lessThan(abs(irCachePos + 0.5), vec3(irCacheRadius)))) {
        irCachePos += irCacheRadius;
        result = sampleIrradianceCache(irCachePos, targetTexNormal).rgb;
    } else {
        result = clamp(skyLight * 1.5, 0.0, 1.0) * skyColorUp * (targetNormal.y * 0.5 + 0.5);
    }
    return result;
}

vec3 getIrradianceCachePrev(vec3 voxelPos, vec3 targetNormal) {
    vec3 voxelIndex = floor(voxelPos);
    voxelIndex.y += voxelOriginY;
    vec3 irCachePos = voxelIndex - voxelizationRadius + voxelMovement;
    vec3 result = vec3(0.0);
    if (all(lessThan(abs(irCachePos + 0.5), vec3(irCacheRadius)))) {
        irCachePos += irCacheRadius;
        vec3 irCacheColor = sampleIrradianceCache(irCachePos, targetNormal).rgb;
        result = irCacheColor;
    }
    return result;
}
