#define MAT_DEFAULT 0
#define MAT_WATER 1
#define MAT_HAND 2
#define MAT_PARTICLE 3
#define MAT_END_PORTAL 4

// Only used in gbuffer special handle
#define MAT_TORCH 10
#define MAT_GRASS 11
#define MAT_LEAVES 12
#define MAT_BREWING_STAND 14
#define MAT_GLOWING_BERRIES 15
#define MAT_LAVA_CAULDRON 16
#define MAT_CAULDRON 17
#define MAT_LAVA 18
