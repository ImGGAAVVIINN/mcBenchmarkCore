vec4 reflectionFilter(ivec2 centerTexel, vec4 originData, float offset, bool useNoise) {
    float reflectionDepth = texelFetch(colortex5, centerTexel, 0).w;
    float totalSmoothness = 1.0 - sqrt(originData.w);
    float roughnessInv = 100.0 / max(originData.w, 1e-5);
    vec2 coordOffset = vec2(4.0 * offset * clamp(originData.w * 20.0, 0.0, 1.0) * (1.0 - exp(-reflectionDepth * 1000.0)));
    if (useNoise) {
        coordOffset *= blueNoiseTemporal(texcoord).x + 0.5;
    }

    vec3 originNormal = getNormalTexel(centerTexel);

    vec4 accumulation = originData;
    float weightAccumulation = 1.0;
    vec2 centerTexelCoord = centerTexel + 0.5;

    for (int i = -REFLECTION_FILTER; i < REFLECTION_FILTER + 1; i++) {
        for (int j = -REFLECTION_FILTER; j < REFLECTION_FILTER + 1; j++) {
            vec2 sampleTexelCoord = centerTexelCoord + vec2(i, j) * coordOffset;
            ivec2 sampleTexel = ivec2(sampleTexelCoord);
            vec4 sampleData = texelFetch(colortex4, sampleTexel, 0);
            float sampleReflectionDepth = texelFetch(colortex5, sampleTexel, 0).w;
            vec3 sampleNormal = getNormalTexel(sampleTexel);

            float weight =
                exp2(
                    roughnessInv * log2(max(dot(originNormal, sampleNormal), 1e-6)) +
                    100.0 * log2(1.0 - abs(originData.w - sampleData.w)) -
                    1.44269502 * abs(reflectionDepth - sampleReflectionDepth) / (max(reflectionDepth, sampleReflectionDepth) + 0.2) * totalSmoothness
                ) *
                step(0.0025, sampleData.w);
            weight = clamp(weight, 0.0, 1.0);
            if (abs(i) != -abs(j) && all(lessThan(floatBitsToUint(sampleTexelCoord * texelSize), floatBitsToUint(screenEdge)))) {
                accumulation += sampleData * weight;
                weightAccumulation += weight;
            }
        }
    }
    originData = accumulation / weightAccumulation;
    return originData;
}
