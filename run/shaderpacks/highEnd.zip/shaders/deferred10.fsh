#version 330 compatibility

#include "/programs/deferred/Deferred10.frag"
