#version 330 compatibility

#define SKY_COLOR_UP
#define TRANSMITTANCE_LUT

#include "/programs/common/Common.vert"
