#version 330 compatibility

#include "/programs/deferred/Deferred8.frag"
