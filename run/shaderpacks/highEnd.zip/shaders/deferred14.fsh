#version 330 compatibility

#include "/programs/deferred/Deferred14.frag"
