#version 330 compatibility

#include "/programs/deferred/Deferred13.frag"
