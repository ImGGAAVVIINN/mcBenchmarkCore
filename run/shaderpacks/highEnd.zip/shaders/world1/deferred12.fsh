#version 330 compatibility

#define DEFERRED_REFLECTION
#define BASIC_LIGHT 0.01
#define THE_END

#include "/programs/deferred/Deferred12.frag"
