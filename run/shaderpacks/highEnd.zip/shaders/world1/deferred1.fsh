#version 330 compatibility

#define THE_END

#include "/programs/deferred/Deferred1.frag"
