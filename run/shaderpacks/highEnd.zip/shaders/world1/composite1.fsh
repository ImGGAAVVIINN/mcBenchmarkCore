#version 330 compatibility

#define THE_END

#include "/programs/composite/Composite1.frag"
