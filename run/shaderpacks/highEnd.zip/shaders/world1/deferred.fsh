#version 330 compatibility

#define THE_END

#include "/programs/deferred/Deferred0.frag"
