#version 330 compatibility

#define SHADOW_AND_SKY
#define TRANSMITTANCE_LUT

#include "/programs/composite/Composite0.frag"
