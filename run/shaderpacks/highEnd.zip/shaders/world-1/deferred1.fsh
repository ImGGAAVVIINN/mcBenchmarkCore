#version 330 compatibility

#define NETHER

#include "/programs/deferred/Deferred1.frag"
