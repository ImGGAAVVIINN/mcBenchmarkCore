#version 330 compatibility

#define AFTER_SR
#define PREV_HAND_ANIMATION

#include "/programs/common/Common.vert"
