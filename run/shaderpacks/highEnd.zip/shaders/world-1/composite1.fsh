#version 330 compatibility

#define NETHER

#include "/programs/composite/Composite1.frag"
