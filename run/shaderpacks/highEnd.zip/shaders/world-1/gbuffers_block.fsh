#version 330 compatibility

#define BEACON
#define END_PORTAL

#include "/programs/gbuffers/Textured.frag"
