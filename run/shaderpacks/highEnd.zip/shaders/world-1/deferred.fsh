#version 330 compatibility

#define NETHER

#include "/programs/deferred/Deferred0.frag"
