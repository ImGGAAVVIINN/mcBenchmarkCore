#version 330 compatibility

#define BASIC_LIGHT 0.01
#define NETHER

#include "/programs/composite/Composite3.frag"
