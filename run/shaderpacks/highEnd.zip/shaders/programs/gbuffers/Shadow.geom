#extension GL_ARB_shading_language_packing : enable

layout(triangles) in;
layout(triangle_strip, max_vertices = 6) out;

#ifdef SHADOW_AND_SKY
    in vec2 vShadowOffset[];
#endif

in vec4 vColor[];
in vec3 vWorldPos[];
in vec3 vWorldNormal[];
in vec2 vLmcoord[];
in vec2 vTexcoord[];
in vec2 voxelCoordOffset[];
in float edgeCheck[];
in float voxelDepth[];
in float vMaterialID[];
in float vIsEmissive[];
in float vDiscardVoxel[];

out vec4 worldPos;
out vec3 color;
out vec2 texlmcoord;

flat out vec2 midTexCoord;

#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"

const int shadowMapResolution = 4096; // [4096 8192 16384]
const float realShadowMapResolution = shadowMapResolution * MC_SHADOW_QUALITY;

#include "/libs/PathTrace.glsl"

void main() {
    vec2 maxCoord = max(vTexcoord[0], max(vTexcoord[1], vTexcoord[2]));
    vec2 minCoord = min(vTexcoord[0], min(vTexcoord[1], vTexcoord[2]));
    vec2 midCoord = (maxCoord + minCoord) * 0.5;
    #ifdef SHADOW_AND_SKY
        vec3 screenPos0 = vec3(gl_in[0].gl_Position.xy, 0.0);
        vec3 screenPos1 = vec3(gl_in[1].gl_Position.xy, 0.0);
        vec3 screenPos2 = vec3(gl_in[2].gl_Position.xy, 0.0);

        vec2 shadowOffset = vShadowOffset[0];
        vec4 positionOffset = vec4(0.0);
        #ifdef TRANSPARENT
            float isTransparent = 1.0;
            #ifdef ENTITIES
                isTransparent = float(abs(textureLod(gtexture, midCoord + 1e-6, 0.0).w * vColor[0].w - 0.5) + 1e-4 < 0.499);
            #endif
            isTransparent *= float(shadowOffset.y == realShadowMapResolution - 1024.0);
            shadowOffset.x -= isTransparent * 0.5 * realShadowMapResolution;
            positionOffset.x = -isTransparent;
        #endif
        vec2 maxCoordOffset = max(abs(minCoord - 1.0), abs(maxCoord - 1.0));
        shadowOffset.x -= realShadowMapResolution * float(max(maxCoordOffset.x, maxCoordOffset.y) > 1.0);

        gl_Position = gl_in[0].gl_Position + positionOffset;
        color = vColor[0].rgb;
        worldPos = vec4(vWorldPos[0], 0.0);
        texlmcoord = vTexcoord[0];
        midTexCoord = shadowOffset;
        EmitVertex();

        bool front = cross(screenPos1 - screenPos0, screenPos2 - screenPos1).z > 0;

        if (front) {
            gl_Position = gl_in[1].gl_Position + positionOffset;
            color = vColor[1].rgb;
            worldPos = vec4(vWorldPos[1], 0.0);
            texlmcoord = vTexcoord[1];
            midTexCoord = shadowOffset;
            EmitVertex();

            gl_Position = gl_in[2].gl_Position + positionOffset;
            color = vColor[2].rgb;
            worldPos = vec4(vWorldPos[2], 0.0);
            texlmcoord = vTexcoord[2];
        } else {
            gl_Position = gl_in[2].gl_Position + positionOffset;
            color = vColor[2].rgb;
            worldPos = vec4(vWorldPos[2], 0.0);
            texlmcoord = vTexcoord[2];
            midTexCoord = shadowOffset;
            EmitVertex();

            gl_Position = gl_in[1].gl_Position + positionOffset;
            color = vColor[1].rgb;
            worldPos = vec4(vWorldPos[1], 0.0);
            texlmcoord = vTexcoord[1];
        }
        midTexCoord = shadowOffset;
        EmitVertex();

        EndPrimitive();
    #endif

    float discardVoxel = vDiscardVoxel[0] + vDiscardVoxel[1] + vDiscardVoxel[2];
    if (discardVoxel < 2.5) {
        vec3 avgWorldPos = (max(vWorldPos[0], max(vWorldPos[1],  vWorldPos[2])) + min(vWorldPos[0], min(vWorldPos[1],  vWorldPos[2]))) / 2.0;
        vec3 voxelPos = avgWorldPos - vWorldNormal[0] * 0.01 + voxelOffset;
        voxelPos.y -= voxelOriginY;

        float gDiscardVoxel = clamp(dot(step(vec3(voxelizationRadius - 1.0), abs(voxelPos)), vec3(1.0)) + float(edgeCheck[0] + edgeCheck[1] + edgeCheck[2] > 0.5), 0.0, 1.0);
        if (gDiscardVoxel < 0.5) {
            vec3 voxelIndex = floor(voxelPos + voxelizationRadius);
            vec2 voxelTexel = calcVoxelShadowTexel(voxelIndex);
            vec2 voxelCoord = voxelTexel * 2.0 / realShadowMapResolution + 1.0 / realShadowMapResolution - 1.0;

            vec4 voxelData = vec4(0.0, 0.0, 0.0, 2.0);
            float depth = -0.999999;

            if (discardVoxel + gDiscardVoxel < 0.1) {
                float texResolution = TEXTURE_RESOLUTION;
                #if TEXTURE_RESOLUTION == 0
                    vec2 texCoordUnit01 = abs(vTexcoord[0] - vTexcoord[1]) / distance(vWorldPos[0], vWorldPos[1]);
                    vec2 texCoordUnit12 = abs(vTexcoord[1] - vTexcoord[2]) / distance(vWorldPos[1], vWorldPos[2]);
                    vec2 texCoordUnit02 = abs(vTexcoord[0] - vTexcoord[2]) / distance(vWorldPos[0], vWorldPos[2]);
                    vec2 coordUnit = max(texCoordUnit01, max(texCoordUnit12, texCoordUnit02)) * atlasSize;
                    #ifdef MC_ANISOTROPIC_FILTERING
                        coordUnit *= spriteBounds.zw - spriteBounds.xy;
                    #endif
                    texResolution = max(coordUnit.x, coordUnit.y);
                #endif
                uint log2ResolutionU = (floatBitsToUint(texResolution) - 0x3F400000u) >> 23u;
                #ifdef MC_ANISOTROPIC_FILTERING
                    midCoord = midCoord * (spriteBounds.zw - spriteBounds.xy) + spriteBounds.xy;
                #endif
                float isEmissive = vIsEmissive[0];
                float isFullBlockLight = step(2.9999, vLmcoord[0].s + vLmcoord[1].s + vLmcoord[2].s);
                float vertexMaterialID = max(vMaterialID[0], max(vMaterialID[1], vMaterialID[2]));
                #ifdef MOD_LIGHT_DETECTION
                    isEmissive += isFullBlockLight * step(vertexMaterialID, -0.5);
                #endif
                vertexMaterialID = max(0.0, vertexMaterialID);
                depth = max(voxelDepth[0], max(voxelDepth[1], voxelDepth[2])) + isFullBlockLight * 0.1 - log2ResolutionU * 0.001;
                if (abs(vertexMaterialID - 9.0) < 7.5) {
                    vertexMaterialID = min(vMaterialID[0], min(vMaterialID[1], vMaterialID[2]));
                    depth = min(voxelDepth[0], min(voxelDepth[1], voxelDepth[2])) + isFullBlockLight * 0.1;
                }
                if (abs(vertexMaterialID - 179.5) < 8.0) {
                    depth = exp(-distance(vWorldPos[0], avgWorldPos)) + (vWorldNormal[0].x + vWorldNormal[0].z * 0.5) * 1e-4;
                }
                voxelData = vec4(isEmissive, vertexMaterialID, texResolution, 1.0);
            }

            for (int i = 0; i < 3; i++) {
                gl_Position = vec4(voxelCoord + voxelCoordOffset[i], depth, 1.0);

                worldPos = voxelData;
                color = vColor[i].rgb;
                texlmcoord = vLmcoord[i];

                midTexCoord = midCoord;

                EmitVertex();
            }
            EndPrimitive();
        }
    }
}
