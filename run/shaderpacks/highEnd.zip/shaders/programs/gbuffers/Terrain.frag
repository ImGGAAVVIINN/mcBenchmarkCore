#extension GL_ARB_gpu_shader5 : enable
#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 gbufferData0;
layout(location = 1) out vec4 gbufferData1;
layout(location = 2) out vec4 gbufferData2;

in vec4 texlmcoord;
in vec3 color;

flat in uint material;
flat in uvec2 blockData;
flat in vec3 viewNormal;
flat in vec4 skyLightFix;
flat in vec4 coordRange;

#define SKYLIGHT_FIX

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Common.glsl"
#include "/libs/Water.glsl"
#include "/libs/Parallax.glsl"
#include "/libs/GbufferPass.glsl"

#if SR_ENABLE
    uniform float SRRenderScaleLog2;
#endif

void main() {
    GbufferData rawData;

    vec2 albedoTexSize = vec2(atlasSize);
    #ifdef MC_ANISOTROPIC_FILTERING
        albedoTexSize *= spriteBounds.zw - spriteBounds.xy;
    #endif
    vec2 albedoTexelSize = uintBitsToFloat(0x7F000000u - floatBitsToUint(albedoTexSize));

    vec4 viewTangent = vec4(unpackHalf2x16(blockData.x), unpackHalf2x16(blockData.y));
    float tangentLenInv = inversesqrt(dot(viewTangent.xyz, viewTangent.xyz));
    vec3 tangent = viewTangent.xyz;
    vec3 bitangent = cross(viewNormal, tangent) * (signI(viewTangent.w) * tangentLenInv);
    mat3 tbnMatrix = mat3(tangent, bitangent, viewNormal);

    vec3 viewPos = screenToViewPos(gl_FragCoord.st * texelSize, gl_FragCoord.z);
    vec3 worldPos = viewToWorldPos(viewPos) + cameraPosition;
    vec2 lightLevel = texlmcoord.pq;
    #ifdef SKYLIGHT_FIX
        #if MC_VERSION <= 12111
            lightLevel.y = clamp(lightLevel.y + skyLightFix.w - dot(worldPos, skyLightFix.xyz), 0.0, 1.0);
        #endif
    #endif
    vec2 quadSize = 1.0 / coordRange.zw;

    vec2 texGradX = dFdx(texlmcoord.st);
    vec2 texGradY = dFdy(texlmcoord.st);
    #if SR_ENABLE
        texGradX *= renderScale.x;
        texGradY *= renderScale.y;
    #endif
    float parallaxOffset = 0.0;
    vec2 texcoord = texlmcoord.st;
    vec3 anisotropicParam = anisotropicOffsetLod(albedoTexSize, albedoTexelSize, texGradX, texGradY, quadSize);
    #ifdef PARALLAX
        vec3 parallaxTexNormal = vec3(0.0, 0.0, 1.0);
        #if WATER_TYPE == 0 && defined CAULDRON_WAVE
            if ((material >> 1) != MAT_WATER)
        #endif
        {
            vec3 textureViewer = viewPos * tbnMatrix;
            textureViewer.y /= abs(viewTangent.w);
            #ifdef VOXEL_PARALLAX
                texcoord = perPixelParallax(texcoord, textureViewer, albedoTexSize, albedoTexelSize, coordRange, parallaxTexNormal, parallaxOffset);
            #else
                texcoord = calculateParallax(texcoord, textureViewer, coordRange, quadSize, albedoTexSize, albedoTexelSize, parallaxOffset);
            #endif
        }
    #endif
    tbnMatrix[0] *= tangentLenInv;

    #if ANISOTROPIC_FILTERING_QUALITY > 0 && !defined MC_ANISOTROPIC_FILTERING
        vec4 albedoData = anisotropicFilter(texcoord, anisotropicParam.xy, anisotropicParam.z, coordRange, quadSize);
    #else
        vec4 albedoData = textureGrad(gtexture, texcoord, texGradX, texGradY);
    #endif
    if (albedoData.w < alphaTestRef) discard;

    #ifdef MC_NORMAL_MAP
        anisotropicParam.z -= 1.0;
        vec4 normalData = textureLod(normals, texcoord, anisotropicParam.z);
        #ifdef LABPBR_TEXTURE_AO
            albedoData.rgb *= pow(normalData.b, 1.0 / 2.2);
        #endif
    #endif

    albedoData.rgb *= color;
    rawData.albedo = albedoData;
    rawData.lightmap = lightLevel;
    rawData.normal = tbnMatrix[2];
    rawData.geoNormal = tbnMatrix[2];
    rawData.smoothness = 0.0;
    rawData.metalness = 0.0;
    rawData.porosity = 0.0;
    rawData.emissive = 0.0;
    rawData.materialID = MAT_DEFAULT;
    rawData.parallaxOffset = parallaxOffset;
    rawData.depth = 0.0;

    #ifdef MC_SPECULAR_MAP
        vec4 specularData = textureLod(specular, texcoord, 0.0);
        SPECULAR_FORMAT(rawData, specularData);
    #endif

    #ifndef SPECULAR_EMISSIVE
        rawData.emissive = 0.0;
    #endif

    float materialID = float(material >> 1);
    #ifdef HARDCODED_EMISSIVE
        float emissive = clamp(float(material & 1u) - rawData.emissive * 1e+3, 0.0, 1.0);
        if (materialID == MAT_TORCH) {
            emissive *= 0.57 * length(rawData.albedo.rgb);
        }
        else if (materialID == MAT_BREWING_STAND) {
            emissive *= clamp(1.5 * rawData.albedo.r - 2.0 * rawData.albedo.b, 0.0, 1.0);
        }
        else if (materialID == MAT_GLOWING_BERRIES) {
            emissive *= clamp(2.0 * rawData.albedo.r - 1.5 * rawData.albedo.g, 0.0, 1.0);
        }
        rawData.emissive += emissive;
    #endif
    bool isCauldronWater = materialID == MAT_WATER;
    rawData.smoothness += float(rawData.smoothness < 1e-3 && isCauldronWater);

    #ifdef MOD_LIGHT_DETECTION
        if (rawData.lightmap.x > 0.99999) {
            rawData.emissive += float(rawData.emissive < 1e-3 && materialID < 0.5);
        }
    #endif

    #ifndef LABPBR_POROSITY
        rawData.porosity = 0.0;
    #endif

    rawData.porosity +=
        clamp(1.0 - rawData.porosity * 1e+3, 0.0, 1.0) *
        (0.5 * float(materialID == MAT_GRASS) + 0.7 * float(materialID == MAT_LEAVES || materialID == MAT_GLOWING_BERRIES));

    float wetStrength = 0.0;
    vec3 rippleNormal = vec3(0.0, 0.0, 1.0);
    float viewDepthInv = inversesqrt(dot(viewPos, viewPos));
    vec3 viewDir = viewPos * (-viewDepthInv);
    if (rainyStrength > 0.0 && materialID != MAT_LAVA) {
        float porosity = rawData.porosity * 255.0 / 64.0;
        porosity *= step(porosity, 1.0);
        float outdoor = clamp(15.0 * rawData.lightmap.y - 14.0, 0.0, 1.0);

        float porosityDarkness = porosity * outdoor * rainyStrength;
        rawData.albedo.rgb = pow(rawData.albedo.rgb, vec3(1.0 + porosityDarkness)) * (1.0 - 0.2 * porosityDarkness);

        vec3 worldNormal = mat3(gbufferModelViewInverse) * rawData.geoNormal;
        #if RAIN_PUDDLE == 1
            wetStrength = (1.0 - rawData.metalness) * clamp(worldNormal.y * 10.0 - 0.1, 0.0, 1.0) * outdoor * rainyStrength * (1.0 - porosity);
        #elif RAIN_PUDDLE == 2
            wetStrength = groundWetStrength(worldPos, worldNormal.y, rawData.metalness, porosity, outdoor);
        #endif
        rawData.smoothness += (1.0 - rawData.smoothness) * wetStrength;

        #ifdef RAIN_RIPPLES
            rippleNormal = rainRippleNormal(worldPos);
            rippleNormal.xy *= viewDepthInv / (viewDepthInv + 0.1 * RIPPLE_FADE_SPEED);
        #endif
    }
    rawData.lightmap = clamp(rawData.lightmap + blueNoiseTemporal(gl_FragCoord.st * texelSize).xy * 2.0 / 255.0 - 1.0 / 255.0, 0.0, 1.0) * clamp(rawData.lightmap * 500.0, 0.0, 1.0);

    vec2 quadTexelSize = albedoTexelSize * quadSize;
    vec2 pixelScale = vec2(tangentLenInv, abs(viewTangent.w)) * albedoTexelSize;
    float curveStart = dot(viewDir, tbnMatrix[2]);
    #ifdef PARALLAX
        #if (defined VOXEL_PARALLAX) || (defined PARALLAX_BASED_NORMAL)
            if (rawData.parallaxOffset > 0.0
                #ifdef VOXEL_PARALLAX
                    && parallaxTexNormal.z < 0.5
                #endif
            ) {
                #ifdef VOXEL_PARALLAX
                    rawData.normal = tbnMatrix * parallaxTexNormal;
                #else
                    #ifdef SMOOTH_PARALLAX
                        rawData.normal = heightBasedNormal(normals, texcoord, coordRange, quadTexelSize, albedoTexSize, pixelScale);
                    #else
                        const float eps = 1e-4;
                        vec2 tileCoord = (texcoord - coordRange.xy) * quadSize;
                        float rD = textureLod(normals, clampCoordRange(tileCoord + vec2(eps * quadTexelSize.x, 0.0), coordRange), anisotropicParam.z).a;
                        float lD = textureLod(normals, clampCoordRange(tileCoord - vec2(eps * quadTexelSize.x, 0.0), coordRange), anisotropicParam.z).a;
                        float uD = textureLod(normals, clampCoordRange(tileCoord + vec2(0.0, eps * quadTexelSize.y), coordRange), anisotropicParam.z).a;
                        float dD = textureLod(normals, clampCoordRange(tileCoord - vec2(0.0, eps * quadTexelSize.y), coordRange), anisotropicParam.z).a;
                        rawData.normal = vec3((lD - rD), (dD - uD), step(abs(lD - rD) + abs(dD - uD), 1e-3));
                    #endif
                    rawData.normal = mix(rawData.normal, rippleNormal, wetStrength);
                    rawData.normal = normalize(tbnMatrix * rawData.normal);
                #endif
                texGradX *= albedoTexSize;
                texGradY *= albedoTexSize;
                float fadeFactor = viewDepthInv * curveStart * gbufferProjection[1].y * screenSize.y;
                rawData.normal = mix(tbnMatrix[2], rawData.normal, fadeFactor / (fadeFactor + 15.0));
            }
            else
        #endif
    #endif
    {
        #ifdef CAULDRON_WAVE
            #if WATER_TYPE == 0
                if (isCauldronWater) {
                    rawData.albedo = vec4(color.rgb * 0.2, 1.0);
                    vec3 tangentDir = viewPos * tbnMatrix;
                    rawData.normal = waterWave(worldPos / 32.0, tangentDir);
                    rawData.normal.xy += rippleNormal.xy * wetStrength;
                    rawData.smoothness = 1.0;
                    rawData.metalness = 0.0;
                    rawData.porosity = 0.0;
                    rawData.emissive = 0.0;
                }
                else
            #endif
        #endif
        {
            #ifdef SMOOTH_NORMAL
                normalData = bilinearNormalSample(normals, texcoord, coordRange, quadTexelSize, albedoTexSize);
            #endif
            #ifdef MC_NORMAL_MAP
                rawData.normal = NORMAL_FORMAT(normalData.xyz);
                rawData.normal.xy *= NORMAL_STRENGTH;
            #else
                rawData.normal = vec3(0.0, 0.0, 1.0);
            #endif
            rawData.normal = mix(rawData.normal, rippleNormal, wetStrength);
        }
        rawData.normal = normalize(tbnMatrix * rawData.normal);

        float NdotV = dot(rawData.normal, viewDir);
        vec3 edgeNormal = rawData.normal - viewDir * NdotV;
        float weight = clamp(curveStart - curveStart * exp(NdotV / curveStart - 1.0), 0.0, 1.0);
        weight = max(NdotV, curveStart) - weight;
        rawData.normal = viewDir * weight + edgeNormal * max(0.0, inversesqrt(dot(edgeNormal, edgeNormal) / (1.0 - weight * weight)));
    }

    packUpGbufferDataSolid(rawData, gbufferData0, gbufferData1, gbufferData2);
}

/* DRAWBUFFERS:012 */
