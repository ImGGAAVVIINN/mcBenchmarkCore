flat out vec4 color;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"

void main() {
    color = gl_Color;
    gl_Position = ftransform();

    #if SR_ENABLE
        gl_Position.xy = gl_Position.xy * renderScale + (renderScale - 1.0) * gl_Position.w;
    #endif

    #ifdef TAA
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
}
