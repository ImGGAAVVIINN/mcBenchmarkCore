#if MC_VERSION >= 11700
in vec4 mc_Entity;
in vec3 vaPosition;
#elif MC_VERSION >= 11500
layout(location = 11) in vec4 mc_Entity;
#else
layout(location = 10) in vec4 mc_Entity;
#endif

#ifdef SHADOW_AND_SKY
    out vec2 vShadowOffset;
#endif

out vec4 vColor;
out vec3 vWorldPos;
out vec3 vWorldNormal;
out vec2 vLmcoord;
out vec2 vTexcoord;
out vec2 voxelCoordOffset;
out float edgeCheck;
out float voxelDepth;
out float vMaterialID;
out float vIsEmissive;
out float vDiscardVoxel;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/PhysicsOcean.glsl"

const int shadowMapResolution = 4096; // [4096 8192 16384]
const float realShadowMapResolution = shadowMapResolution * MC_SHADOW_QUALITY;

uniform ivec2 eyeBrightness;

void main() {
    vColor = gl_Color;
    vWorldNormal = normalize(mat3(shadowModelViewInverse) * gl_NormalMatrix * gl_Normal);
    vTexcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    vLmcoord = gl_MultiTexCoord1.st / 240.0;
    #ifdef IS_IRIS
        vLmcoord = clamp(gl_MultiTexCoord1.st / 232.0 - 8.0 / 232.0, 0.0, 1.0);
    #endif
    vIsEmissive = step(511.5, mc_Entity.x);
    vMaterialID = mc_Entity.x - step(1.5, mc_Entity.x) - 511.0 * vIsEmissive;
    vMaterialID *= float(mc_Entity.x != 2);
    #ifdef PHYSICS_OCEAN
        float physics_localWaviness = texelFetch(physics_waviness, ivec2(gl_Vertex.xz) - physics_textureOffset, 0).r;
        vec3 physics_localPosition = gl_Vertex.xyz + vec3(0.0, physics_waveHeight(gl_Vertex.xz, PHYSICS_ITERATIONS_OFFSET, physics_localWaviness, physics_gameTime), 0.0);

        vec3 viewPos = mat3(gl_ModelViewMatrix) * physics_localPosition + gl_ModelViewMatrix[3].xyz;
    #else
        vec3 viewPos = mat3(gl_ModelViewMatrix) * gl_Vertex.xyz + gl_ModelViewMatrix[3].xyz;
    #endif
    vWorldPos = mat3(shadowModelViewInverse) * viewPos + shadowModelViewInverse[3].xyz;

    vDiscardVoxel = 0.0;
    voxelDepth = -0.5;
    #ifdef IS_IRIS
        vec3 vertexPos = gl_Vertex.xyz + cameraPositionFract;
    #elif MC_VERSION >= 11700
        vec3 vertexPos = vaPosition;
    #else
        vec3 vertexPos = gl_Vertex.xyz;
    #endif
    vec3 absNormal = abs(gl_Normal);
    float normalCheck = step(0.9, max(absNormal.x, max(absNormal.y, absNormal.z)));
    edgeCheck = step(0.4, dot(abs(floor(vertexPos - gl_Normal * 3e-5) - floor(vertexPos - gl_Normal * 0.01)), absNormal));
    vec3 blockPos = abs(fract(vertexPos) - 0.5);
    float isNoCubik = 1.0 - normalCheck * step(0.49, min(blockPos.x, min(blockPos.y, blockPos.z)));
    voxelDepth += step(mc_Entity.x, 0.5) * 0.6;
    voxelDepth += (isNoCubik + 1.0 - normalCheck) * 0.25;
    voxelDepth += abs(eyeBrightness.y - gl_MultiTexCoord1.t) / 240.0 * 0.1;
    if (mc_Entity.x < 1.5) {
        vDiscardVoxel = isNoCubik;
    }
    else if (vMaterialID == 118) {
        if (vIsEmissive < 0.5) {
            voxelDepth -= 0.1 * float(abs(gl_Normal.y) < 0.5) + 0.1 * float(abs(min(blockPos.x, min(blockPos.y, blockPos.z)) - 5.0 / 16.0) < 0.5 / 16.0);
        } else {
            voxelDepth -= 0.1 * float(gl_Normal.y > 0.5) + 0.1 * float(abs(blockPos.y - 7.0 / 16.0) < 0.5 / 16.0);
        }
    }
    else if (mc_Entity.x == 149) {
        vec3 pixelPos = abs(fract(vertexPos * 16.0) - 0.5);
        vDiscardVoxel = step(max(pixelPos.x, max(pixelPos.y, pixelPos.z)), 0.49);
    }
    else if (abs(vMaterialID - 154.5) < 2.0) {
        vDiscardVoxel = step(gl_Normal.y, 0.5);
    }
    else if (mc_Entity.x == 514) {
        float height = floor(fract(vertexPos.y + 0.4 / 16.0) * 16.0);
        voxelDepth = height * (0.3 / 16.0) + 0.3 * float(height < 0.5) - float(absNormal.y > 0.01);
        vMaterialID = vMaterialID - 1.0 + height;
    }
    else if (abs(mc_Entity.x - 1536.0) < 512.5) {
        vMaterialID = 168.0;
        if (abs(mc_Entity.x - 1025.5) < 2.0) {
            vColor.rgb = vec3(.8,1.,.8) * (mc_Entity.x - 1023.0) * 0.25;
        }
        if (abs(mc_Entity.x - 1035.0) < 7.5) {
            vColor.rgb = commonLightColor * inversesqrt(dot(commonLightColor, commonLightColor) / ((mc_Entity.x - 1027.0) * 0.06));
        }
    }
    #ifdef IS_IRIS
        else if (abs(vMaterialID - 159.5) < 1.0) {
            voxelDepth -= 0.2 * float(abs(fract(vertexPos.y) - 1.0 / 16.0) < 0.5 / 16.0);
        }
    #endif
    vDiscardVoxel = clamp(vDiscardVoxel + step(255.5, vMaterialID), 0.0, 1.0);

    ivec2 corner;
    corner.y = (gl_VertexID & 2) >> 1;
    corner.x = (corner.y + gl_VertexID) & 1;
    corner = (1 - corner) << 31;
    voxelCoordOffset = intBitsToFloat(floatBitsToInt(1.0 / realShadowMapResolution) | corner);

    #ifdef SHADOW_AND_SKY
        vShadowOffset = vec2(0.0, 0.0);
        #ifdef TRANSPARENT
            bool isWater = mc_Entity.x == 264;
            if (isWater) {
                vColor.r = 0.98 - pow(1.0 - clamp(abs(dot(shadowModelViewInverse[2].xyz, vWorldNormal)), 0.0, 1.0), 5.0) * 0.98;
            }
            float isWaterF = float(isWater);
            vShadowOffset.y = -isWaterF;
        #endif

        gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
        float clipLengthInv = inversesqrt(dot(gl_Position.xy, gl_Position.xy));
        float shadowDistortion = log(distortionStrength / clipLengthInv + 1.0) / log(distortionStrength + 1.0) * (2048 / realShadowMapResolution);
        gl_Position.xy *= max(0.0, clipLengthInv * shadowDistortion);
        gl_Position.xy = gl_Position.xy + (realShadowMapResolution - 2048) / realShadowMapResolution + vShadowOffset;
        gl_Position.z *= 0.2;

        vShadowOffset = vShadowOffset * 0.5 * realShadowMapResolution + vec2(realShadowMapResolution - 1024.0);
    #else
        gl_Position = vec4(0.0, 0.0, 0.0, 1.0);
    #endif
}
