#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer5;

#ifdef SHADOW_AND_SKY
    in vec3 skyColorUp;
#endif

in vec2 texcoord;

#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/ReflectionFilter.glsl"

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);
    float waterDepth = texelFetch(depthtex0, texel, 0).r;
    vec3 solidColor = texelFetch(colortex5, texel, 0).rgb;

    vec4 mirrorWeight = texelFetch(colortex2, texel, 0);
    #ifdef REFLECTION
        if (waterDepth < texelFetch(depthtex1, texel, 0).r) {
            vec4 reflectionColor = texelFetch(colortex4, texel, 0);
            #if REFLECTION_FILTER > 0
                if (reflectionColor.w > 0.0025) {
                    reflectionColor.rgb = reflectionFilter(texel, reflectionColor, 1.0, true).rgb;
                }
            #endif

            solidColor += reflectionColor.rgb * mirrorWeight.rgb;
        }
    #endif
    float parallaxOffset = mirrorWeight.w * PARALLAX_DEPTH * 0.2;

    #ifdef SHADOW_AND_SKY
        float weatherData = texelFetch(colortex0, texel, 0).w;
        weatherData = weatherData * 2.5 - 1.5;
        float weatherLightData = abs(weatherData);
        if (weatherLightData > 0.3) {
            float sunlightStrength = 2.0 * weatherLightData - 1.0;
            float basicSunlight = (1.0 - sqrt(weatherStrength)) * 8.0 * SUNLIGHT_BRIGHTNESS;
            vec3 weatherLight = sunlightStrength * basicSunlight * sunColor + skyColorUp * (1.0 - 0.8 * weatherStrength);
            float weatherBlendWeight = clamp(weatherData * 1e+10, 0.0, 1.0) * 0.8 + 0.2;
            solidColor = mix(solidColor, weatherLight, weatherBlendWeight);
        }
    #endif

    texBuffer5 = vec4(solidColor.rgb, parallaxOffset);
}

/* DRAWBUFFERS:5 */
