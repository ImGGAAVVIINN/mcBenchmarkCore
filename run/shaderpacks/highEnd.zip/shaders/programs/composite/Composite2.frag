#extension GL_ARB_gpu_shader5 : enable
#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer4;
layout(location = 1) out vec4 texBuffer5;

in vec2 texcoord;
in vec3 skyColorUp;

#include "/settings/CloudSettings.glsl"
#include "/settings/GlobalSettings.glsl"
#include "/settings/VolumetricLightSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/Atmosphere.glsl"
#include "/libs/Cloud.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Shadow.glsl"
#include "/libs/VolumetricLight.glsl"

void main() {
    float absorption = 1.0;
    vec3 volumetricLight = vec3(0.0);

    if (isEyeInWater < 2) {
        float waterDepth = textureLod(depthtex0, texcoord, 0.0).r;
        vec3 waterViewPos;
        #ifdef LOD
            if (waterDepth == 1.0) {
                waterDepth = getLodDepthWater(texcoord);
                waterViewPos = screenToViewPosLod(texcoord, waterDepth);
            } else
        #endif
        {
            waterViewPos = screenToViewPos(texcoord, waterDepth);
        }
        vec3 waterWorldPos = mat3(gbufferModelViewInverse) * waterViewPos;
        float waterWorldDistanceInv = inversesqrt(dot(waterViewPos, waterViewPos));
        vec3 waterWorldDir = waterWorldDistanceInv * waterWorldPos;

        float basicWeight = 1.0;
        vec3 absorptionBeta = vec3(blindnessFactor + 0.003);
        float airScattering = VL_STRENGTH;
        float LdotV = dot(waterWorldDir, shadowDirection);
        float volumetricFogScattering = 0.0;
        if (isEyeInWater == 1) {
            absorptionBeta = waterAbsorptionBeta + 0.003;
            basicWeight = 10.0 * WATER_VL_STRENGTH;
            airScattering *= rayleighPhase(LdotV);
        }
        else {
            float timeStrength = pow(clamp(1.0 - shadowDirection.y, 0.0, 1.0), 5.0);
            float heightDensity = clamp(exp(-(cameraPosition.y + WORLD_BASIC_HEIGHT) / 1200.0), 0.0, 1.0);
            float timeVLStrength = (timeStrength * (MORNING_VL_STRENGTH - NOON_VL_STRENGTH) + NOON_VL_STRENGTH) * heightDensity;
            basicWeight = timeVLStrength;
            airScattering *= miePhase(LdotV, 0.6, 0.36);

            volumetricFogScattering = heightDensity * VOLUMETRIC_FOG_DENSITY * (timeStrength * (VOLUMETRIC_FOG_MORNING_DENSITY - VOLUMETRIC_FOG_NOON_DENSITY) + VOLUMETRIC_FOG_NOON_DENSITY);
        }

        float noise = bayer64Temporal(gl_FragCoord.xy);
        float maxHorizonalRange = far + 32.0;
        float maxVerticalRange = min(far, max(cameraPosition.y + 64.0, 320.0 - cameraPosition.y) * 2.0) + 32.0;
        #ifdef LOD
            maxHorizonalRange = lodRenderDistance() * 1.1;
        #endif
        float waterWorldDirY2 = waterWorldDir.y * waterWorldDir.y;
        float maxAllowedDistance = maxHorizonalRange * maxVerticalRange * inversesqrt(pow2(maxHorizonalRange) * waterWorldDirY2 + pow2(maxVerticalRange) * (1.0 - waterWorldDirY2));
        maxAllowedDistance = min(maxAllowedDistance, 5000.0 * exp(-6.0 * length(absorptionBeta)));

        vec3 target = waterWorldPos * clamp(maxAllowedDistance * waterWorldDistanceInv, 0.0, 1.0);
        vec3 stepSize = target / VL_SAMPLES;
        vec3 samplePos = gbufferModelViewInverse[3].xyz + stepSize * noise;
        float stepLength = length(stepSize);

        basicWeight *= stepLength;
        absorptionBeta *= stepLength * 1.44269502;
        vec3 rayAbsorption = exp2(-absorptionBeta * noise) * basicWeight * 0.02;
        #ifdef LIGHT_LEAKING_FIX
            rayAbsorption *= pow(clamp(eyeBrightnessSmooth.y / 240.0 + 1e-4 + float(isEyeInWater == 1), 0.0, 1.0), exp(-0.5 * stepLength));
        #endif
        vec3 stepAbsorption = exp2(-absorptionBeta);
        vec3 skyScattering = (sunColor * SUNLIGHT_BRIGHTNESS * 2.0 + skyColorUp) * eyeBrightnessSmooth.y / 1000.0;
        stepLength *= -0.01 * 1.44269502 / max(1e-5, basicWeight);
        for (int i = 0; i < VL_SAMPLES; i++) {
            vec3 singleLight = vec3(1.0);
            #ifdef CLOUD_SHADOW
                singleLight *= cloudShadow(samplePos, shadowDirection);
            #endif
            vec3 sampleShadowCoord = worldPosToShadowCoord(samplePos);
            if (all(lessThan(
                abs(sampleShadowCoord - vec3(vec2(1.0 - 1024 / realShadowMapResolution), 0.5)),
                vec3(vec2(1024 / realShadowMapResolution), 0.5))
            )) {
                float solidShadowStrength = textureLod(shadowtex0, sampleShadowCoord, 2.0);
                singleLight *= vec3(solidShadowStrength);
                sampleShadowCoord.y -= 0.5;
                vec3 caustic = waterCaustic(sampleShadowCoord, samplePos, shadowDirection, 2.0);
                singleLight *= caustic;
                #ifdef TRANSPARENT_SHADOW
                    sampleShadowCoord.xy += vec2(-0.5, 0.5);
                    float transparentShadowStrength = textureLod(shadowtex0, sampleShadowCoord, 2.0);
                    if (transparentShadowStrength < 1.0) {
                        vec4 transparentShadowColor = textureLod(shadowcolor0, sampleShadowCoord.st, 2.0);
                        transparentShadowColor.rgb = pow(
                            transparentShadowColor.rgb * (1.0 - 0.5 * pow2(transparentShadowColor.w)),
                            vec3(sqrt(transparentShadowColor.w * 2.2 * 2.2 * 1.5) + 1e-6)
                        );
                        singleLight *= mix(transparentShadowColor.rgb, vec3(1.0), vec3(transparentShadowStrength));
                    }
                #endif
            }
            singleLight *= sunColor * SUNLIGHT_BRIGHTNESS;
            #ifdef VOLUMETRIC_FOG
                float sampleVolumetricFogDensity = volumetricFogDensity(samplePos) * volumetricFogScattering;
                singleLight *= sampleVolumetricFogDensity * 5.0 + airScattering;
                singleLight += sampleVolumetricFogDensity * skyScattering;
            #else
                singleLight *= airScattering;
            #endif
            singleLight *= rayAbsorption;
            #ifdef VOLUMETRIC_FOG
                float volumetricFogAbsorption = exp2(stepLength * sampleVolumetricFogDensity);
                rayAbsorption *= volumetricFogAbsorption;
                absorption *= volumetricFogAbsorption;
            #endif
            rayAbsorption *= stepAbsorption;
            volumetricLight += singleLight;
            samplePos += stepSize;
        }
    }
    ivec2 texel = ivec2(gl_FragCoord.st);
    vec4 solidColor = texelFetch(colortex5, texel, 0);
    solidColor.rgb = solidColor.rgb * absorption + volumetricLight;
    vec4 absorptionData = texelFetch(colortex4, texel, 0);
    absorptionData.rgb *= absorption;
    texBuffer4 = absorptionData;
    texBuffer5 = solidColor;
}

/* DRAWBUFFERS:45 */
