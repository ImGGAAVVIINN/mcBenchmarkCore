#extension GL_ARB_gpu_shader5 : enable
#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer0;
layout(location = 1) out vec4 texBuffer4;
layout(location = 2) out vec4 texBuffer5;

in vec2 texcoord;

#define REFRACTION_STRENGTH 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.2 2.4 2.6 2.8 3.0 3.2 3.4 3.6 3.8 4.0 4.2 4.4 4.6 4.8 5.0 5.5 6.0 6.5 7.0 7.5 8.0 9.5 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define REFRACTION_EDGE_FADE 0.5 // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

#include "/settings/CloudSettings.glsl"
#include "/settings/GlobalSettings.glsl"
#include "/settings/VolumetricLightSettings.glsl"

#ifdef SHADOW_AND_SKY
    in vec3 skyColorUp;
#else
    const vec3 skyColorUp = vec3(0.0);
#endif

#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/Atmosphere.glsl"
#include "/libs/Cloud.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Shadow.glsl"
#include "/libs/VolumetricLight.glsl"
#ifdef THE_END
    #include "/libs/Galaxy.glsl"
#endif

void main() {
    ivec2 texel = ivec2(gl_FragCoord.st);
    GbufferData gbufferData = getGbufferData(texel, texcoord);
    float waterDepth = textureLod(depthtex0, texcoord, 0.0).r;
    float solidDepth = gbufferData.depth;
    vec4 solidColor = texelFetch(colortex5, texel, 0);
    vec3 viewPos;
    #ifdef LOD
        if (solidDepth == 1.0) {
            solidDepth = getLodDepthSolid(texcoord);
            viewPos = screenToViewPosLod(texcoord, solidDepth);
            solidDepth += 1.0;
        } else
    #endif
    {
        viewPos = screenToViewPos(texcoord, solidDepth);
    }
    vec3 waterViewPos;
    #ifdef LOD
        if (waterDepth == 1.0) {
            waterDepth = getLodDepthWater(texcoord);
            waterViewPos = screenToViewPosLod(texcoord, waterDepth);
            waterDepth += 1.0;
        } else
    #endif
    {
        waterViewPos = screenToViewPos(texcoord, waterDepth);
    }
    vec3 worldPos = mat3(gbufferModelViewInverse) * viewPos;
    float worldDistanceInv = inversesqrt(dot(worldPos, worldPos));
    vec3 waterWorldDir = worldPos * worldDistanceInv;

    float waterViewDepthNoLimit = length(waterViewPos);

    texBuffer0 = vec4(0.0, 0.0, texelFetch(colortex4, texel, 0).zw);

    /********************************************************** Water Refraction **********************************************************/

    float f0 = 0.04;
    if (waterDepth < solidDepth) {
        vec3 worldDir = waterWorldDir;
        vec3 waterWorldPos = waterWorldDir * waterViewDepthNoLimit + gbufferModelViewInverse[3].xyz;
        texBuffer0.b = gbufferData.materialID / 255.0;
        bool isTargetWater = gbufferData.materialID == MAT_WATER;
        bool isTargetNotParticle = gbufferData.materialID != MAT_PARTICLE;
        vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.normal);
        vec3 worldGeoNormal = mat3(gbufferModelViewInverse) * gbufferData.geoNormal;
        float LdotH = clamp(dot(-worldNormal, waterWorldDir), 0.0, 1.0);
        vec3 stainedColor = vec3(0.0);
        if (isTargetNotParticle) {
            stainedColor += gbufferData.smoothness * gbufferData.smoothness;
            float refractionStrength = REFRACTION_STRENGTH * 4e-2 * clamp((1.0 - waterViewDepthNoLimit * worldDistanceInv) / (waterViewDepthNoLimit * worldDistanceInv + worldDistanceInv), 0.0, 1.0);

            float roughness = 1.0 - gbufferData.smoothness;
            vec2 blueNoise = textureLod(noisetex, texcoord * screenSize / 64.0, 0.0).xy;
            vec2 randomOffset = vec2(cos(blueNoise.x * 2.0 * PI), sin(blueNoise.x * 2.0 * PI)) * blueNoise.y;
            float k = sqrt(1.5 * 1.5 - (1.0 - LdotH * LdotH));
            vec3 refractDirection = normalize(
                viewPos * worldDistanceInv - (LdotH + k) * gbufferData.normal +
                (dot(-worldGeoNormal, waterWorldDir) + k) * gbufferData.geoNormal * float(isTargetWater) // Get this idea from zombye/spectrum, MIT Licence
            );
            vec2 refractionOffset = (refractDirection.xy - viewPos.xy / viewPos.z * refractDirection.z + roughness * randomOffset) * refractionStrength * screenEdge;
            refractionOffset.x *= screenSize.y * texelSize.x;
            vec2 screenEdgeIntersection = mix(texcoord, screenEdge - texcoord, clamp(refractionOffset * 1e+20, 0.0, 1.0)) / abs(refractionOffset);
            float screenEdgeLength = min(screenEdgeIntersection.x, screenEdgeIntersection.y);
            if (screenEdgeLength < 1.0 / (1.0 - REFRACTION_EDGE_FADE)) {
                refractionOffset *= screenEdgeLength + pow2(REFRACTION_EDGE_FADE * screenEdgeLength) / (-1.0 + (1.0 - 2.0 * REFRACTION_EDGE_FADE) * screenEdgeLength);
            }

            vec2 refractionTarget = texcoord + refractionOffset;
            float targetSolidDepth = textureLod(depthtex1, refractionTarget, 0.0).r;
            #ifdef LOD
                targetSolidDepth += float(targetSolidDepth == 1.0) * getLodDepthSolid(refractionTarget);
            #endif
            if (waterDepth < targetSolidDepth) {
                solidDepth = targetSolidDepth;
                solidColor.rgb = texelFetch(colortex5, ivec2(refractionTarget * screenSize), 0).rgb;
                vec3 viewPos;
                #ifdef LOD
                    if (targetSolidDepth > 1.0) {
                        viewPos = screenToViewPosLod(refractionTarget, targetSolidDepth - 1.0);
                    } else
                #endif
                {
                    viewPos = screenToViewPos(refractionTarget, targetSolidDepth);
                }
                worldPos = mat3(gbufferModelViewInverse) * viewPos;
                worldDistanceInv = inversesqrt(dot(worldPos, worldPos));
                worldDir = worldPos * worldDistanceInv;
            }
        }

        float waterDistance = distance(worldPos + gbufferModelViewInverse[3].xyz, waterWorldPos);
        vec3 rawSolidColor = solidColor.rgb;
        f0 -= 0.02 * float(isTargetWater);
        #ifdef LABPBR_F0
            f0 = mix(f0, gbufferData.metalness , step(0.001, gbufferData.metalness));
            gbufferData.metalness = step(229.5 / 255.0, gbufferData.metalness);
        #endif
        #ifdef LOD
            solidDepth -= float(solidDepth > 1.0);
        #endif
        waterDistance = mix(waterDistance, 114514.0, step(0.999999, solidDepth));
        if (isEyeInWater == 1 ^^ isTargetWater) {
            solidColor.rgb = waterFogTotal(solidColor.rgb, worldDir, skyColorUp, waterDistance, gbufferData.lightmap.y);
        }
        else if (isEyeInWater == 2) {
            solidColor.rgb = lavaFogTotal(solidColor.rgb, waterDistance);
        }
        else if (isEyeInWater == 3) {
            solidColor.rgb = snowFogTotal(solidColor.rgb, skyColorUp, waterDistance, gbufferData.lightmap.y);
        }
        else {
            #ifdef NETHER
                solidColor.rgb = netherFogTotal(solidColor.rgb, waterDistance);
            #elif defined THE_END
                solidColor.rgb = endFogTotal(solidColor.rgb, waterDistance);
                if (solidDepth > 0.999999)
                    solidColor.rgb += endStars(worldDir);
            #else
                float atmosphereDepth = mix(waterDistance * (1.0 + RF_GROUND_EXTRA_DENSITY * 3.0 * weatherStrength), 1600.0, step(0.999999, solidDepth));
                #if defined ATMOSPHERE_SCATTERING_FOG && defined SHADOW_AND_SKY
                    solidColor.rgb = solidAtmosphereScattering(solidColor.rgb, worldDir, skyColorUp, atmosphereDepth, gbufferData.lightmap.y);
                #endif
                solidColor.rgb *= airAbsorption(waterDistance);
            #endif
            f0 -= f0 * 2.0 * float(isTargetWater);
        }
        float waterStain = 1.0;
        #if WATER_TYPE == 0
            waterStain = float(!isTargetWater);
        #endif
        stainedColor *= log2(1.0 - fresnel(LdotH, mix(vec3(f0), gbufferData.albedo.rgb, gbufferData.metalness)));
        stainedColor += sqrt(gbufferData.albedo.w * 1.5) * log2(clamp(gbufferData.albedo.rgb + 1e-5, 0.0, 1.0) * (1.0 - 0.5 * gbufferData.albedo.w * gbufferData.albedo.w)) * waterStain;
        stainedColor = exp2(stainedColor);

        stainedColor = mix(vec3(1.0), stainedColor, vec3(solidColor.w));
        solidColor.rgb = mix(rawSolidColor, solidColor.rgb, vec3(solidColor.w)) * stainedColor;

        float isTargetParticle = 1.0 - float(isTargetNotParticle);
        vec3 vanillaLight = pow2(gbufferData.lightmap.y) * (skyColorUp + sunColor * SUNLIGHT_BRIGHTNESS) * (1.0 - gbufferData.metalness) * (1.0 - 0.8 * weatherStrength) * isTargetParticle;
        vec3 volumetricLight = gbufferData.albedo.rgb * gbufferData.albedo.w * (gbufferData.emissive * BLOCK_LIGHT_BRIGHTNESS * PI + vanillaLight);

        #ifdef SHADOW_AND_SKY
            float NdotL = clamp(dot(worldNormal, shadowDirection) + isTargetParticle, 0.0, 1.0);
            float shadowLightFactor = 1.0;
            #ifdef LIGHT_LEAKING_FIX
                shadowLightFactor = clamp(gbufferData.lightmap.y * 10.0, 0.0, 1.0);
            #endif
            vec3 shadow = vec3(1.0);
            vec3 subsurfaceScattering = vec3(float(gbufferData.porosity > 64.5 / 255.0));
            directShadow(
                waterWorldPos, worldGeoNormal, NdotL, shadowLightFactor, gbufferData.smoothness,
                gbufferData.porosity, gbufferData.lightmap.y, 0.0, shadow, subsurfaceScattering
            );
            shadow *= (1.0 - gbufferData.metalness) * gbufferData.albedo.rgb * gbufferData.albedo.w * isTargetParticle + sunlightSpecular(
                waterWorldDir, shadowDirection, worldNormal, gbufferData.smoothness * 0.995, NdotL, LdotH, vec3(f0), vec3(1.0)
            ) * airAbsorption(11.4 * gbufferData.smoothness) * clamp(19.0 - gbufferData.smoothness * 20.0, 0.0, 1.0);
            shadow += subsurfaceScattering * (1.0 - gbufferData.metalness) * gbufferData.albedo.rgb * gbufferData.albedo.w * isTargetParticle;
            #ifdef CLOUD_SHADOW
                shadow *= cloudShadow(waterWorldPos, shadowDirection);
            #endif
            shadow *= sunColor;
            volumetricLight += shadow;

            #ifdef VOLUMETRIC_LIGHT
                float basicWeight = 1.0;
                vec3 absorptionBeta = vec3(blindnessFactor + 0.003);
                float LdotV = dot(worldDir, shadowDirection);
                float airScattering = VL_STRENGTH;
                float volumetricFogScattering = 0.0;
                if ((isEyeInWater == 0) ^^ isTargetWater) {
                    float timeStrength = pow(clamp(1.0 - shadowDirection.y, 0.0, 1.0), 5.0);
                    float timeVLStrength = timeStrength * (MORNING_VL_STRENGTH - NOON_VL_STRENGTH) + NOON_VL_STRENGTH;
                    float heightDensity = clamp(exp(-(cameraPosition.y + WORLD_BASIC_HEIGHT) / 1200.0), 0.0, 1.0);
                    basicWeight *= timeVLStrength * heightDensity;
                    airScattering *= miePhase(LdotV, 0.6, 0.36);

                    volumetricFogScattering = heightDensity * VOLUMETRIC_FOG_DENSITY * (timeStrength * (VOLUMETRIC_FOG_MORNING_DENSITY - VOLUMETRIC_FOG_NOON_DENSITY) + VOLUMETRIC_FOG_NOON_DENSITY);
                }
                else {
                    absorptionBeta = waterAbsorptionBeta + 0.003;
                    basicWeight *= 10.0 * WATER_VL_STRENGTH * shadowLightFactor;
                    airScattering *= rayleighPhase(LdotV);
                }

                float maxHorizonalRange = far + 32.0;
                float maxVerticalRange = min(far, max(cameraPosition.y + 64.0, 320.0 - cameraPosition.y) * 2.0) + 32.0;
                #ifdef LOD
                    maxHorizonalRange = lodRenderDistance() * 1.1;
                #endif
                float waterWorldDirY2 = waterWorldDir.y * waterWorldDir.y;
                float maxAllowedDistance = maxHorizonalRange * maxVerticalRange * inversesqrt(pow2(maxHorizonalRange) * waterWorldDirY2 + pow2(maxVerticalRange) * (1.0 - waterWorldDirY2));
                maxAllowedDistance = min(maxAllowedDistance, waterViewDepthNoLimit + 5000.0 * exp(-6.0 * length(absorptionBeta)));
                if (waterViewDepthNoLimit < maxAllowedDistance && isEyeInWater < 2) {
                    float noise = bayer64Temporal(gl_FragCoord.xy);

                    vec3 origin = gbufferModelViewInverse[3].xyz;
                    vec3 target = worldPos * clamp(maxAllowedDistance * worldDistanceInv, 0.0, 1.0) + origin;
                    vec3 samplePos = origin + worldDir * waterViewDepthNoLimit;
                    vec3 stepSize = (target - samplePos) / VL_SAMPLES;
                    samplePos += stepSize * noise;
                    float stepLength = length(stepSize);

                    basicWeight *= stepLength;
                    stainedColor *= basicWeight * 0.02;
                    absorptionBeta *= -1.44269502 * stepLength;
                    vec3 rayAbsorption = exp2(absorptionBeta * noise) * stainedColor;
                    #ifdef LIGHT_LEAKING_FIX
                        rayAbsorption *= pow(gbufferData.lightmap.y + 1e-4, exp(-0.5 * stepLength));
                    #endif
                    vec3 stepAbsorption = exp2(absorptionBeta);
                    vec3 skyScattering = (sunColor * SUNLIGHT_BRIGHTNESS * 2.0 + skyColorUp) * eyeBrightnessSmooth.y / 1000.0;
                    stepLength *= -0.01 * 1.44269502 / max(1e-5, basicWeight);
                    for (int i = 0; i < VL_SAMPLES; i++) {
                        vec3 singleLight = vec3(1.0);
                        #ifdef CLOUD_SHADOW
                            singleLight *= cloudShadow(samplePos, shadowDirection);
                        #endif
                        vec3 sampleShadowCoord = worldPosToShadowCoord(samplePos);
                        if (all(lessThan(
                            abs(sampleShadowCoord - vec3(vec2(1.0 - 1024 / realShadowMapResolution), 0.5)),
                            vec3(vec2(1024 / realShadowMapResolution), 0.5))
                        )) {
                            float solidShadowStrength = textureLod(shadowtex0, sampleShadowCoord, 2.0);
                            singleLight *= vec3(solidShadowStrength);
                            sampleShadowCoord.y -= 0.5;
                            vec3 caustic = waterCaustic(sampleShadowCoord, samplePos, shadowDirection, 2.0);
                            singleLight *= caustic;
                            #ifdef TRANSPARENT_SHADOW
                                sampleShadowCoord.xy += vec2(-0.5, 0.5);
                                float transparentShadowStrength = textureLod(shadowtex0, sampleShadowCoord, 2.0);
                                if (transparentShadowStrength < 1.0) {
                                    vec4 transparentShadowColor = textureLod(shadowcolor0, sampleShadowCoord.st, 2.0);
                                    transparentShadowColor.rgb = pow(
                                        transparentShadowColor.rgb * (1.0 - 0.5 * pow2(transparentShadowColor.w)),
                                        vec3(sqrt(transparentShadowColor.w * 2.2 * 2.2 * 1.5) + 1e-6)
                                    );
                                    singleLight *= mix(transparentShadowColor.rgb, vec3(1.0), vec3(transparentShadowStrength));
                                }
                            #endif
                        }
                        singleLight *= sunColor * SUNLIGHT_BRIGHTNESS;
                        #ifdef VOLUMETRIC_FOG
                            float sampleVolumetricFogDensity = volumetricFogDensity(samplePos) * volumetricFogScattering;
                            singleLight *= sampleVolumetricFogDensity * 5.0 + airScattering;
                            singleLight += sampleVolumetricFogDensity * skyScattering;
                        #else
                            singleLight *= airScattering;
                        #endif
                        singleLight *= rayAbsorption;
                        #ifdef VOLUMETRIC_FOG
                            float volumetricFogAbsorption = exp2(stepLength * sampleVolumetricFogDensity);
                            rayAbsorption *= volumetricFogAbsorption;
                            solidColor.rgb *= volumetricFogAbsorption;
                        #endif
                        rayAbsorption *= stepAbsorption;
                        volumetricLight += singleLight;
                        samplePos += stepSize;
                    }
                }
            #endif
        #endif

        solidColor.rgb = solidColor.rgb + volumetricLight;
    }


    /************************************************************* Water Fog *************************************************************/

    vec3 absorption = vec3(1.0);
    waterDepth -= float(waterDepth > 1.0);
    float waterViewDepth = mix(waterViewDepthNoLimit, 114514.0, step(0.999999, waterDepth));
    if (isEyeInWater == 0) {
        #ifdef NETHER
            absorption = vec3(netherFogAbsorption(waterViewDepth));
            solidColor.rgb *= absorption;
            solidColor.rgb += netherFogScattering(waterViewDepth);
        #elif defined THE_END
            absorption = vec3(endFogAbsorption(waterViewDepth));
            solidColor.rgb *= absorption;
            solidColor.rgb += endFogScattering(waterViewDepth);
            if (waterDepth > 0.999999) {
                solidColor.rgb += endStars(waterWorldDir);
            }
        #else
            #ifdef SHADOW_AND_SKY
                #ifdef ATMOSPHERE_SCATTERING_FOG
                    float atmosphereDepth = mix(waterViewDepthNoLimit * (1.0 + RF_GROUND_EXTRA_DENSITY * 3.0 * weatherStrength), 1600.0, step(0.999999, waterDepth));
                    absorption *= exp2(-vec3(atmosphereDepth * rainyMieBeta * 25.0 * 1.44269502));
                    solidColor.rgb = solidAtmosphereScattering(solidColor.rgb, waterWorldDir, skyColorUp, atmosphereDepth, eyeBrightnessSmooth.y / 240.0);
                #endif
            #endif
            absorption *= vec3(airAbsorption(waterViewDepth));
            solidColor.rgb *= vec3(airAbsorption(waterViewDepth));
        #endif
    }
    else if (isEyeInWater == 1) {
        absorption = waterFogAbsorption(waterViewDepth);
        solidColor.rgb *= absorption;
        solidColor.rgb += waterFogScattering(waterWorldDir, skyColorUp, waterViewDepth, eyeBrightnessSmooth.y / 240.0);
    }
    else if (isEyeInWater == 2) {
        absorption = vec3(lavaFogAbsorption(waterViewDepth));
        solidColor.rgb *= absorption;
        solidColor.rgb += lavaFogScattering(waterViewDepth);
    }
    else if (isEyeInWater == 3) {
        absorption = vec3(snowFogAbsorption(waterViewDepth));
        solidColor.rgb *= absorption;
        solidColor.rgb += snowFogScattering(skyColorUp, waterViewDepth, eyeBrightnessSmooth.y / 240.0);
    }

    texBuffer4 = vec4(absorption * solidColor.w, 1.0);
    texBuffer5 = vec4(solidColor.rgb, f0);
}

/* DRAWBUFFERS:045 */
