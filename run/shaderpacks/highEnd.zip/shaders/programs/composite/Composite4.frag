#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer4;

in vec2 texcoord;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/ReflectionFilter.glsl"

void main() {
    texBuffer4 = vec4(0.0);
    float depth = getWaterDepth(texcoord);
    ivec2 texel = ivec2(texcoord * screenSize);
    vec4 originData = texelFetch(colortex4, texel, 0);
    if (depth < getSolidDepth(texcoord) && originData.w > 0.0025)
        texBuffer4 = reflectionFilter(texel, originData, 6.0, false);
}

/* DRAWBUFFERS:4 */
