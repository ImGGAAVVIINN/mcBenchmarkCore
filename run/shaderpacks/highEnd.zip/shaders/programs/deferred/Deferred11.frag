#extension GL_ARB_gpu_shader5 : enable
#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer5;

in vec2 texcoord;

uniform vec4 projShadowDirection;

// #define COLORFUL_HELD_LIGHT
#define LIGHTING_OUTSIDE_VOXELIZATION
#define PCSS
#define PCSS_SAMPLES 9 // [2 3 4 5 6 7 8 9 10 12 14 16 18 20 25 30 36]
#define SCREEN_SPACE_SHADOW_SAMPLES 12 // [4 5 6 7 8 9 10 12 14 16 18 20 25 30 35 40 45 50]
#define SCREEN_SPACE_SHADOW
#define PATH_TRACED_CONTACT_SHADOW
#define VANILLA_BLOCK_LIGHT_FADE 2.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.2 2.4 2.6 2.8 3.0 3.2 3.4 3.6 3.8 4.0 4.2 4.4 4.6 4.8 5.0 5.5 6.0 6.5 7.0 7.5 8.0 9.5 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]

#include "/settings/CloudSettings.glsl"
#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/Atmosphere.glsl"
#include "/libs/Cloud.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Shadow.glsl"
#include "/libs/VoxelShape.glsl"
#include "/libs/PathTrace.glsl"

const bool colortex4MipmapEnabled = true;

const float shadowDistance = 120.0; // [80.0 120.0 160.0 200.0 240.0 280.0 320.0 360.0 400.0 480.0 560.0 640.0]

#ifdef SHADOW_AND_SKY
    vec3 shadowSpaceSurfaceOffset(vec3 worldOffsetDir) {
        vec3 offset = mat3(shadowModelViewProj0, shadowModelViewProj1, shadowModelViewProj2) * worldOffsetDir;
        offset *= inversesqrt(max(dot(offset.xy, offset.xy), dot(offset, offset) * 0.09)) * 0.1 / shadowDistance;
        offset.z *= 0.1;
        return offset;
    }

    void percentageCloserSoftShadow(
        vec3 worldPos, vec3 worldGeoNormal, float NdotL, float viewLength, float lightFactor, float smoothness,
        float porosity, float skyLight, vec2 noise, inout vec3 shadow, inout vec3 subsurfaceScattering
    ) {
        shadow *= basicSunlight;
        subsurfaceScattering *= basicSunlight * clamp(SUBSERFACE_SCATTERING_STRENTGH * 1e+10, 0.0, 1.0);
        if (weatherStrength < 0.999) {
            vec3 sssShadowCoord = worldPosToShadowCoordNoDistort(worldPos);
            float normalOffsetLen = (viewLength * 2e-3 + 2e-2) * (1.0 + sqrt(1.0 - NdotL));
            vec3 normalOffset = mat3(shadowModelViewProj0, shadowModelViewProj1, shadowModelViewProj2) * (worldGeoNormal * normalOffsetLen);
            normalOffset.z *= 0.1;

            vec3 basicShadowCoordNoDistort = sssShadowCoord + normalOffset;
            sssShadowCoord = distortShadowCoord(sssShadowCoord - normalOffset);
            float clipLengthInv = inversesqrt(dot(basicShadowCoordNoDistort.xy, basicShadowCoordNoDistort.xy));
            float distortFactor = clipLengthInv * log(distortionStrength / clipLengthInv + 1.0) / log(distortionStrength + 1.0);
            vec3 basicShadowCoord = basicShadowCoordNoDistort;
            basicShadowCoord.st = basicShadowCoord.st * (1024 / realShadowMapResolution) * distortFactor + (realShadowMapResolution - 1024) / realShadowMapResolution;

            float normalFactor = clamp(pow(NdotL, pow2(1.0 - smoothness * 0.3)), 0.0, 1.0);
            NdotL = abs(dot(worldGeoNormal, shadowDirection));
            NdotL = NdotL + (1.0 - NdotL) * clamp(porosity * 255.0 / 191.0 - 64.0 / 191.0, 0.0, 1.0);
            vec3 offsetDirection1 = cross(worldGeoNormal, shadowDirection);
            vec3 offsetDirection2 = cross(worldGeoNormal, offsetDirection1);
            offsetDirection1 = shadowSpaceSurfaceOffset(offsetDirection1);
            offsetDirection2 = shadowSpaceSurfaceOffset(offsetDirection2);
            basicShadowCoordNoDistort.z -= 2e-5;

            float avgOcclusionDepth = 0.0;
            float depthSum = 0.0;
            float depthSampleRadius = (0.5 + noise.y) * 2.0;
            float offsetX = -depthSampleRadius;
            for (int i = -1; i <= 1; i++) {
                float offsetY = -depthSampleRadius;
                for (int j = -1; j <= 1; j++) {
                    vec3 sampleCoord = distortShadowCoord(basicShadowCoordNoDistort + offsetX * offsetDirection1 + offsetY * offsetDirection2);
                    float sampleDepth = textureLod(shadowtex1, sampleCoord.st, 1.0).r;
                    depthSum += sampleDepth;
                    avgOcclusionDepth += clamp(sampleCoord.z - sampleDepth, 0.0, 1.0);
                    offsetY += depthSampleRadius;
                }
                offsetX += depthSampleRadius;
            }

            if (
                all(lessThan(
                    abs(basicShadowCoord - vec3(vec2((realShadowMapResolution - 1024) / realShadowMapResolution), 0.5)),
                    vec3(vec2((1024 - 4.0) / realShadowMapResolution), 0.5))
                ) && depthSum < 8.9999
            ) {
                if (depthSum < 8.9999) {
                    float filterRadius = min(avgOcclusionDepth * 80.0 / 9.0, 4.0) + 0.02 * shadowDistance / distortFactor;

                    vec3 waterShadowCoord = basicShadowCoord - vec3(0.0, 0.5, 0.0);
                    vec3 caustic = waterCaustic(waterShadowCoord, worldPos, shadowDirection, 1.0) * lightFactor;
                    shadow *= caustic;
                    subsurfaceScattering *= caustic;

                    const mat2 rotation = mat2(cos(2.39996323), sin(2.39996323), -sin(2.39996323), cos(2.39996323));
                    noise.x *= PI * 2.0;
                    vec2 sampleAngle = vec2(cos(noise.x), sin(noise.x)) * filterRadius;
                    float sampleRadius = noise.y * 1.0 / PCSS_SAMPLES + 1e-6;
                    bool needSubsurfaceScattering = porosity > 64.5 / 255.0;

                    float sssRadius = ((1024.0 / realShadowMapResolution) + (1024.0 / realShadowMapResolution) / filterRadius) * distortFactor;
                    float transparentShadow = 1e-6;
                    vec4 transparentShadowColor = vec4(0.0, 0.0, 0.0, 1e-6);
                    float opticalDepth = 0.0;
                    float solidShadow = 0.0;
                    for (int i = 0; i < PCSS_SAMPLES; i++) {
                        vec2 sampleRotation = sampleRadius * inversesqrt(sampleRadius) * sampleAngle;
                        vec3 sampleOffset = sampleRotation.x * offsetDirection1 + sampleRotation.y * offsetDirection2;
                        vec3 sampleShadowCoord = distortShadowCoord(basicShadowCoordNoDistort + sampleOffset);
                        if (normalFactor > 1e-5) {
                            float sampleSolidShadow = textureLod(shadowtex0, sampleShadowCoord, 0.0);
                            solidShadow += sampleSolidShadow;
                        }

                        if (needSubsurfaceScattering) {
                            vec3 sssSampleCoord = sssShadowCoord + vec3(sampleOffset.st * sssRadius, 0.0);
                            float shadowDepth = textureLod(shadowtex1, sssSampleCoord.st, 1.0).r;
                            opticalDepth += clamp(sssSampleCoord.z - shadowDepth + 1e-4, 0.0, 1.0);
                        }

                        sampleAngle = rotation * sampleAngle;
                        sampleRadius += 1.0 / PCSS_SAMPLES;
                        #ifdef TRANSPARENT_SHADOW
                            sampleShadowCoord.x -= 0.5;
                            float sampleTransparentShadow = textureLod(shadowtex0, sampleShadowCoord, 0.0);
                            if (sampleTransparentShadow < 1.0) {
                                sampleTransparentShadow = 1.0 - sampleTransparentShadow;
                                vec4 sampleTransparentColor = textureLod(shadowcolor0, sampleShadowCoord.st, 1.0);
                                transparentShadow += sampleTransparentShadow;
                                transparentShadowColor += sampleTransparentColor * sampleTransparentShadow;
                            }
                        #endif
                    }
                    solidShadow *= normalFactor / PCSS_SAMPLES;
                    if (needSubsurfaceScattering && SUBSERFACE_SCATTERING_STRENTGH > 0.0) {
                        const float absorptionScale = SUBSERFACE_SCATTERING_STRENTGH / (191.0);
                        float absorptionBeta = -4e+3 * 0.5 * 1.44269502 / max(porosity * absorptionScale * 255.0 - absorptionScale * 64.0, 1e-5) * opticalDepth / PCSS_SAMPLES;
                        subsurfaceScattering *= exp2(absorptionBeta) * (1.0 - solidShadow) * NdotL;
                    }
                    shadow *= solidShadow;

                    #ifdef TRANSPARENT_SHADOW
                        transparentShadowColor /= transparentShadow;
                        transparentShadow /= PCSS_SAMPLES;
                        transparentShadowColor.rgb = pow(
                            transparentShadowColor.rgb * (1.0 - 0.5 * pow2(transparentShadowColor.w)),
                            vec3(sqrt(transparentShadowColor.w * 2.2 * 2.2 * 1.5))
                        );
                        transparentShadowColor.rgb = mix(vec3(1.0), transparentShadowColor.rgb, vec3(transparentShadow));
                        shadow *= transparentShadowColor.rgb;
                        subsurfaceScattering *= transparentShadowColor.rgb;
                    #endif
                }
            }
            else {
                skyLight = smoothstep(0.8, 0.9, skyLight);
                shadow *= skyLight * normalFactor;
                subsurfaceScattering *= skyLight * (1.0 - normalFactor) * NdotL * step(64.5 / 255.0, porosity);
            }
        }
    }

    float screenSpaceShadow(vec3 viewPos, float NdotL, float viewLength, float porosity, vec2 noise, float materialID) {
        vec4 originProjPos = vec4(vec3(gbufferProjection[0].x, gbufferProjection[1].y, gbufferProjection[2].z) * viewPos, -viewPos.z);
        originProjPos.z += gbufferProjection[3].z;
        originProjPos.xy += gbufferProjection[2].xy * viewPos.z;
        #ifdef TAA
            originProjPos.xy += taaOffset * originProjPos.w;
        #endif
        float projScale = 0.5 / originProjPos.w;
        vec4 originCoord = vec4(originProjPos.xyz * projScale + 0.5, 0.0);

        vec4 projDirection = projShadowDirection;
        float traceLength = projIntersectionScreenEdge(originProjPos, projDirection);
        vec4 targetProjPos = originProjPos + projDirection * traceLength;
        float targetProjScale = 0.5 / targetProjPos.w;
        vec4 targetCoord = vec4(targetProjPos.xyz * targetProjScale + 0.5, 0.0);

        #ifdef LOD
            projDirection.z = projShadowDirection.z / gbufferProjection[2].z * projLod()[2].z;
            float originProjDepthLod = viewPos.z * projLod()[2].z + projLod()[3].z;
            originCoord.w = originProjDepthLod * projScale + 0.5;
            targetCoord.w = (originProjDepthLod + projDirection.z * traceLength) * targetProjScale + 0.5;
        #endif

        vec4 stepSize = targetCoord - originCoord;
        stepSize *= inversesqrt(dot(stepSize.xy, stepSize.xy));
        originCoord += stepSize * max(texelSize.x, texelSize.y) * 1.5;

        float shadow = 1.0;
        float stepScale = 1.0;
        float porosityScale = (1.0 - clamp(porosity - 0.25, 0.0, 1.0));
        stepSize *= 0.003 * 12.0 / SCREEN_SPACE_SHADOW_SAMPLES;

        targetCoord = originCoord + stepSize * SCREEN_SPACE_SHADOW_SAMPLES;
        #if SR_ENABLE
            originCoord.st *= renderScale;
            targetCoord.st *= renderScale;
            stepSize.st *= renderScale;
        #endif
        vec3 targetViewPos = screenToViewPos(targetCoord.xy, targetCoord.z);
        #ifdef LOD
            if (targetCoord.z >= 1.0) {
                targetViewPos = screenToViewPosLod(targetCoord.xy, targetCoord.w);
            }
        #endif
        const float absorptionScale = SUBSERFACE_SCATTERING_STRENTGH / (191.0);
        vec3 viewPosDiff = targetViewPos - viewPos;
        float absorptionBeta = -0.5 / (max(porosity * absorptionScale * 255.0 - absorptionScale * 64.0, 1e-5) * inversesqrt(dot(viewPosDiff, viewPosDiff)));
        float absorption = exp2(absorptionBeta * porosityScale * 0.5) * step(0.25, porosity) * (1.0 - clamp(NdotL * 10.0, 0.0, 1.0) * porosityScale) + 1.0;
        float shadowWeight = clamp(1.0 - abs(NdotL) * 10.0, 0.0, 1.0) * clamp(1.0 - 1.1 / viewLength / shadowDistance, 0.0, 1.0);

        vec4 sampleCoord = originCoord + noise.x * stepSize;
        sampleCoord.zw -= 2e-7;

        float maximumThickness = 0.0005 * viewLength + 0.03 * float(materialID == MAT_HAND);
        float maximumThicknessLod = 0.5 * viewLength;
        float depthMultiplicator = mix(1.0, 1.0 / MC_HAND_DEPTH, float(materialID == MAT_HAND));
        float baseDepthOffset = 0.5 - 0.5 * depthMultiplicator;
        sampleCoord.zw -= vec2(maximumThickness, maximumThicknessLod);

        for (int i = 0; i < SCREEN_SPACE_SHADOW_SAMPLES; i++) {
            if (any(greaterThan(floatBitsToUint(sampleCoord.xy), floatBitsToUint(screenEdge))) || shadow < 0.01) {
                break;
            }
            float sampleDepth = textureLod(depthtex1, sampleCoord.st, 0.0).r;
            bool hit;
            #ifdef LOD
                if (sampleDepth == 1.0) {
                    float sampleDepthLod = getLodDepthSolidDeferred(sampleCoord.st);
                    hit = abs(sampleCoord.w - sampleDepthLod) < maximumThicknessLod && sampleDepthLod < 1.0;
                }
                else
            #endif
            {
                float sampleParallaxOffset = textureLod(colortex5, sampleCoord.st, 0.0).w / 512.0 + baseDepthOffset;
                sampleDepth = sampleDepth * depthMultiplicator + sampleParallaxOffset;
                hit = abs(sampleCoord.z - sampleDepth) < maximumThickness && sampleDepth < 1.0;
                if (hit) {
                    vec2 sampleTexelCoord = sampleCoord.xy * screenSize + 0.5;
                    vec2 sampleTexel = floor(sampleTexelCoord);
                    vec4 sh = textureGather(depthtex1, sampleTexel * texelSize, 0);
                    vec2 fpc = sampleTexelCoord - sampleTexel;
                    vec2 x = mix(sh.wx, sh.zy, vec2(fpc.x));
                    float sampleDepth = mix(x.x, x.y, fpc.y);
                    sampleDepth = sampleDepth * depthMultiplicator + sampleParallaxOffset;
                    hit = abs(sampleCoord.z - sampleDepth) < maximumThickness;
                }
            }
            shadow *= clamp(absorption - float(hit), 0.0, 1.0);
            sampleCoord += stepSize;
        }

        return clamp(mix(shadow, 1.0, shadowWeight), 0.0, 1.0);
    }

    float pathTracedContactShadow(vec3 voxelPos, float viewLength) {
        const int shadowRaySteps = 4;

        vec2 atlasTexSize = vec2(textureSize(depthtex0, 0));
        Ray shadowRay = Ray(voxelPos, shadowDirection, shadowDirection, signI(shadowDirection));

        vec3 voxelIndex = shadowRay.dirSigned * floor(voxelPos);
        vec3 mirroredOrigin = (voxelPos - 0.5) * shadowRay.dirSigned - 0.5;
        vec3 stepLength = 1.0 / max(vec3(1e-6), abs(shadowDirection));
        shadowRay.dirInv = stepLength * shadowRay.dirSigned;
        vec3 nextLength = (voxelIndex - mirroredOrigin) * stepLength;
        float shadow = 0.1 * viewLength + 1.2;

        for (int i = 0; i < shadowRaySteps; i++) {
            vec3 realVoxelIndex = shadowRay.dirSigned * voxelIndex;
            ivec2 shadowTexel = ivec2(calcVoxelShadowTexel(realVoxelIndex));
            vec4 voxelData0 = texelFetch(shadowcolor0, shadowTexel, 0);
            vec4 voxelData1 = texelFetch(shadowcolor1, shadowTexel, 0);
            vec3 voxelDistance = abs(realVoxelIndex - voxelizationRadius + 0.5);
            if (any(greaterThan(voxelDistance, voxelizationRadius)))
                break;
            float rayLength = min(nextLength.x, min(nextLength.y, nextLength.z));
            vec3 nextBlock = clamp(1.0 - (nextLength - rayLength) * 1e+10, vec3(0.0), vec3(1.0));
            nextLength += nextBlock * stepLength;
            voxelIndex += nextBlock;
            if (voxelData0.w < 1.0) {
                voxelData1.z = round(voxelData1.z * 255.0);
                float textureResolution = 1.0 / TEXTURE_RESOLUTION;
                #if TEXTURE_RESOLUTION == 0
	                textureResolution = uintBitsToFloat((0x7Fu - (uint(round(voxelData1.w * 255.0)) & 0x7Fu)) << 23u);
                #endif
                vec2 atlasTiles = atlasTexSize * textureResolution;
                float targetOpacity = 1.0;
                if (isRayHitBlock(shadowRay, depthtex0, atlasTiles, voxelData1, realVoxelIndex, targetOpacity, rayLength) && targetOpacity > 0.999) {
                    shadow = rayLength * 5.0 - shadow + 1.0;
                    break;
                }
            }
        }
        shadow = clamp(shadow, 0.0, 1.0);
        return shadow;
    }
#endif

void main() {
    ivec2 texel = ivec2(gl_FragCoord.st);
    GbufferData gbufferData = getGbufferData(texel, texcoord);
    vec4 diffuseData = texelFetch(colortex5, texel, 0);
    vec3 viewPos;
    vec3 viewPosNoPOM;
    #ifdef LOD
        if (gbufferData.depth == 1.0) {
            gbufferData.depth = getLodDepthSolidDeferred(texcoord);
            viewPos = screenToViewPosLod(texcoord, gbufferData.depth - 1e-7);
            viewPosNoPOM = viewPos;
            gbufferData.depth = -gbufferData.depth;
        } else
    #endif
    {
        if (gbufferData.materialID == MAT_HAND) {
            gbufferData.depth = gbufferData.depth / MC_HAND_DEPTH - 0.5 / MC_HAND_DEPTH + 0.5;
        }
        viewPosNoPOM = screenToViewPos(texcoord, gbufferData.depth - 1e-7);
        gbufferData.depth += abs(diffuseData.w) / 512.0;
        viewPos = screenToViewPos(texcoord, gbufferData.depth - 1e-7);
    }
    vec3 worldPos = viewToWorldPos(viewPosNoPOM);
    vec3 worldDir = normalize(worldPos - gbufferModelViewInverse[3].xyz);

    vec4 finalColor = vec4(0.0);

    if (abs(gbufferData.depth) < 1.0) {
        float viewLength = inversesqrt(dot(viewPos, viewPos));
        vec3 viewDir = viewPos * viewLength;
        vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.normal);
        vec3 worldGeoNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.geoNormal);
        finalColor.rgb = diffuseData.rgb * 10.0 + (BASIC_LIGHT + NIGHT_VISION_BRIGHTNESS * nightVision);

        #ifdef LIGHTING_OUTSIDE_VOXELIZATION
            float outOfVoxelization = max(max(abs(worldPos.x), abs(worldPos.z)) - voxelizationRadius.x, abs(worldPos.y) - voxelizationRadius.y);
            outOfVoxelization = max(max(length(worldPos.xz), abs(worldPos.y)) - shadowDistance, outOfVoxelization);
            outOfVoxelization = clamp(outOfVoxelization * 0.1 + 0.5, 0.0, 1.0);
            outOfVoxelization *= outOfVoxelization * (3.0 - 2.0 * outOfVoxelization);
            const float fadeFactor = VANILLA_BLOCK_LIGHT_FADE;
            float blockLight = pow2(1.0 / (fadeFactor - fadeFactor * fadeFactor / (1.0 + fadeFactor) * gbufferData.lightmap.x) - 1.0 / fadeFactor);
            finalColor.rgb += commonLightColor * blockLight * outOfVoxelization * pow2(1.0 - gbufferData.emissive) * BLOCK_LIGHT_BRIGHTNESS;
        #endif

        #ifdef HELD_LIGHT
            vec3 heldLightColor = commonLightColor;
            #ifdef COLORFUL_HELD_LIGHT
                vec4 heldLight = textureLod(colortex4, vec2(0.5), 1024.0);
                heldLightColor = heldLight.rgb / max(1e-6, heldLight.w);
            #endif
            vec3 positionLeft = viewPos - vec3(-0.4, -0.3, 0.4);
            vec3 positionRight = viewPos - vec3(0.4, -0.3, 0.4);
            float distantLeft = dot(positionLeft, positionLeft);
            float distantRight = dot(positionRight, positionRight);
            vec3 directionLeft = viewDir + vec3(0.05, 0.0, 0.0);
            vec3 directionRight = viewDir + vec3(-0.05, 0.0, 0.0);
            float heldLightStrength =
                heldBlockLightValue * max(-dot(directionRight, gbufferData.normal) * inversesqrt(dot(directionRight, directionRight) * distantRight * distantRight), 0.0)+
                heldBlockLightValue2 * max(-dot(directionLeft, gbufferData.normal) * inversesqrt(dot(directionLeft, directionLeft) * distantLeft * distantLeft), 0.0);
            finalColor.rgb += heldLightStrength / 4.0 * heldLightColor;
        #endif

        float diffuseWeight = 1.0 - gbufferData.smoothness;
        float diffuseWeight2 = diffuseWeight * diffuseWeight;
        diffuseWeight *= diffuseWeight2 * diffuseWeight2;
        vec3 f0 = vec3(0.04);
        vec3 f82 = vec3(1.0);
        #ifdef LABPBR_F0
            f0 = mix(f0, vec3(gbufferData.metalness), step(0.001, gbufferData.metalness));
            f82 = hardcodedMetal(gbufferData.metalness);
            gbufferData.metalness = step(229.5 / 255.0, gbufferData.metalness);
        #endif
        f0 = mix(f0, gbufferData.albedo.rgb, gbufferData.metalness);
        #ifndef FULL_REFLECTION
            diffuseWeight = 1.0 - (1.0 - diffuseWeight) * sqrt(clamp(gbufferData.smoothness - (1.0 - gbufferData.smoothness) * (1.0 - 0.6666 * gbufferData.metalness), 0.0, 1.0));
        #endif
        float NdotV = clamp(dot(viewDir, -gbufferData.normal), 0.0, 1.0);
        vec3 diffuseAbsorption = (1.0 - gbufferData.metalness) * diffuseAbsorptionWeight(NdotV, gbufferData.smoothness, f0, f82);
        finalColor.rgb *= diffuseAbsorption + diffuseWeight / PI;
        finalColor.rgb += gbufferData.emissive * BLOCK_LIGHT_BRIGHTNESS * PI;
        finalColor.rgb *= gbufferData.albedo.rgb;
        finalColor.w = 1.0 - diffuseWeight;

        #ifdef SHADOW_AND_SKY
            vec3 shadow = sunColor;
            float NdotL = clamp(dot(worldNormal, shadowDirection), 0.0, 1.0);
            vec3 shadowDiffuse = gbufferData.albedo.rgb * diffuseAbsorption;
            vec3 shadowSpecular =
                sunlightSpecular(worldDir, shadowDirection, worldNormal, gbufferData.smoothness * 0.995, NdotL, NdotV, f0, f82) *
                airAbsorption(11.4 * gbufferData.smoothness) * clamp(19.0 - gbufferData.smoothness * 20.0, 0.0, 1.0);
            vec2 noise = blueNoiseTemporal(texcoord).xy;
            #ifdef SCREEN_SPACE_SHADOW
                shadow *= screenSpaceShadow(viewPos, dot(worldGeoNormal, shadowDirection), viewLength, gbufferData.porosity, noise, gbufferData.materialID);
            #endif
            #ifdef CLOUD_SHADOW
                shadow *= cloudShadow(worldPos, shadowDirection);
            #endif
            vec3 subsurfaceScattering = vec3(float(gbufferData.porosity > 64.5 / 255.0)) * shadow * shadowDiffuse;
            shadow *= shadowDiffuse + shadowSpecular;
            viewLength = 1.0 / viewLength;
            vec3 voxelPos = worldToVoxelPos(worldPos + (1e-4 + uintBitsToFloat((floatBitsToUint(cameraPosition) & 0x7F800000u) - 0x0B800000u)) * worldGeoNormal);
            float shadowLightFactor = 1.0;
            #ifdef LIGHT_LEAKING_FIX
                shadowLightFactor = clamp(gbufferData.lightmap.y * 10.0 + isEyeInWater, 0.0, 1.0);
            #endif
            #ifdef PCSS
                percentageCloserSoftShadow(
                    worldPos, worldGeoNormal, NdotL, viewLength, shadowLightFactor, gbufferData.smoothness,
                    gbufferData.porosity, gbufferData.lightmap.y, noise, shadow, subsurfaceScattering
                );
            #else
                directShadow(
                    worldPos, worldGeoNormal, NdotL, shadowLightFactor, gbufferData.smoothness,
                    gbufferData.porosity, gbufferData.lightmap.y, 0.0, shadow, subsurfaceScattering
                );
            #endif
            shadow += subsurfaceScattering;
            #ifdef PATH_TRACED_CONTACT_SHADOW
                if (gbufferData.porosity < 64.5 / 255.0 && gbufferData.materialID != MAT_HAND)
                    shadow *= pathTracedContactShadow(voxelPos, viewLength);
            #endif
            finalColor.rgb += shadow;
        #endif
    }
    #ifdef SHADOW_AND_SKY
        else {
            finalColor.rgb = renderSun(worldDir, sunDirection, vec3(300.0)) + gbufferData.albedo.rgb * 2.0;
        }
    #endif

    texBuffer5 = finalColor;
}

/* DRAWBUFFERS:5 */
