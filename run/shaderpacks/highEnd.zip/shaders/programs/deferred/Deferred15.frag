#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer4;
layout(location = 1) out vec4 texBuffer5;

in vec2 texcoord;

#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/ReflectionFilter.glsl"

void main() {
    ivec2 texel = ivec2(gl_FragCoord.st);
    texBuffer4 = texelFetch(colortex0, texel, 0);
    vec3 finalColor = texelFetch(colortex5, texel, 0).rgb;

    #ifdef REFLECTION
        float depth = getSolidDepth(texcoord);
        #ifdef LOD
            depth += float(depth == 1.0) * (getLodDepthSolidDeferred(texcoord) - 1.0);
        #endif
        if (depth < 1.0) {
            vec4 reflectionColor = texelFetch(colortex4, texel, 0);
            #if REFLECTION_FILTER > 0
                if (reflectionColor.w > 0.0025) {
                    reflectionColor.rgb = reflectionFilter(texel, reflectionColor, 1.0, true).rgb;
                }
            #endif
            vec3 mirrorWeight = texelFetch(colortex2, texel, 0).rgb;
            reflectionColor.rgb *= mirrorWeight;

            finalColor += reflectionColor.rgb;
        }
    #endif
    texBuffer5 = vec4(finalColor, 1.0);
}

/* DRAWBUFFERS:45 */
