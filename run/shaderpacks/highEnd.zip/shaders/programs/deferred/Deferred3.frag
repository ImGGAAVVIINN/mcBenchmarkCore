#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer5;

in vec2 texcoord;

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/GlobalIllumination.glsl"

void main() {
    texBuffer5 = globalIlluminationFilter(vec2(1.0, 0.0));
}

/* DRAWBUFFERS:5 */
