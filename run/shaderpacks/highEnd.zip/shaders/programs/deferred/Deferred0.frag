#extension GL_ARB_gpu_shader5 : enable
#extension GL_ARB_shading_language_packing : enable

#define GLOBAL_ILLUMINATION
#define GI_MAX_STEP 64 // [64 114 256 365 514]
// #define MOD_NIGHT_VISION_COMPAT
#define SCREEN_SPACE_GLOBAL_ILLUMINATION
// #define SSGI_PARALLAX
#define SSGI_STEPS 8 // [2 3 4 5 6 7 8 10 12 14 16 20 24 28 32]
#define SSGI_REFINEMENTS 3 // [1 2 3 4 5 6 8]
#define SSGI_LENGTH 0.2 // [0.05 0.1 0.15 0.2 0.3 0.4 0.5 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0]

layout(location = 0) out vec4 texBuffer0;
layout(location = 1) out vec4 texBuffer4;
layout(location = 2) out vec4 texBuffer5;

in vec2 texcoord;

#include "/settings/CloudSettings.glsl"
#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"

#ifdef SHADOW_AND_SKY
    in vec3 skyColorUp;

    #define LQ_REALISTIC_CLOUD
#else
    const vec3 skyColorUp = vec3(0.0);
#endif

#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/Atmosphere.glsl"
#include "/libs/Cloud.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Shadow.glsl"
#include "/libs/VoxelShape.glsl"
#include "/libs/PathTrace.glsl"

vec3 directionDistribution(vec3 normal, vec2 randVec2) {
    float randAngle = 6.2831853 * randVec2.x;
    float randStrength = sqrt(randVec2.y);
    float inversed = signI(normal.z);
    vec3 tangentDirection = vec3(cos(randAngle) * randStrength, sin(randAngle) * randStrength, sqrt(1.0 - randVec2.y) * inversed);
    vec3 reflectDirection = vec3(normal.xy, normal.z + inversed);
    vec3 rayDirection = dot(tangentDirection, reflectDirection) * reflectDirection / abs(reflectDirection.z) - tangentDirection;
    return rayDirection;
}

vec3 traceGlobalIllumination(vec2 texcoord, GbufferData gbufferData) {
    vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.normal);
    vec3 worldGeoNormal = normalize(mat3(gbufferModelViewInverse) * gbufferData.geoNormal);

    vec3 viewPos;
    #ifdef LOD
        if (gbufferData.depth < 0.0) {
            viewPos = screenToViewPosLod(texcoord, -gbufferData.depth - 1e-7);
        } else
    #endif
    {
        if (gbufferData.materialID == MAT_HAND) {
            gbufferData.depth = gbufferData.depth / MC_HAND_DEPTH - 0.5 / MC_HAND_DEPTH + 0.5;
        }
        viewPos = screenToViewPos(texcoord, gbufferData.depth - 1e-7);
    }
    vec3 viewPosPOM = viewPos;
    #if (defined SCREEN_SPACE_GLOBAL_ILLUMINATION) && (defined SSGI_PARALLAX)
        viewPosPOM += gbufferData.parallaxOffset * PARALLAX_DEPTH * viewPos * 0.2 / max(dot(viewPos, -gbufferData.geoNormal), 1e-6);
    #endif
    vec3 worldPos = viewToWorldPos(viewPos);
    vec3 worldPosNoOffset = worldPos - gbufferModelViewInverse[3].xyz;
    float spreadSize = spreadAngle * length(worldPosNoOffset);

    vec3 voxelPos = worldToVoxelPos(worldPos + (1e-4 + uintBitsToFloat((floatBitsToUint(cameraPosition) & 0x7F800000u) - 0x0B800000u)) * worldGeoNormal);

    vec2 atlasTexSize = vec2(textureSize(depthtex0, 0));
    NoiseGenerator noiseGenerator = initNoiseGenerator(uvec2(gl_FragCoord.st), uint(frameCounter));

    vec3 totalLight = vec3(0.0);
    #ifdef MOD_NIGHT_VISION_COMPAT
        totalLight += texelFetch(colortex5, ivec2(0), 0).rgb * GI_SAMPLES * NIGHT_VISION_BRIGHTNESS;
    #endif
    Ray tracedRay = Ray(voxelPos, vec3(0.0), vec3(0.0), vec3(0.0));
    for (int i = 0; i < GI_SAMPLES; i++) {
        vec2 noise = nextVec2(noiseGenerator);
        tracedRay.direction = directionDistribution(worldNormal, noise);

        bool hitSky = true;
        float rayLength = 0.0;
        vec3 singleLight = vec3(0.0);
        vec3 stainedColor = vec3(1.0);
        vec4 sampleCoord = vec4(worldGeoNormal, -114514.0);
        #ifdef SCREEN_SPACE_GLOBAL_ILLUMINATION
            vec4 parallaxRayOrigin = vec4(vec3(gbufferProjection[0].x, gbufferProjection[1].y, gbufferProjection[2].z) * viewPosPOM, -viewPosPOM.z);
            parallaxRayOrigin.z += gbufferProjection[3].z;
            parallaxRayOrigin.xy += gbufferProjection[2].xy * viewPosPOM.z;
            float originProjScale = 1.0 / parallaxRayOrigin.w;
            vec4 screenOrigin = vec4(parallaxRayOrigin.xyz * originProjScale, 0.0);
            vec3 viewRayDir = mat3(gbufferModelView) * tracedRay.direction;
            vec4 projDirection = vec4(vec3(gbufferProjection[0].x, gbufferProjection[1].y, gbufferProjection[2].z) * viewRayDir, -viewRayDir.z);
            projDirection.xy += gbufferProjection[2].xy * viewRayDir.z;
            float maxTraceLength = projIntersectionScreenEdge(parallaxRayOrigin, projDirection);
            vec4 maxTraceEnd = parallaxRayOrigin + projDirection * maxTraceLength;
            maxTraceEnd.w = 1.0 / maxTraceEnd.w;
            vec4 screenEdgePos = vec4(maxTraceEnd.xyz * maxTraceEnd.w, 0.0);
            #ifdef LOD
                float originProjDepthLod = viewPosPOM.z * projLod()[2].z + projLod()[3].z;
                screenOrigin.w = originProjDepthLod * originProjScale;
                projDirection.z = viewRayDir.z * projLod()[2].z;
                screenEdgePos.w = (originProjDepthLod + projDirection.z * maxTraceLength) * maxTraceEnd.w;
            #endif

            vec4 maxTraceOffset = screenEdgePos - screenOrigin;
            vec4 traceOffset = maxTraceOffset * clamp(SSGI_LENGTH * inversesqrt(dot(maxTraceOffset.xy, maxTraceOffset.xy)), 0.0, 1.0);
            traceOffset *= 0.5 / SSGI_STEPS;

            #ifdef TAA
                screenOrigin.st += taaOffset;
            #endif
            sampleCoord = screenOrigin * 0.5 + 0.5;
            vec4 stepSize = traceOffset;
            sampleCoord += stepSize * (nextFloat(noiseGenerator) + 0.1);
            #if SR_ENABLE
                sampleCoord.st *= renderScale;
                stepSize.st *= renderScale;
            #endif
            float minimumThichness = max(0.002 * originProjScale, abs(stepSize.z)) + 0.03 * float(gbufferData.materialID == MAT_HAND);
            float minimumThichnessLod = max(0.02 * originProjScale, abs(stepSize.w));

            vec4 sampleNormalData = vec4(0.0);
            vec4 sampleGbufferData = vec4(0.0);
            for (int j = 0; j < SSGI_STEPS; j++) {
                float sampleDepth = textureLod(depthtex1, sampleCoord.st, 0.0).x;
                ivec2 sampleTexel = ivec2(sampleCoord.st * screenSize);
                sampleGbufferData = texelFetch(colortex2, sampleTexel, 0);
                vec2 sampleMaterialParallaxOffset = unpackM3P13(sampleGbufferData.a);
                if (abs(sampleMaterialParallaxOffset.x * 7.0 - MAT_HAND) < 0.1) {
                    sampleDepth = sampleDepth / MC_HAND_DEPTH - 0.5 / MC_HAND_DEPTH + 0.5;
                }
                #ifdef SSGI_PARALLAX
                    if (sampleDepth < 1.0) {
                        sampleNormalData = texelFetch(colortex1, sampleTexel, 0);
                        vec3 sampleGeoNormal = decodeNormal(sampleNormalData.zw);
                        vec3 sampleViewPos = screenToViewPos(sampleCoord.st, sampleDepth);
                        sampleViewPos += sampleMaterialParallaxOffset.y * PARALLAX_DEPTH * sampleViewPos * 0.2 / max(dot(sampleViewPos, -sampleGeoNormal), 1e-6);
                        sampleDepth = viewToScreenDepth(-sampleViewPos.z);
                    }
                #endif

                bool hitCheck = sampleCoord.z > sampleDepth && sampleDepth < 1.0;
                #ifdef LOD
                    float sampleDepthLod = getLodDepthSolidDeferred(sampleCoord.st);
                    hitCheck = hitCheck || (sampleDepth == 1.0 && sampleCoord.w > sampleDepthLod && sampleDepthLod < 1.0);
                #endif
                if (hitCheck) {
                    float stepScale = 0.5;
                    vec4 refinementCoord = sampleCoord;
                    for (int j = 0; j < SSGI_REFINEMENTS; j++) {
                        float stepDirection = sampleDepth - refinementCoord.z;
                        #ifdef LOD
                            sampleDepthLod = getLodDepthSolidDeferred(refinementCoord.st);
                            float stepDirectionLod = sampleDepthLod - refinementCoord.w;
                            stepDirection = mix(stepDirection, stepDirectionLod, float(sampleDepth == 1.0));
                        #endif
                        refinementCoord += signMul(stepScale, stepDirection) * stepSize;

                        sampleDepth = textureLod(depthtex1, refinementCoord.st, 0.0).x;
                        ivec2 sampleTexel = ivec2(refinementCoord.st * screenSize);
                        sampleGbufferData = texelFetch(colortex2, sampleTexel, 0);
                        vec2 sampleMaterialParallaxOffset = unpackM3P13(sampleGbufferData.a);
                        if (abs(sampleMaterialParallaxOffset.x * 7.0 - MAT_HAND) < 0.1) {
                            sampleDepth = sampleDepth / MC_HAND_DEPTH - 0.5 / MC_HAND_DEPTH + 0.5;
                        }
                        #ifdef SSGI_PARALLAX
                            if (sampleDepth < 1.0) {
                                sampleNormalData = texelFetch(colortex1, sampleTexel, 0);
                                vec3 sampleGeoNormal = decodeNormal(sampleNormalData.zw);
                                vec3 sampleViewPos = screenToViewPos(refinementCoord.st, sampleDepth);
                                sampleViewPos += sampleMaterialParallaxOffset.y * PARALLAX_DEPTH * sampleViewPos * 0.2 / max(dot(sampleViewPos, -sampleGeoNormal), 1e-6);
                                sampleDepth = viewToScreenDepth(-sampleViewPos.z);
                            }
                        #endif

                        stepScale *= 0.5;
                    }
                    bool hitTerrain = abs(refinementCoord.z - sampleDepth) < minimumThichness && sampleDepth < 1.0;
                    #ifdef LOD
                        hitTerrain = hitTerrain || (sampleDepth == 1.0 && abs(refinementCoord.w - sampleDepthLod) < minimumThichnessLod && sampleDepthLod < 1.0);
                    #endif
                    if (hitTerrain && all(lessThan(floatBitsToUint(refinementCoord.st), floatBitsToUint(screenEdge)))) {
                        sampleCoord = refinementCoord;
                        #ifdef SSGI_PARALLAX
                            float sampleParallaxOffset = unpackM3P13(sampleGbufferData.a).y;
                            vec3 sampleGeoNormal = decodeNormal(sampleNormalData.zw);
                            vec3 sampleViewPos = screenToViewPos(refinementCoord.st, sampleDepth);
                            sampleViewPos -= sampleParallaxOffset * PARALLAX_DEPTH * sampleViewPos * 0.2 / max(dot(sampleViewPos, -sampleGeoNormal), 1e-6);
                            sampleDepth = viewToScreenDepth(-sampleViewPos.z);
                        #endif
                        sampleCoord.z = sampleDepth;
                        #ifdef LOD
                            sampleCoord.w = sampleDepthLod;
                        #endif
                        hitSky = false;
                        break;
                    }
                }
                if (clamp(sampleCoord.st, 0.0, 1.0) != sampleCoord.st || sampleCoord.z < 0.0) break;
                sampleCoord += stepSize;
            }
            if (hitSky) {
                sampleCoord.w = -114514.0;      // -.w marks screen space miss
                sampleCoord.xyz = worldGeoNormal;
            }
        #endif
        tracedRay.dirSigned = signI(tracedRay.direction);

        vec3 voxelIndex = tracedRay.dirSigned * floor(tracedRay.origin);
        vec3 mirroredOrigin = (tracedRay.origin - 0.5) * tracedRay.dirSigned - 0.5;
        vec3 stepLength = 1.0 / max(vec3(1e-6), abs(tracedRay.direction));
        tracedRay.dirInv = stepLength * tracedRay.dirSigned;
        // Turns targetCoord when hit
        vec3 nextLength = (voxelIndex - mirroredOrigin) * stepLength;

        float prevID = 255.0;
        float prevIDCopy = prevID;
        vec3 targetNormal = -tracedRay.direction;
        vec4 targetAlbedo = vec4(1.0);
        vec4 voxelData0 = vec4(0.0);

        for (int j = 0; j < GI_MAX_STEP; j++) {
            vec3 realVoxelIndex = tracedRay.dirSigned * voxelIndex;
            ivec2 shadowTexel = ivec2(calcVoxelShadowTexel(realVoxelIndex));
            voxelData0 = texelFetch(shadowcolor0, shadowTexel, 0);
            vec4 voxelData1 = texelFetch(shadowcolor1, shadowTexel, 0);
            vec3 voxelDistance = abs(realVoxelIndex - voxelizationRadius + 0.5);
            rayLength = min(nextLength.x, min(nextLength.y, nextLength.z));
            float rayLengthTemp = rayLength;
            prevIDCopy = prevID;
            prevID = 255.0;
            if (any(greaterThan(voxelDistance, voxelizationRadius)))
                break;
            if (voxelData0.w < 1.0) {
                voxelData1.z = round(voxelData1.z * 255.0);
                float textureResolution = 1.0 / TEXTURE_RESOLUTION;
                #if TEXTURE_RESOLUTION == 0
                    textureResolution = uintBitsToFloat((0x7Fu - (uint(round(voxelData1.w * 255.0)) & 0x7Fu)) << 23u);
                #endif
                float emissiveScale;
                vec2 targetCoord = vec2(0.0);
                vec3 targetTangent = vec3(0.0);
                vec2 atlasTiles = atlasTexSize * textureResolution;
                if (isRayHitBlock(
                    tracedRay, depthtex0, atlasTiles, voxelData0.rgb, voxelData1, realVoxelIndex, vec2(spreadSize, 0.2) / textureResolution,
                    targetAlbedo, targetCoord, rayLength, targetNormal, targetTangent, emissiveScale
                )) {
                    emissiveScale *= step(0.4, voxelData1.w);
                    if (targetAlbedo.w > 0.999 && voxelData1.z != 168.0) {
                        nextLength = vec3(targetCoord, emissiveScale);
                        hitSky = false;
                        break;
                    }
                    if (voxelData1.z == 168.0) {
                        vec3 lightColor = pow(targetAlbedo.rgb, vec3(2.2)) * stainedColor;
                        if (isEyeInWater == 0) {
                            #ifdef NETHER
                                lightColor *= netherFogAbsorption(rayLength);
                            #elif defined THE_END
                                lightColor *= endFogAbsorption(rayLength);
                            #else
                                lightColor *= airAbsorption(rayLength);
                            #endif
                        }
                        else if (isEyeInWater == 1) {
                            lightColor *= waterFogAbsorption(rayLength);
                        }
                        singleLight += lightColor * PI * BLOCK_LIGHT_BRIGHTNESS;
                    }
                    else if (targetAlbedo.w > 0.01) {
                        if (voxelData1.z + prevIDCopy > 100.0) {
                            targetAlbedo.rgb = 2.2 * log2(targetAlbedo.rgb);
                            vec3 glassColor = exp2(sqrt(targetAlbedo.w * 1.5) * (targetAlbedo.rgb + log2(1.0 - 0.5 * targetAlbedo.w * targetAlbedo.w)));
                            float LdotH = clamp(dot(-tracedRay.direction, targetNormal), 0.0, 1.0);
                            SpecularData specularData = SpecularData(0.0, 0.0, 0.0, 0.0);
                            #ifdef MC_SPECULAR_MAP
                                specularData = SPECULAR_FORMAT(textureLod(depthtex2, targetCoord, 0.0));
                            #endif
                            #ifndef SPECULAR_EMISSIVE
                                specularData.emissive = 0.0;
                            #endif
                            #ifdef HARDCODED_EMISSIVE
                                specularData.emissive += step(specularData.emissive, 1e-3) * emissiveScale;
                            #endif
                            specularData.emissive *= PI * BLOCK_LIGHT_BRIGHTNESS;
                            float f0 = 0.04;
                            #ifdef LABPBR_F0
                                f0 = mix(f0, specularData.metalness, step(0.001, specularData.metalness));
                                specularData.metalness = step(229.5 / 255.0, specularData.metalness);
                            #endif
                            glassColor *= sqrt(1.0 - fresnel(LdotH, vec3(f0)));
                            vec3 lightColor = exp2(targetAlbedo.rgb) * specularData.emissive * targetAlbedo.w;
                            if (isEyeInWater == 0) {
                                #ifdef NETHER
                                    singleLight += netherFogScattering(rayLength) * stainedColor;
                                    stainedColor *= netherFogAbsorption(rayLength);
                                #elif defined THE_END
                                    singleLight += endFogScattering(rayLength) * stainedColor;
                                    stainedColor *= endFogAbsorption(rayLength);
                                #else
                                    stainedColor *= airAbsorption(rayLength);
                                #endif
                            }
                            else if (isEyeInWater == 1) {
                                singleLight += waterFogScattering(tracedRay.direction, skyColorUp, rayLength, gbufferData.lightmap.y) * stainedColor;
                                stainedColor *= waterFogAbsorption(rayLength);
                            }
                            singleLight += lightColor * stainedColor;
                            targetAlbedo = vec4(1.0);
                            stainedColor *= glassColor;

                            tracedRay.origin += tracedRay.direction * rayLength;
                            float k = sqrt(1.5 * 1.5 - 1.0 + LdotH * LdotH);
                            float n = 1.0 / 1.5;
                            stainedColor *= n * n;
                            vec3 refractDir = (tracedRay.direction + (LdotH - k) * targetNormal) * n;
                            tracedRay.direction = mix(tracedRay.direction, refractDir, specularData.smoothness + step(specularData.smoothness, 0.001));
                            tracedRay.dirSigned = signI(tracedRay.direction);
                            vec3 mirroredOrigin = (tracedRay.origin - 0.5) * tracedRay.dirSigned - 0.5;
                            stepLength = 1.0 / max(vec3(1e-6), abs(tracedRay.direction));
                            tracedRay.dirInv = stepLength * tracedRay.dirSigned;
                            nextLength = (voxelIndex - mirroredOrigin) * stepLength;
                            rayLengthTemp = min(nextLength.x, min(nextLength.y, nextLength.z));
                        }
                        prevID *= step(100.0, voxelData1.z);
                    }
                }
                targetNormal = -tracedRay.direction;
            }
            vec3 nextBlock = clamp(1.0 - (nextLength - rayLengthTemp) * 1e+10, vec3(0.0), vec3(1.0));
            voxelIndex += nextBlock;
            nextLength += nextBlock * stepLength;
        }
        vec3 targetLight = vec3(0.0);
        float atmosphereDepth = 1600.0;
        if (hitSky) {
            rayLength = 114514.0;
            #ifdef SHADOW_AND_SKY
                vec3 atmosphere;
                vec3 worldPos = tracedRay.origin - voxelOffset - voxelizationRadius;
                #ifdef VIVECRAFT
                    worldPos += floor(cameraPositionFract + vivecraftShadowCameraOffset);
                #endif
                worldPos.y += voxelOriginY;
                vec4 intersectionData = planetIntersectionData(worldPos, tracedRay.direction);
                vec3 skylightColor = singleAtmosphereScattering(vec3(0.0), worldPos, tracedRay.direction, sunDirection, intersectionData, skyColorUp, 30.0, atmosphere);
                #ifdef CLOUD_IN_GI
                    float cloudDepth;
                    skylightColor = sampleClouds(
                        skylightColor, atmosphere, worldPos, tracedRay.direction, shadowDirection, sunDirection, skyColorUp, intersectionData.xyz, 0.0, cloudDepth
                    ).rgb;
                #endif
                float skyLightFactor = 1.0;
                #ifdef LIGHT_LEAKING_FIX
                    skyLightFactor = clamp(gbufferData.lightmap.y * 10.0, 0.0, 1.0);
                #endif
                targetLight = skylightColor * skyLightFactor;
            #endif
        }
        else {
            float targetSkyLight;
            vec3 targetVoxelPos;
            vec3 targetWorldPos;
            SpecularData specularData = SpecularData(0.0, 0.0, 0.0, 0.0);
            if (sampleCoord.w > -11451.4) {
                singleLight = vec3(0.0);
                ivec2 sampleTexel = ivec2(sampleCoord.st * screenSize);
                targetAlbedo.rgb = texelFetch(colortex0, sampleTexel, 0).rgb;
                vec4 sampleNormalData = texelFetch(colortex1, sampleTexel, 0);
                vec4 sampleGbufferData = texelFetch(colortex2, sampleTexel, 0);
                vec4 unpackedSpecular = vec4(unpack16Bit(sampleGbufferData.g), unpack16Bit(sampleGbufferData.b));
                targetNormal = mat3(gbufferModelViewInverse) * decodeNormal(sampleNormalData.zw);
                specularData = SpecularData(unpackedSpecular.x, unpackedSpecular.y, unpackedSpecular.z, unpackedSpecular.w);
                targetSkyLight = unpack16Bit(sampleGbufferData.r).y;

                vec3 targetViewPos;
                #ifdef LOD
                    if (sampleCoord.z >= 1.0) {
                        targetViewPos = screenToViewPosLod(sampleCoord.st, sampleCoord.w);
                    }
                    else
                #endif
                {
                    targetViewPos = screenToViewPos(sampleCoord.st, sampleCoord.z);
                }
                targetWorldPos = viewToWorldPos(targetViewPos);
                targetVoxelPos = worldToVoxelPos(targetWorldPos);
                rayLength = dot(targetViewPos - viewPosPOM, tracedRay.direction);
            }
            else {
                targetNormal = mix(targetNormal, sampleCoord.xyz, step(rayLength, 0.0));
                #ifdef MC_SPECULAR_MAP
                    specularData = SPECULAR_FORMAT(textureLod(depthtex2, nextLength.xy, 0.0));
                #endif
                #ifndef SPECULAR_EMISSIVE
                    specularData.emissive = 0.0;
                #endif
                #ifdef HARDCODED_EMISSIVE
                    specularData.emissive += step(specularData.emissive, 1e-3) * nextLength.z;
                #endif
                targetSkyLight = voxelData0.w * 255.0 / 128.0 - 32.0 / 128.0;
                targetVoxelPos = tracedRay.origin + tracedRay.direction * (rayLength - 1e-4);
                targetWorldPos = targetVoxelPos - voxelOffset - voxelizationRadius;
                #ifdef VIVECRAFT
                    targetWorldPos += floor(cameraPositionFract + vivecraftShadowCameraOffset);
                #endif
                targetWorldPos.y += voxelOriginY;
            }
            atmosphereDepth = rayLength * (1.0 + RF_GROUND_EXTRA_DENSITY * 3.0 * weatherStrength);
            vec3 irradianceCache = getIrradianceCachePrev(targetVoxelPos + targetNormal * 0.01, targetNormal);
            specularData.emissive *= PI * BLOCK_LIGHT_BRIGHTNESS;
            targetAlbedo.rgb = pow(targetAlbedo.rgb, vec3(2.2));

            targetLight += (irradianceCache + specularData.emissive) * targetAlbedo.rgb;

            #ifdef SHADOW_AND_SKY
                vec3 f0 = vec3(0.04);
                vec3 f82 = vec3(1.0);
                #ifdef LABPBR_F0
                    f0 = mix(f0, vec3(specularData.metalness), step(0.001, specularData.metalness));
                    f82 = hardcodedMetal(specularData.metalness);
                    specularData.metalness = step(229.5 / 255.0, specularData.metalness);
                #endif
                f0 = mix(f0, targetAlbedo.rgb, specularData.metalness);

                float rainWetness = clamp(targetNormal.y * 10.0 + 0.5, 0.0, 1.0) * rainyStrength;
                rainWetness *= clamp(targetSkyLight - 0.9, 0.0, 1.0) * max(10.0 - specularData.porosity * 40.0, 0.0);
                specularData.smoothness += (1.0 - specularData.metalness) * (1.0 - specularData.smoothness) * clamp(rainWetness, 0.0, 1.0);

                float shadowLightFactor = 1.0;
                #ifdef LIGHT_LEAKING_FIX
                    shadowLightFactor = clamp(targetSkyLight * 10.0, 0.0, 1.0);
                #endif
                float NdotL = clamp(dot(targetNormal, shadowDirection), 0.0, 1.0);
                vec3 shadow = vec3(1.0);
                #ifdef CLOUD_SHADOW
                    shadow *= cloudShadow(targetWorldPos, shadowDirection);
                #endif
                vec3 subsurfaceScattering = vec3(float(specularData.porosity > 64.5 / 255.0)) * shadow;
                directShadow(
                    targetWorldPos, targetNormal, NdotL, shadowLightFactor, specularData.smoothness,
                    specularData.porosity, targetSkyLight, 1.0, shadow, subsurfaceScattering
                );
                shadow =
                    (shadow + subsurfaceScattering) * targetAlbedo.rgb * (1.0 - specularData.metalness) + (1.0 + log2(specularData.smoothness + 1.0) * 1.2) *
                    shadow * sunlightSpecular(
                        tracedRay.direction, shadowDirection, targetNormal, log(specularData.smoothness + 1.0), NdotL, dot(-tracedRay.direction, targetNormal), f0, f82
                    );
                targetLight += shadow * sunColor;
            #endif
        }
        singleLight += targetLight * stainedColor;
        #ifdef SHADOW_AND_SKY
            singleLight = solidAtmosphereScattering(singleLight, tracedRay.direction, skyColorUp, atmosphereDepth, gbufferData.lightmap.y);
        #endif
        #ifdef NETHER
            singleLight *= netherFogAbsorption(rayLength);
            singleLight += netherFogScattering(rayLength) * stainedColor;
        #endif
        #ifdef THE_END
            singleLight *= endFogAbsorption(rayLength);
            singleLight += endFogScattering(rayLength) * stainedColor;
        #endif
        totalLight += singleLight;
    }
    return max(totalLight, vec3(0.0)) * 0.1 / GI_SAMPLES;
}

void main() {
    ivec2 texel = ivec2(gl_FragCoord.st);
    texBuffer5 = texelFetch(colortex6, texel, 0);

    GbufferData gbufferData = getGbufferData(texel, texcoord);
    #ifdef LOD
        gbufferData.depth -= (1.0 + getLodDepthSolidDeferred(texcoord)) * float(gbufferData.depth == 1.0);
    #endif

    vec3 pathTraceResult = vec3(0.0);
    float weatherData = texelFetch(colortex4, texel, 0).w;
    vec4 moveData = vec4(vec3(0.0), weatherData);
    if (abs(gbufferData.depth) < 0.999999) {
        moveData.z = gbufferData.materialID / 255.0 + 0.1 / 255.0;
        pathTraceResult = traceGlobalIllumination(texcoord, gbufferData);
    }

    texBuffer0 = moveData;
    texBuffer4 = vec4(pathTraceResult, weatherData);
}

/* DRAWBUFFERS:045 */
