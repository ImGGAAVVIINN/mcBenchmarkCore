#extension GL_ARB_gpu_shader5 : enable
#extension GL_ARB_shading_language_packing : enable

layout(location = 0) out vec4 texBuffer1;
layout(location = 1) out vec4 texBuffer2;
layout(location = 2) out vec4 texBuffer4;
layout(location = 3) out vec4 texBuffer5;

in vec2 texcoord;

#define SCREEN_DATA_COVER

#include "/settings/CloudSettings.glsl"
#include "/settings/GlobalSettings.glsl"
#include "/settings/PathTraceSettings.glsl"

#ifdef SHADOW_AND_SKY
    in vec3 skyColorUp;
#else
    const vec3 skyColorUp = vec3(0.0);
#endif

#include "/libs/Uniform.glsl"
#include "/libs/Common.glsl"
#include "/libs/Atmosphere.glsl"
#include "/libs/Cloud.glsl"
#include "/libs/GbufferData.glsl"
#include "/libs/Shadow.glsl"
#include "/libs/VoxelShape.glsl"
#include "/libs/PathTrace.glsl"
#include "/libs/Parallax.glsl"
#ifdef THE_END
    #include "/libs/Galaxy.glsl"
#endif
#include "/libs/Reflection.glsl"

void main() {
    ivec2 texel = ivec2(gl_FragCoord.st);
    GbufferData gbufferData = getGbufferData(texel, texcoord);

    texBuffer1 = texelFetch(colortex1, texel, 0);

    vec4 reflectionColor = vec4(0.0);
    vec4 diffuseData = texelFetch(colortex5, texel, 0);
    vec3 mirrorColor = diffuseData.rgb;
    vec3 mirrorWeight = vec3(1.0);
    float reflectionDepth = 0.0;

    texBuffer2.w = gbufferData.parallaxOffset;

    #ifdef REFLECTION
        float reflectionWeight = diffuseData.w;
        vec3 f0 = vec3(0.04);
        vec3 f82 = vec3(1.0);
        #ifdef LABPBR_F0
            f0 = mix(f0, vec3(gbufferData.metalness), vec3(clamp(gbufferData.metalness * 1e+10, 0.0, 1.0)));
            f82 = hardcodedMetal(gbufferData.metalness);
            gbufferData.metalness = step(229.5 / 255.0, gbufferData.metalness);
        #endif
        f0 = mix(f0, gbufferData.albedo.rgb, gbufferData.metalness);
        if (reflectionWeight > 1e-3) {
            #ifdef LOD
                gbufferData.depth += float(gbufferData.depth == 1.0) * getLodDepthSolidDeferred(texcoord);
            #endif
            vec3 reflectionNormal;
            reflection(
                gbufferData, f0, f82, reflectionWeight, depthtex0, colortex7, depthtex2,
                reflectionDepth, mirrorColor, reflectionColor, reflectionNormal, mirrorWeight
            );

            mirrorColor = max(mirrorColor, vec3(0.0));
            reflectionDepth = max(reflectionDepth, 0.0);
            reflectionColor = max(reflectionColor, vec4(0.0));

            texBuffer1.rg = encodeNormal(mat3(gbufferModelView) * reflectionNormal);
        }
    #endif

    texBuffer2.rgb = mirrorWeight;
    texBuffer4 = reflectionColor;
    texBuffer5 = vec4(mirrorColor, reflectionDepth);
}

/* DRAWBUFFERS:1245 */
