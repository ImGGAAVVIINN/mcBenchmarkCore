out vec2 texcoord;

#ifdef AVERAGE_EXPOSURE
    out float prevExposure;
#endif

#ifdef SMOOTH_CENTER_DEPTH
    out float smoothCenterDepth;
#endif

#include "/settings/GlobalSettings.glsl"
#include "/libs/Uniform.glsl"

#ifdef SKY_COLOR_UP
    out vec3 skyColorUp;

    #include "/libs/Atmosphere.glsl"
#endif

#ifdef PREV_HAND_ANIMATION
    out vec2 prevHandAnimation;
    out vec2 temporalHandRotation;

    #include "/libs/Common.glsl"
#endif

void main() {
    vec2 offset = vec2(-float(gl_VertexID & 2), float(min(gl_VertexID, 1) << 1)) + vec2(1.0, -1.0);
    #if SR_ENABLE && !defined AFTER_SR
        offset *= renderScale;
    #endif
    texcoord = offset;
    gl_Position = vec4(offset * 2.0 - 1.0, 0.0, 1.0);

    #ifdef AVERAGE_EXPOSURE
        prevExposure = texelFetch(colortex7, ivec2(0), 0).w;
    #endif

    #ifdef SMOOTH_CENTER_DEPTH
        #include "/libs/Materials.glsl"
        vec2 screenCenter = vec2(0.5);
        #if SR_ENABLE
            screenCenter *= renderScale;
        #endif
        float prevCenterDepth = texelFetch(colortex7, ivec2(screenSize - 0.5), 0).w;
        float currCenterDepth = textureLod(DOF_DEPTH_TEXTURE, vec2(screenCenter), 0.0).x;
        #ifdef CORRECT_DOF_HAND_DEPTH
            float materialID = texelFetch(colortex0, ivec2(screenSize * screenCenter), 0).b * 255.0;
            if (abs(materialID - MAT_HAND) < 0.2) {
                currCenterDepth = currCenterDepth / MC_HAND_DEPTH - 0.5 / MC_HAND_DEPTH + 0.5;
            }
        #endif
        float fadeFactor = exp(log(0.5) * frameTime * 10.0 / centerDepthHalflife) * float(prevCenterDepth > 0.0);
        smoothCenterDepth = mix(currCenterDepth, prevCenterDepth, fadeFactor);
    #endif

    #ifdef SKY_COLOR_UP
        vec3 atmosphere;
        skyColorUp = atmosphereScatteringUp(sunDirection.y, 30.0);
    #endif

    #ifdef PREV_HAND_ANIMATION
        float prevHandRotationX = uintBitsToFloat(texelFetch(colortex3, ivec2(1, 0), 0)).w;
        float prevHandRotationY = uintBitsToFloat(texelFetch(colortex3, ivec2(2, 0), 0)).w;
        float currHeadRotationX = atan(gbufferModelView[0].x, -gbufferModelView[2].x);
        float currHeadRotationY = asin(clamp(gbufferModelView[1].z, -1.0, 1.0));
        float blendFactor = exp2(-20.0 * frameTime);
        float currHandRotationX = mix(currHeadRotationX, prevHandRotationX + float(abs(currHeadRotationX - prevHandRotationX) > PI) * signMul(2.0 * PI, currHeadRotationX), blendFactor);
        float currHandRotationY = mix(currHeadRotationY, prevHandRotationY, blendFactor);

        float prevHeadRotationX = atan(gbufferPreviousModelView[0].x, -gbufferPreviousModelView[2].x);
        float prevHeadRotationY = asin(clamp(gbufferPreviousModelView[1].z, -1.0, 1.0));
        prevHandRotationX = prevHeadRotationX - prevHandRotationX - float(abs(prevHeadRotationX - prevHandRotationX) > PI) * signMul(2.0 * PI, prevHeadRotationX);
        prevHandRotationY = prevHeadRotationY - prevHandRotationY;
        temporalHandRotation = mod(vec2(currHandRotationX, currHandRotationY) + PI, 2.0 * PI) - PI;
        currHandRotationX = currHeadRotationX - currHandRotationX;
        currHandRotationY = currHeadRotationY - currHandRotationY;

        float prevHandAnimationX = (prevHandRotationX - currHandRotationX) * 0.1;
        float prevHandAnimationY = (prevHandRotationY - currHandRotationY) * 0.1;
        prevHandAnimation = vec2(prevHandAnimationX, prevHandAnimationY);
    #endif
}
