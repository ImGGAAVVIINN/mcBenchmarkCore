// Common Settings In Path Tracing
    #define PATH_TRACE_GEOMETRY_QUALITY 3 // [0 1 2 3]
    #define QUALITY_CUTOUT_TRACE
    #define VOXELIZATION_HEIGHT_CLAMP

// Global Illumination
    #define GI_SAMPLES 1 // [1 2 3 4 5 6 7 8]
    #define CLOUD_IN_GI

// Relfection
    #define REFLECTION_MAX_STEP 64 // [64 114 256 365 514]
    #define REFLECTION
    // #define FULL_REFLECTION
    #define CLOUD_IN_REFLECTION
    #define SMOOTH_IRRADIANCE_CACHE
    // Screen Space Reflection
        #define SCREEN_SPACE_REFLECTION
        #define SCREEN_SPACE_REFLECTION_STEP 8 // [2 3 4 5 6 7 8 10 12 14 16 20 24 28 32]
        #define SCREEN_SPACE_REFLECTION_REFINEMENTS 4 // [1 2 3 4 5 6 8]
