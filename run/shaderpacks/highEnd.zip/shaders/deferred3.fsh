#version 330 compatibility

#include "/programs/deferred/Deferred3.frag"
