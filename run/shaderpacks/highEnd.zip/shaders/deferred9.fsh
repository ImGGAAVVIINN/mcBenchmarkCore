#version 330 compatibility

#include "/programs/deferred/Deferred9.frag"
