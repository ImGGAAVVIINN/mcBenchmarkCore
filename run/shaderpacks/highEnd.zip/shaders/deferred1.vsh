#version 330 compatibility

#define AFTER_SR
#define PREV_HAND_ANIMATION
#define SKY_COLOR_UP

#include "/programs/common/Common.vert"
