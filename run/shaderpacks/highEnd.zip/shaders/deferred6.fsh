#version 330 compatibility

#include "/programs/deferred/Deferred6.frag"
