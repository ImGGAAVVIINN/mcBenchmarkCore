#version 330 compatibility

#include "/programs/deferred/Deferred4.frag"
