#version 330 compatibility

#include "/programs/deferred/Deferred5.frag"
