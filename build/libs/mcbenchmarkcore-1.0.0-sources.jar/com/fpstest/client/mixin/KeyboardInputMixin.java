package com.fpstest.client.mixin;

import com.fpstest.client.bench.camera.CinematicState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin(class_744.class)
public abstract class KeyboardInputMixin {
    // ClientInput already has getMoveVector(), only need setter accessor for the protected field
    @Accessor("moveVector")
    protected abstract void setMoveVector(class_241 value);

    @Inject(
        method = "tick",
        at = @At("TAIL")
    )
    private void fpstest$lockInput(CallbackInfo ci) {
        if (CinematicState.active) {
            class_744 self = (class_744) (Object) this;
            // Create new Input with all false values (record is immutable)
            self.field_54155 = new class_10185(false, false, false, false, false, false, false);
            // Set moveVector to zero via accessor
            setMoveVector(new class_241(0.0f, 0.0f));
        }
    }
}