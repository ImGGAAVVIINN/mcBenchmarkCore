package com.fpstest.client.mixin;

import com.fpstest.client.bench.camera.CinematicState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_743.class)
public abstract class KeyboardInputMixin {
    @Inject(
        method = "tick",
        at = @At("TAIL")
    )
    private void fpstest$lockInput(CallbackInfo ci) {
        if (CinematicState.active) {
            class_743 self = (class_743) (Object) this;
            // Neutralize movement during cinematic benchmark runs
            self.field_3905 = 0.0f;
            self.field_3907 = 0.0f;
            self.field_54155 = new class_10185(false, false, false, false, false, false, false);
        }
    }
}