package com.fpstest.client.mixin;

import com.fpstest.client.gui.BenchmarkHub;
import com.fpstest.client.gui.I18n;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {

    protected TitleScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(
        method = "init",
        at = @At("TAIL")
    )
    private void fpstest$addBenchmarkButton(CallbackInfo ci) {
        this.fpstest$removeVanillaButtons();
        class_4185 btn = class_4185.method_46430(
                class_2561.method_43470(I18n.tr("fpstest.button.run_benchmark")),
                b -> BenchmarkHub.startFullBenchmark()
        )
        .method_46434(this.field_22789 - 110, 4, 100, 20)
        .method_46431();

        this.method_37063(btn);
    }

    /**
     * Removes the vanilla Singleplayer / Multiplayer / Realms / Accessibility
     * buttons from the title screen. The benchmark title-screen UI (Test FPS,
     * Language, Options, Quit, copyright) is left untouched.
     */
    private void fpstest$removeVanillaButtons() {
        List<class_364> toRemove = new ArrayList<>();
        for (class_364 child : this.method_25396()) {
            if (child instanceof class_339 widget) {
                class_2561 message = widget.method_25369();
                if (message != null && message.method_10851() instanceof class_2588 contents) {
                    String key = contents.method_11022();
                    if ("menu.singleplayer".equals(key)
                            || "menu.multiplayer".equals(key)
                            || "menu.online".equals(key)
                            || "options.accessibility".equals(key)
                            || "accessibility.onboarding.accessibility.button".equals(key)) {
                        toRemove.add(child);
                    }
                }
            }
        }
        for (class_364 child : toRemove) {
            this.method_37066(child);
        }
    }
}