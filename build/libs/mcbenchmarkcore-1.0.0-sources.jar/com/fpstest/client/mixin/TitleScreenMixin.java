package com.fpstest.client.mixin;

import com.fpstest.client.gui.BenchmarkHub;
import com.fpstest.client.gui.I18n;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_7077;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {

    protected TitleScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(
        method = "init",
        at = @At("TAIL")
    )
    private void fpstest$addBenchmarkButton(CallbackInfo ci) {
        this.fpstest$removeVanillaButtons();
        this.fpstest$replaceCopyrightText();
        this.fpstest$addBenchmarkVersionWidget();
        this.fpstest$addRunBenchmarkWidget();
    }

    /**
     * Adds the "Run Benchmark" button as a PlainTextButton at the top-right
     * so FancyMenu can discover and customize it (Button widgets are skipped by FancyMenu).
     */
    private void fpstest$addRunBenchmarkWidget() {
        String buttonText = I18n.tr("fpstest.button.run_benchmark");
        int width = this.field_22793.method_1727(buttonText) + 20; // add padding
        int height = this.field_22793.field_2000 + 4; // add padding
        int x = this.field_22789 - width - 4;
        int y = 4;
        
        class_7077 benchmarkWidget = new class_7077(
            x, y, width, height,
            class_2561.method_43470(buttonText),
            b -> BenchmarkHub.startFullBenchmark(),
            this.field_22793
        );
        this.method_37063(benchmarkWidget);
    }

    /**
     * Replaces the vanilla copyright text with the diagnostic text.
     */
    private void fpstest$replaceCopyrightText() {
        for (class_364 child : this.method_25396()) {
            if (child instanceof class_7077 button) {
                class_2561 message = button.method_25369();
                if (message != null && message.getString().contains("Mojang")) {
                    // Replace the copyright text with our diagnostic text
                    // We need to create a new PlainTextButton with the new text
                    // Since we can't easily modify the existing button's message,
                    // we remove it and add a new one with the same position
                    int y = button.method_46427();
                    int height = button.method_25364();
                    // Calculate width needed for the longer diagnostic text
                    String diagnosticText = "Internal diagnostic tool, provided as-is, no warranty or support!";
                    int width = this.field_22793.method_1727(diagnosticText) + 10; // add some padding
                    // Position from right edge - adjusted right by ~1.5 char widths (9px) to fix left offset without clipping
                    int x = this.field_22789 - width + 9;
                    this.method_37066(button);
                    
                    class_7077 newButton = new class_7077(
                        x, y, width, height,
                        class_2561.method_43470(diagnosticText),
                        b -> {}, // no-op onPress
                        this.field_22793
                    );
                    this.method_37063(newButton);
                    break;
                }
            }
        }
    }

    /**
     * Removes the vanilla Singleplayer / Multiplayer / Realms / Accessibility
     * buttons from the title screen. Also removes the "Create Test World" button
     * that appears in development environments (IS_RUNNING_IN_IDE).
     * The benchmark title-screen UI (Test FPS, Language, Options, Quit, copyright) is left untouched.
     */
    private void fpstest$removeVanillaButtons() {
        List<class_364> toRemove = new ArrayList<>();
        for (class_364 child : this.method_25396()) {
            if (child instanceof class_339 widget) {
                class_2561 message = widget.method_25369();
                if (message != null) {
                    // Check for translation keys (vanilla buttons)
                    if (message.method_10851() instanceof class_2588 contents) {
                        String key = contents.method_11022();
                        if ("menu.singleplayer".equals(key)
                                || "menu.multiplayer".equals(key)
                                || "menu.online".equals(key)
                                || "options.accessibility".equals(key)
                                || "accessibility.onboarding.accessibility.button".equals(key)) {
                            toRemove.add(child);
                        }
                    }
                    // Check for literal "Create Test World" button (vanilla IDE-only button)
                    else if (message.getString().equals("Create Test World")) {
                        toRemove.add(child);
                    }
                }
            }
        }
        for (class_364 child : toRemove) {
            this.method_37066(child);
        }
    }

    /**
     * Adds the "MC Benchmark Core V1.0.0" text as a widget at the bottom-left
     * so FancyMenu can discover and customize it.
     * Position is chosen to avoid overlap with vanilla version text
     * (drawn at y=height-10 by vanilla TitleScreen).
     */
    private void fpstest$addBenchmarkVersionWidget() {
        String benchmarkText = "MC Benchmark Core V1.0.0";
        int width = this.field_22793.method_1727(benchmarkText) + 10; // add some padding
        int height = this.field_22793.field_2000;
        // Position at bottom-left, just above the vanilla version text
        // Vanilla text is at y=height-10, so we place our widget just above it with a small gap
        int x = 2;
        int y = this.field_22790 - height - 12;
        
        class_7077 benchmarkWidget = new class_7077(
            x, y, width, height,
            class_2561.method_43470(benchmarkText),
            b -> {}, // no-op onPress
            this.field_22793
        );
        this.method_37063(benchmarkWidget);
    }
}