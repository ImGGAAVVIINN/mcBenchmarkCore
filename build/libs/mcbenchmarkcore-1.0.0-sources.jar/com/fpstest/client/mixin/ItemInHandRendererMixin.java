package com.fpstest.client.mixin;

import com.fpstest.client.bench.camera.CinematicState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hides the first-person hand/item rendering while a benchmark is running.
 * Without this, the player's hand and held item are drawn over the cinematic view
 * whenever the camera type is FIRST_PERSON.
 */
@Environment(EnvType.CLIENT)
@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {

    @Inject(
        method = "renderHandsWithItems",
        at = @At("HEAD"),
        cancellable = true
    )
    private void fpstest$cancelHandDuringBenchmark(
        float partialTick,
        class_4587 poseStack,
        class_11659 submitNodeCollector,
        class_746 localPlayer,
        int packedLight,
        CallbackInfo ci
    ) {
        if (CinematicState.active) {
            ci.cancel();
        }
    }
}
