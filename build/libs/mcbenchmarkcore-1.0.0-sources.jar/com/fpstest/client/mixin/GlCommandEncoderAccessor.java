package com.fpstest.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10860;
import net.minecraft.class_10866;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import java.util.Collection;

@Environment(EnvType.CLIENT)
@Mixin(class_10860.class)
public interface GlCommandEncoderAccessor {
    @Invoker("trySetup")
    boolean fpstest$trySetup(class_10866 pass, Collection<String> samplers);
}
