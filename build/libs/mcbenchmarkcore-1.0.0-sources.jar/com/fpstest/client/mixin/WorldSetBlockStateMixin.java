package com.fpstest.client.mixin;

import com.fpstest.client.bench.instrumentation.Instr;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_9904;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_1937.class)
public abstract class WorldSetBlockStateMixin {

    @Inject(
        method = "setBlockAndUpdate(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z",
        at = @At("HEAD")
    )
    private void fpstest$countSetState(
        class_2338 pos,
        class_2680 state,
        CallbackInfoReturnable<Boolean> cir
    ) {
        Instr.blockStateChanges.incrementAndGet();
    }

    @Inject(
        method = "updateNeighborsAt",
        at = @At("HEAD")
    )
    private void fpstest$countNeighborUpdate(
        class_2338 pos,
        class_2248 sourceBlock,
        class_9904 orientation,
        CallbackInfo ci
    ) {
        Instr.neighbourUpdates.incrementAndGet();
    }
}