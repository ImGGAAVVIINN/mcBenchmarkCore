package com.fpstest.client.mixin;

import com.fpstest.client.bench.camera.CinematicState;
import com.fpstest.client.bench.camera.Pose;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraMixin {

    @Inject(
        method = "update",
        at = @At("TAIL")
    )
    private void fpstest$cameraSetup(
        net.minecraft.class_1922 level,
        net.minecraft.class_1297 entity,
        boolean detached,
        boolean thirdPerson,
        float partialTick,
        CallbackInfo ci
    ) {
        if (CinematicState.active) {
            Pose pose = CinematicState.currentPose(partialTick);

            if (pose != null) {
                CameraAccessor self = (CameraAccessor) (Object) this;

                self.fpstest$setPosition(
                    pose.pos().method_10216(),
                    pose.pos().method_10214(),
                    pose.pos().method_10215()
                );

                self.fpstest$setRotation(
                    pose.yaw(),
                    pose.pitch()
                );
            }
        }
    }
}
