package com.fpstest.client.mixin;

import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5219;
import net.minecraft.class_5321;
import net.minecraft.class_7659;
import net.minecraft.class_7780;
import net.minecraft.server.MinecraftServer;
import java.util.Map;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftServer.class)
public interface MinecraftServerAccessor {
    @Accessor("worlds")
    Map<class_5321<class_1937>, class_3218> fpstest$getLevels();

    @Accessor("session")
    class_32.class_5143 fpstest$getStorageSource();

    @Accessor("saveProperties")
    class_5219 fpstest$getWorldData();

    @Accessor("combinedDynamicRegistries")
    class_7780<class_7659> fpstest$getRegistries();
}