package com.fpstest.client.gui;

import net.minecraft.class_2561;

public final class I18n {
    private I18n() {
    }

    public static String tr(String key) {
        return key;
    }

    public static class_2561 t(String key) {
        return class_2561.method_43470(tr(key));
    }
}