package com.fpstest.client.gui;

import com.fpstest.client.FpsTestClient;
import com.fpstest.client.bench.BenchmarkRegistry;
import com.fpstest.client.bench.RunPlan;
import com.fpstest.client.gui.I18n;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class BenchmarkHub extends class_437 {
    private final class_437 parent;

    public BenchmarkHub(class_437 parent) {
        super(class_2561.method_43470("FPS Test Benchmark Hub"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        // Run Showcase button - starts the showcase benchmark
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Run Showcase"),
                b -> {
                    BenchmarkRegistry.bootstrap();
                    FpsTestClient.RUNNER.startSingle(
                        RunPlan.fromBench(BenchmarkRegistry.get("idle_baseline").orElseThrow()),
                        () -> {}
                    );
                    this.method_25419();
                })
                .method_46434(centerX - 100, centerY - 30, 200, 20)
                .method_46431());

        // Back button - returns to parent screen
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Back"),
                b -> this.method_25419())
                .method_46434(centerX - 100, centerY + 10, 200, 20)
                .method_46431());
    }

    @Override
    public void method_25394(net.minecraft.class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        
        // Draw title
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 40, 0xFFFFFF);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(this.parent);
    }
}
