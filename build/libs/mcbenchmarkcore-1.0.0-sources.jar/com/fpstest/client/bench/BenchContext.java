package com.fpstest.client.bench;

import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

public final class BenchContext {
    public final class_310 client;
    private final List<UUID> spawned = new ArrayList<>();
    private class_2338 arenaOrigin = class_2338.field_10980;
    private RunPlan plan;

    public BenchContext(class_310 client) {
        this.client = client;
    }

    public RunPlan plan() {
        return plan;
    }

    public void setPlan(RunPlan plan) {
        this.plan = plan;
    }

    public class_746 player() {
        return client.field_1724;
    }

    public class_638 clientLevel() {
        return client.field_1687;
    }

    public MinecraftServer server() {
        return client.method_1576();
    }

    public net.minecraft.class_3222 serverPlayer() {
        MinecraftServer server = server();
        if (server == null) return null;
        if (client.field_1724 == null) return null;
        return server.method_3760().method_14602(client.field_1724.method_5667());
    }

    public net.minecraft.class_1937 serverLevel() {
        net.minecraft.class_3222 serverPlayer = serverPlayer();
        if (serverPlayer != null) {
            return serverPlayer.method_51469();
        }
        MinecraftServer server = server();
        if (server != null) {
            return server.method_30002();
        }
        return null;
    }

    public void onServer(java.util.function.Consumer<MinecraftServer> consumer) {
        MinecraftServer server = server();
        if (server == null) return;

        if (Thread.currentThread() == server.method_3777()) {
            consumer.accept(server);
        } else {
            server.execute(() -> consumer.accept(server));
        }
    }

    public void spawnTracked(net.minecraft.class_1297 entity, net.minecraft.class_1937 world) {
        world.method_8649(entity);
        spawned.add(entity.method_5667());
    }

    public int trackedCount() {
        return spawned.size();
    }

    public void removeTracked() {
        if (spawned.isEmpty()) return;
        MinecraftServer server = server();
        if (server == null) {
            spawned.clear();
            return;
        }
        List<UUID> toRemove = new ArrayList<>(spawned);
        spawned.clear();
        server.execute(() -> drainBatch(server, toRemove, 0));
    }

    private void drainBatch(MinecraftServer server, List<UUID> uuids, int start) {
        net.minecraft.class_3218 world = server.method_30002();
        if (world == null) {
            return;
        }
        if (start < uuids.size()) {
            net.minecraft.class_1297 entity = world.method_66347(uuids.get(start));
                if (entity != null) {
                    entity.method_31472();
                }
            drainBatch(server, uuids, start + 1);
        }
    }

    public void setBlock(net.minecraft.class_1937 world, net.minecraft.class_2338 pos, net.minecraft.class_2680 state) {
        world.method_8652(pos, state, 2);
    }

    public void setArenaOrigin(net.minecraft.class_2338 pos) {
        this.arenaOrigin = pos;
    }

    public net.minecraft.class_2338 arenaOrigin() {
        return arenaOrigin;
    }
}