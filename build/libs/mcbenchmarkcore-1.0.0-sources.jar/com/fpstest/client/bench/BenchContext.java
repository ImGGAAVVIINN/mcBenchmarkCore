package com.fpstest.client.bench;

import com.fpstest.client.bench.camera.CameraPath;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

public final class BenchContext {
    public final class_310 client;
    private final List<UUID> spawned = new ArrayList<>();
    private class_243 arenaOrigin = class_243.field_1353;
    private CameraPath cameraPath;
    private RunPlan plan;

    public BenchContext(class_310 client) {
        this.client = client;
    }

    public RunPlan plan() {
        return plan;
    }

    public void setPlan(RunPlan plan) {
        this.plan = plan;
    }

    public class_746 player() {
        return client.field_1724;
    }

    public class_638 clientLevel() {
        return client.field_1687;
    }

    public MinecraftServer server() {
        return client.method_1576();
    }

    public net.minecraft.class_3222 serverPlayer() {
        MinecraftServer server = server();
        if (server == null) return null;
        if (client.field_1724 == null) return null;
        return server.method_3760().method_14602(client.field_1724.method_5667());
    }

    public net.minecraft.class_3218 serverLevel() {
        net.minecraft.class_3222 serverPlayer = serverPlayer();
        if (serverPlayer != null) {
            return (net.minecraft.class_3218) serverPlayer.method_51469();
        }
        MinecraftServer server = server();
        if (server != null) {
            return server.method_30002();
        }
        return null;
    }

    public void onServer(java.util.function.Consumer<MinecraftServer> consumer) {
        MinecraftServer server = server();
        if (server == null) return;

        if (Thread.currentThread() == server.method_3777()) {
            consumer.accept(server);
        } else {
            server.execute(() -> consumer.accept(server));
        }
    }

    public void spawnTracked(net.minecraft.class_1297 entity, net.minecraft.class_1937 world) {
        world.method_8649(entity);
        spawned.add(entity.method_5667());
    }

    public int trackedCount() {
        return spawned.size();
    }

    public void removeTracked() {
        if (spawned.isEmpty()) return;
        MinecraftServer server = server();
        if (server == null) {
            spawned.clear();
            return;
        }
        List<UUID> toRemove = new ArrayList<>(spawned);
        spawned.clear();
        server.execute(() -> drainBatch(server, toRemove, 0));
    }

    private void drainBatch(MinecraftServer server, List<UUID> uuids, int start) {
        net.minecraft.class_3218 world = server.method_30002();
        if (world == null) {
            return;
        }
        int batch = 50;
        int end = Math.min(start + batch, uuids.size());

        for (int i = start; i < end; i++) {
            try {
                net.minecraft.class_1297 entity = world.method_66347(uuids.get(i));
                if (entity != null) {
                    entity.method_31472();
                }
            } catch (Throwable ignored) {
            }
        }

        if (end < uuids.size()) {
            server.execute(() -> drainBatch(server, uuids, end));
        }
    }

    public void setBlock(net.minecraft.class_1937 world, net.minecraft.class_2338 pos, net.minecraft.class_2680 state) {
        world.method_8652(pos, state, 2);
    }

    public void setArenaOrigin(class_243 origin) {
        this.arenaOrigin = origin;
    }

    public class_243 arenaOrigin() {
        return arenaOrigin;
    }

    public void setCameraPath(CameraPath path) {
        this.cameraPath = path;
        com.fpstest.client.bench.camera.CinematicState.path = path;
        com.fpstest.client.bench.camera.CinematicState.pathTick = 0;
    }
}