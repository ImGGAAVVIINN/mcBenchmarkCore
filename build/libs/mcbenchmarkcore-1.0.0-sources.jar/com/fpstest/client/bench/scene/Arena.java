package com.fpstest.client.bench.scene;

import com.fpstest.client.bench.BenchContext;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.Set;

@Environment(EnvType.CLIENT)
public final class Arena {
    private Arena() {
    }

    public static void teleport(BenchContext ctx, net.minecraft.class_243 pos, float yaw, float pitch) {
        ctx.onServer(server -> {
            class_3222 player = ctx.serverPlayer();
            class_3218 level = (class_3218) ctx.serverLevel();
            if (player != null && level != null) {
                player.method_48105(level, pos.field_1352, pos.field_1351, pos.field_1350, Set.of(), yaw, pitch, true);
                player.method_38785();
                player.method_5875(true);
                player.method_5684(true);
            }
        });
    }

    public static void stoneSlab(class_3218 level, int cx, int cy, int cz, int halfX, int halfZ) {
        fillSlab(level, cx, cy, cz, halfX, halfZ, class_2246.field_10340.method_9564());
    }

    public static void bedrockSlab(class_3218 level, int cx, int cy, int cz, int halfX, int halfZ) {
        fillSlab(level, cx, cy, cz, halfX, halfZ, class_2246.field_9987.method_9564());
    }

    private static void fillSlab(class_3218 level, int cx, int cy, int cz, int halfX, int halfZ, class_2680 block) {
        class_2338.class_2339 pos = new class_2338.class_2339();

        for (int x = -halfX; x <= halfX; x++) {
            for (int z = -halfZ; z <= halfZ; z++) {
                pos.method_10103(cx + x, cy, cz + z);
                level.method_8652(pos, block, 2);
            }
        }
    }

    public static void carveBox(class_3218 level, int cx, int cy, int cz, int halfX, int height, int halfZ) {
        class_2680 air = class_2246.field_10124.method_9564();
        class_2338.class_2339 pos = new class_2338.class_2339();

        for (int y = 1; y <= height; y++) {
            for (int x = -halfX; x <= halfX; x++) {
                for (int z = -halfZ; z <= halfZ; z++) {
                    pos.method_10103(cx + x, cy + y, cz + z);
                    level.method_8652(pos, air, 2);
                }
            }
        }
    }

    public static void freezeDaytime(BenchContext ctx) {
        ctx.onServer(server -> {
            class_3218 level = (class_3218) ctx.serverLevel();
            if (level != null) {
                level.method_29199(6000L);
            }
        });
    }

    public static void freezeMidnight(BenchContext ctx) {
        ctx.onServer(server -> {
            class_3218 level = (class_3218) ctx.serverLevel();
            if (level != null) {
                level.method_29199(18000L);
            }
        });
    }
}