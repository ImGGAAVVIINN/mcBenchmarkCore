package com.fpstest.client.bench.world;

import com.fpstest.client.FpsTestClient;
import com.fpstest.client.bench.WorldType;
import com.fpstest.client.mixin.MinecraftServerAccessor;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1267;
import net.minecraft.class_1928;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_1940;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_1992;
import net.minecraft.class_2246;
import net.minecraft.class_2874;
import net.minecraft.class_2897;
import net.minecraft.class_310;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3229;
import net.minecraft.class_3232;
import net.minecraft.class_3754;
import net.minecraft.class_5218;
import net.minecraft.class_5284;
import net.minecraft.class_5285;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_6880;
import net.minecraft.class_7134;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7712;
import net.minecraft.class_7723;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.function.Function;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public final class EphemeralWorld {
    public static final String LEVEL_ID = "fpstest-arena";
    private static volatile String currentLevelId = "fpstest-arena";
    private static volatile class_5321<class_1937> currentDimensionKey = null;

    private EphemeralWorld() {
    }

    public static String currentLevelId() {
        return currentLevelId;
    }

    public static class_5321<class_1937> currentDimensionKey() {
        return currentDimensionKey;
    }

    public static void create(long seed, WorldType type) {
        class_310 mc = class_310.method_1551();
        String levelId = "fpstest-arena";

        try {
            Path existing = mc.method_1586().method_52238(class_5218.field_24188.method_27423()).resolve("fpstest-arena");
            if (Files.exists(existing)) {
                levelId = "fpstest-arena-" + System.currentTimeMillis() / 1000L;
                FpsTestClient.LOG.warn("[MC Benchmark Core] using fallback arena name: {} (previous save tree still present)", levelId);
            }
        } catch (Exception var9) {
            FpsTestClient.LOG.debug("[MC Benchmark Core] could not probe save dir for fallback name: {}", var9.getMessage());
        }

        currentLevelId = levelId;

        FpsTestClient.LOG.info("[MC Benchmark Core] creating ephemeral world seed={}, type={}, levelId={}", seed, type.kind, levelId);

        // Create game rules for the ephemeral world
        class_1928 rules = new class_1928(class_7699.method_45397());
        rules.method_76186(class_1928.field_19396, false, null);
        rules.method_76186(class_1928.field_19406, false, null);
        rules.method_76186(class_1928.field_19390, false, null);
        rules.method_76186(class_1928.field_19391, false, null);
        rules.method_76186(class_1928.field_19392, false, null);
        rules.method_76186(class_1928.field_19393, false, null);
        rules.method_76186(class_1928.field_56559, 0, null);
        rules.method_76186(class_1928.field_19388, false, null);
        rules.method_76186(class_1928.field_21831, false, null);
        rules.method_76186(class_1928.field_21832, false, null);
        rules.method_76186(class_1928.field_38975, false, null);

        // Create level settings
        class_1940 settings = new class_1940("MC Benchmark Core Arena", class_1934.field_9220, false, class_1267.field_5802, true, rules, class_7712.field_40260);
        class_5285 opts = new class_5285(seed, false, false);

        // Build the WorldDimensions using a function that takes HolderLookup.Provider
        // This matches the reference implementation's approach using WorldOpenFlows.createFreshLevel
        java.util.function.Function<class_7225.class_7874, class_7723> dims = provider -> {
            return buildDimensions(provider, type);
        };

        // Use WorldOpenFlows.createFreshLevel() to properly create the level
        // This replaces the manual ServerLevel construction and insertion into levels map
        mc.method_41735().method_41895(levelId, settings, opts, dims, null);

        FpsTestClient.LOG.info("[MC Benchmark Core] created ephemeral world seed={}, type={}, levelId={}", seed, type.kind, levelId);
    }

    /**
     * Destroys the ephemeral world by removing it from the server's levels map
     * and cleaning up resources. Must be called on the server thread.
     */
    public static void destroy() {
        class_310 mc = class_310.method_1551();
        MinecraftServer server = mc.method_1576();
        if (server == null || currentDimensionKey == null) {
            FpsTestClient.LOG.debug("[MC Benchmark Core] No ephemeral world to destroy");
            return;
        }

        // Remove from levels map
        class_3218 level = ((MinecraftServerAccessor) server).fpstest$getLevels().remove(currentDimensionKey);
        if (level != null) {
            // Close the level resources
            try {
                level.close();
            } catch (IOException e) {
                FpsTestClient.LOG.error("[MC Benchmark Core] Failed to close ephemeral world", e);
            }
            FpsTestClient.LOG.info("[MC Benchmark Core] destroyed ephemeral world dimensionKey={}", currentDimensionKey);
        } else {
            FpsTestClient.LOG.warn("[MC Benchmark Core] Ephemeral world not found in levels map for dimensionKey={}", currentDimensionKey);
        }

        currentDimensionKey = null;
    }

    /**
     * Schedules the destruction of the ephemeral world on the server thread.
     * Use this when calling from the client thread.
     */
    public static void destroyAsync() {
        class_310 mc = class_310.method_1551();
        MinecraftServer server = mc.method_1576();
        if (server == null) {
            return;
        }
        server.execute(EphemeralWorld::destroy);
    }

    private static class_7723 buildDimensions(class_7225.class_7874 provider, WorldType type) {
        class_5363 stem = switch (type.kind) {
            case OVERWORLD -> buildOverworldDimensions(provider);
            case FLAT -> buildFlatDimensions(provider);
            case FIXED_BIOME -> buildFixedBiomeDimensions(provider, type.biome);
        };
        Map<class_5321<class_5363>, class_5363> dimMap = new HashMap<>();
        dimMap.put(class_5363.field_25412, stem);
        return new class_7723(dimMap);
    }

    private static class_5363 buildOverworldDimensions(class_7225.class_7874 provider) {
        // Get the overworld dimension type from BuiltinDimensionTypes
        class_5321<class_2874> overworldDimTypeKey = class_7134.field_37666;
        class_6880<class_2874> dimTypeHolder = provider.method_46762(class_7924.field_41241).method_46747(overworldDimTypeKey);
        
        // Get the overworld noise settings
        class_5321<class_5284> overworldNoiseKey = class_5284.field_26355;
        class_6880<class_5284> noiseSettings = provider.method_46762(class_7924.field_41243).method_46747(overworldNoiseKey);
        
        // Create the chunk generator
        class_3754 generator = new class_3754(
            new class_1992(provider.method_46762(class_7924.field_41236).method_46747(class_1972.field_9451)),
            noiseSettings
        );
        
        return new class_5363(dimTypeHolder, generator);
    }

    private static class_5363 buildFlatDimensions(class_7225.class_7874 provider) {
        class_6880<class_1959> biomeHolder = provider.method_46762(class_7924.field_41236).method_46747(class_1972.field_9451);
        
        // FlatLayerInfo constructor takes (int, Block) not BlockState
        List<class_3229> layers = List.of(
            new class_3229(1, class_2246.field_9987),
            new class_3229(2, class_2246.field_10566),
            new class_3229(1, class_2246.field_10219)
        );
        
        // FlatLevelGeneratorSettings: use withBiomeAndLayers for layers
        // Constructor: (Optional<HolderSet<StructureSet>>, Holder<Biome>, List<Holder<PlacedFeature>>)
        // Method: withBiomeAndLayers(List<FlatLayerInfo>, Optional<HolderSet<StructureSet>>, Holder<Biome>)
        class_3232 flatSettings = new class_3232(
            Optional.empty(),
            biomeHolder,
            List.of()
        ).method_46727(layers, Optional.empty(), biomeHolder);
        
        // FlatLevelSource constructor takes only FlatLevelGeneratorSettings
        class_2897 generator = new class_2897(flatSettings);
        
        // Get the overworld dimension type from BuiltinDimensionTypes
        class_5321<class_2874> overworldDimTypeKey = class_7134.field_37666;
        class_6880<class_2874> dimTypeHolder = provider.method_46762(class_7924.field_41241).method_46747(overworldDimTypeKey);
        
        return new class_5363(dimTypeHolder, generator);
    }

    private static class_5363 buildFixedBiomeDimensions(class_7225.class_7874 provider, class_5321<class_1959> biomeKey) {
        class_6880<class_1959> biomeHolder = provider.method_46762(class_7924.field_41236).method_46747(biomeKey);
        
        // Get the overworld noise settings
        class_5321<class_5284> overworldNoiseKey = class_5284.field_26355;
        class_6880<class_5284> noiseSettings = provider.method_46762(class_7924.field_41243).method_46747(overworldNoiseKey);
        
        class_1992 source = new class_1992(biomeHolder);
        // NoiseGeneratorSettings is a record, use it directly
        class_3754 generator = new class_3754(source, noiseSettings);
        
        // Get the overworld dimension type from BuiltinDimensionTypes
        class_5321<class_2874> overworldDimTypeKey = class_7134.field_37666;
        class_6880<class_2874> dimTypeHolder = provider.method_46762(class_7924.field_41241).method_46747(overworldDimTypeKey);
        
        return new class_5363(dimTypeHolder, generator);
    }

    public static void deleteSaveQuietly() {
        deleteSaveCore(false);
    }

    public static void deleteSaveBlocking() {
        deleteSaveCore(true);
    }

    private static void deleteSaveCore(boolean blocking) {
        class_310 mc = class_310.method_1551();
        class_32 src = mc.method_1586();
        Path saveDir = src.method_52238(class_5218.field_24188.method_27423()).resolve("fpstest-arena");
        if (!Files.exists(saveDir)) {
            FpsTestClient.LOG.debug("[MC Benchmark Core] cleanup: no stale arena directory at {}", saveDir);
        } else {
            try {
                Thread.sleep(200L);
            } catch (InterruptedException var12) {
                Thread.currentThread().interrupt();
                return;
            }

            try {
                class_32.class_5143 access = src.method_27002("fpstest-arena");

                try {
                    try {
                        access.close();
                    } catch (IOException var11) {
                    }
                } catch (Throwable var14) {
                    if (access != null) {
                        try {
                            access.close();
                        } catch (Throwable var10) {
                            var14.addSuppressed(var10);
                        }
                    }

                    throw var14;
                }

                if (access != null) {
                    access.close();
                }
            } catch (Exception var15) {
                FpsTestClient.LOG.info("[MC Benchmark Core] could not open arena session for cleanup ({})", var15.getMessage());
            }

            int maxPasses = blocking ? 3 : 5;
            long passDelayMs = blocking ? 500L : 750L;
            IOException lastError = null;

            for (int pass = 0; pass < maxPasses; pass++) {
                try {
                    Files.walkFileTree(saveDir, new SimpleFileVisitor<Path>() {
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                            deleteWithRetry(file);
                            return FileVisitResult.CONTINUE;
                        }

                        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                            deleteWithRetry(dir);
                            return FileVisitResult.CONTINUE;
                        }
                    });
                    if (!Files.exists(saveDir)) {
                        if (pass > 0) {
                            FpsTestClient.LOG.info("[MC Benchmark Core] cleanup succeeded (pass {})", pass + 1);
                        } else {
                            FpsTestClient.LOG.debug("[MC Benchmark Core] cleanup succeeded (first pass)");
                        }

                        return;
                    }

                    lastError = null;
                } catch (IOException var9) {
                    lastError = var9;
                }

                try {
                    Thread.sleep(passDelayMs);
                } catch (InterruptedException var13) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            if (lastError != null) {
                FpsTestClient.LOG
                    .warn(
                        "[MC Benchmark Core] cleanup deferred: failed to delete arena save tree at {} after {} passes ({}). Next run will use a fallback arena name; full retry on next MC Benchmark Core launch.",
                        new Object[]{saveDir, maxPasses, lastError.getMessage()}
                    );
            } else if (Files.exists(saveDir)) {
                FpsTestClient.LOG
                    .warn(
                        "[MC Benchmark Core] cleanup deferred: arena save tree at {} still present after {} passes. Next run will use a fallback arena name; full retry on next MC Benchmark Core launch.",
                        saveDir,
                        maxPasses
                    );
            }
        }
    }

    public static void cleanupStaleOnStartup() {
        try {
            class_310 mc = class_310.method_1551();
            class_32 src = mc.method_1586();
            Path saveDir = src.method_52238(class_5218.field_24188.method_27423()).resolve("fpstest-arena");
            if (!Files.exists(saveDir)) {
                return;
            }

            FpsTestClient.LOG.info("[MC Benchmark Core] startup cleanup: stale arena save tree found at {}, removing on background thread", saveDir);
            Thread t = new Thread(EphemeralWorld::deleteSaveQuietly, "MC Benchmark Core-arena-startup-cleanup");
            t.setDaemon(true);
            t.start();
        } catch (Throwable var3) {
            FpsTestClient.LOG.warn("[MC Benchmark Core] startup cleanup raised an exception, ignoring: {}", var3.getMessage());
        }
    }

    private static void deleteWithRetry(Path p) throws IOException {
        IOException last = null;

        for (int attempt = 0; attempt < 10; attempt++) {
            try {
                Files.deleteIfExists(p);
                return;
            } catch (IOException var6) {
                last = var6;

                try {
                    Thread.sleep(250L);
                } catch (InterruptedException var5) {
                    Thread.currentThread().interrupt();
                    throw var6;
                }
            }
        }

        if (last != null) {
            throw last;
        }
    }
}