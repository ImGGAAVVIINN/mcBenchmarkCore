package com.fpstest.client.bench;

import com.fpstest.client.FpsTestClient;
import com.fpstest.client.bench.camera.CinematicState;
import com.fpstest.client.bench.world.EphemeralWorld;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_5498;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public final class CinematicRunner {
    private static final Logger LOG = LoggerFactory.getLogger(CinematicRunner.class);

    private final Deque<RunPlan> queue = new ArrayDeque<>();
    private Runnable onFinished;
    private Consumer<String> onProgress;
    private State state = State.IDLE;
    private RunPlan plan;
    private Benchmark current;
    private BenchContext ctx;
    private BenchmarkResult.Builder builder;
    private int phaseTicks;
    private int waitTicks;
    private int preloadedChunks;
    private long preloadStartNanos;
    private long preloadDurationMs;
    private int totalQueued;
    private int completedInQueue;
    private String sessionId;
    private String sessionLabel;
    private long entityCountAtSampleStart;
    private long entityCountAtSampleEnd;
    private final java.util.List<BenchmarkResult> session = new java.util.ArrayList<>();

    public State state() {
        return state;
    }

    public Benchmark current() {
        return current;
    }

    public RunPlan currentPlan() {
        return plan;
    }

    public int phaseTicks() {
        return phaseTicks;
    }

    public int totalQueued() {
        return totalQueued;
    }

    public int completedInQueue() {
        return completedInQueue;
    }

    public int queuedRemaining() {
        return queue.size();
    }

    public String sessionLabel() {
        return sessionLabel;
    }

    public boolean busy() {
        return state != State.IDLE;
    }

    public synchronized boolean startSingle(RunPlan plan, Runnable onFinished) {
        return state != State.IDLE ? false : startQueue(List.of(plan), plan.bench.displayName(), onFinished);
    }

    public synchronized boolean startQueue(List<RunPlan> plans, String label, Runnable onFinished) {
        if (state == State.IDLE && !plans.isEmpty()) {
            resetSession();
            queue.clear();
            queue.addAll(plans);
            totalQueued = plans.size();
            completedInQueue = 0;
            this.onFinished = onFinished;
            sessionLabel = label;
            sessionId = java.time.LocalDateTime.now().toString().replace(':', '-');
            return dequeueNext();
        } else {
            return false;
        }
    }

    public void setProgressListener(Consumer<String> listener) {
        this.onProgress = listener;
    }

    private boolean dequeueNext() {
        RunPlan next = queue.pollFirst();
        if (next == null) {
            finishSession();
            return false;
        } else {
            plan = next;
            current = plan.bench;
            phaseTicks = 0;
            waitTicks = 0;
            preloadedChunks = 0;
            LOG.info("[FPS Test] starting benchmark: {} (preset={})", current.id(), plan.presetName);
            if (onProgress != null) {
                onProgress.accept("Loading " + current.displayName());
            }

            EphemeralWorld.deleteSaveBlocking();

            try {
                EphemeralWorld.create(current.seed(), current.worldType());
            } catch (Throwable var3) {
                LOG.error("[FPS Test] world creation failed", var3);
                abortCurrent("world creation failed: " + var3.getMessage());
                return false;
            }

            state = State.WORLD_LOADING;
            return true;
        }
    }

    public synchronized void abortAll(String reason) {
        LOG.warn("[FPS Test] abort all: {}", reason);
        queue.clear();
        abortCurrent(reason);
    }

    public synchronized void abortCurrentRequested(String reason) {
        if (state != State.IDLE) {
            abortCurrent(reason);
        }
    }

    private void abortCurrent(String reason) {
        LOG.warn("[FPS Test] abort current: {}", reason);
        CinematicState.reset();
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 != null) {
            try {
                mc.field_1687.method_8525(class_2561.method_43470("FPS Test — aborted: " + reason));
            } catch (Throwable ignored) {
            }
            try {
                mc.method_1507(new net.minecraft.class_437(class_2561.method_43470("FPS Test — aborted")) {
                    @Override
                    protected void method_25426() {
                        this.method_37063(class_4185.method_46430(class_2561.method_43470("Back to Title"), b -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(null);
                            }
                        }).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2, 200, 20).method_46431());
                    }
                });
            } catch (Throwable ignored) {
            }
        }
        state = State.POST_RUN;
        waitTicks = 0;
    }

    public void onClientTick(class_310 mc) {
        try {
            tickInternal(mc);
        } catch (Throwable var5) {
            LOG.error("[FPS Test] runner tick failed — aborting current benchmark", var5);
            try {
                abortCurrent("runner tick threw: " + var5.getMessage());
            } catch (Throwable ignored) {
            }
        }
    }

    private void tickInternal(class_310 mc) {
        if (state != State.IDLE) {
            switch (state) {
                case WORLD_LOADING:
                    if (mc.field_1687 != null && mc.field_1724 != null) {
                        state = State.READY_WAIT;
                        waitTicks = 0;
                    }
                    break;
                case READY_WAIT:
                    waitTicks++;
                    if (mc.field_1687 == null || mc.field_1724 == null) {
                        return;
                    }
                    if (mc.field_1724.field_6012 > 20 && waitTicks > 20 && mc.field_1755 != null) {
                        beginPrepare(mc);
                    }
                    break;
                case PREPARING:
                    state = State.CHUNK_PRELOAD;
                    phaseTicks = 0;
                    preloadStartNanos = System.nanoTime();
                    break;
                case CHUNK_PRELOAD:
                    phaseTicks++;
                    CinematicState.pathTick = 0;
                    int ready = countLoadedChunksAroundCamera(mc);
                    preloadedChunks = ready;
                    int target = desiredLoadedChunks();
                    if (ready >= target || phaseTicks >= plan.preloadTicks) {
                        preloadDurationMs = (System.nanoTime() - preloadStartNanos) / 1000000L;
                        state = State.WARMUP;
                        phaseTicks = 0;
                        FpsTestClient.FPS.startRecording(plan.warmupTicks * 50 + 1000);
                        FpsTestClient.TICKS.startRecording(plan.warmupTicks + 20);
                    }
                    break;
                case WARMUP:
                    phaseTicks++;
                    CinematicState.pathTick++;
                    safeTick();
                    if (phaseTicks >= plan.warmupTicks) {
                        FpsTestClient.FPS.stopAndGetSamples();
                        FpsTestClient.TICKS.stopAndGetSamples();
                        FpsTestClient.FPS.startRecording(plan.sampleTicks * 50 + 1000);
                        FpsTestClient.TICKS.startRecording(plan.sampleTicks + 20);
                        FpsTestClient.MEMORY.snapshot();
                        state = State.SAMPLING;
                        phaseTicks = 0;
                    }
                    break;
                case SAMPLING:
                    phaseTicks++;
                    CinematicState.pathTick++;
                    safeTick();
                    if (phaseTicks >= plan.sampleTicks) {
                        finishSampling();
                        state = State.COOLDOWN;
                        phaseTicks = 0;
                        CinematicState.holdPose = true;
                    }
                    break;
                case COOLDOWN:
                    phaseTicks++;
                    if (phaseTicks >= plan.cooldownTicks) {
                        try {
                            current.cleanup(ctx);
                        } catch (Throwable ignored) {
                        }
                        ctx.removeTracked();
                        disconnectWorld(mc);
                    }
                    break;
                case DISCONNECTING:
                    waitTicks++;
                    if (mc.field_1687 == null || waitTicks > 100) {
                        state = State.POST_RUN;
                        waitTicks = 0;
                    }
                    break;
                case POST_RUN:
                    waitTicks++;
                    if (waitTicks > 8) {
                        completedInQueue++;
                        EphemeralWorld.deleteSaveQuietly();
                        if (queue.isEmpty()) {
                            finishSession();
                        } else {
                            dequeueNext();
                        }
                    }
            }
        }
    }

    private int desiredLoadedChunks() {
        return 48;
    }

    private int countLoadedChunksAroundCamera(class_310 mc) {
        if (mc.field_1687 == null) {
            return 0;
        }
        com.fpstest.client.bench.camera.Pose pose = CinematicState.currentPose(0.0F);
        class_243 pos = pose != null ? pose.pos() : (mc.field_1724 != null ? mc.field_1724.method_73189() : class_243.field_1353);
        int cx = (int) Math.floor(pos.field_1352) >> 4;
        int cz = (int) Math.floor(pos.field_1350) >> 4;
        int loaded = 0;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (mc.field_1687.method_8477(new net.minecraft.class_2338((cx + dx) << 4, 0, (cz + dz) << 4))) {
                    loaded++;
                }
            }
        }
        return loaded;
    }

    private void safeTick() {
        try {
            current.tick(ctx);
        } catch (Throwable var2) {
            LOG.warn("[FPS Test] tick failed for {}", current.id(), var2);
        }
    }

    private void finishSampling() {
        double[] frames = FpsTestClient.FPS.stopAndGetSamples();
        double[] ticks = FpsTestClient.TICKS.stopAndGetSamples();
        double[] fpsSamples = new double[frames.length];
        for (int i = 0; i < frames.length; i++) {
            fpsSamples[i] = frames[i] > 0.0 ? 1000.0 / frames[i] : 0.0;
        }
        double meanFrameMs = 0.0;
        if (frames.length > 0) {
            double sum = 0.0;
            for (double f : frames) {
                sum += f;
            }
            meanFrameMs = sum / frames.length;
        }
        double harmonicFps = meanFrameMs > 0.0 ? 1000.0 / meanFrameMs : 0.0;
        builder
            .sampleTicks(plan.sampleTicks)
            .frameTimes(frames)
            .tickTimes(ticks)
            .fps(com.fpstest.client.metrics.Stats.of(fpsSamples))
            .frameTimeMs(com.fpstest.client.metrics.Stats.of(frames))
            .tickTimeMs(com.fpstest.client.metrics.Stats.of(ticks))
            .heap(FpsTestClient.MEMORY.snapshotHeap(), FpsTestClient.MEMORY.usedBytes(), FpsTestClient.MEMORY.peakBytesSinceSnapshot())
            .gc(FpsTestClient.MEMORY.gcEventsSinceSnapshot(), FpsTestClient.MEMORY.gcTimeMsSinceSnapshot())
            .extra("fps_1pct_low", com.fpstest.client.metrics.Stats.lowPercentFps(frames, 0.01))
            .extra("fps_0p1pct_low", com.fpstest.client.metrics.Stats.lowPercentFps(frames, 0.001))
            .extra("fps_harmonic_avg", harmonicFps)
            .extra("seed", (double) current.seed())
            .extra("preload_chunks", (double) preloadedChunks)
            .extra("preload_duration_ms", (double) preloadDurationMs)
            .extra("entity_count_sample_start", (double) entityCountAtSampleStart)
            .extra("entity_count_sample_end", (double) entityCountAtSampleEnd)
            .extra("entity_count_delta", (double) (entityCountAtSampleEnd - entityCountAtSampleStart))
            .extra("preset_quick", "quick".equals(plan.presetName) ? 1.0 : 0.0)
            .extra("preset_full", "full".equals(plan.presetName) ? 1.0 : 0.0)
            .extra("preset_long", "long".equals(plan.presetName) ? 1.0 : 0.0);

        try {
            current.recordExtra(ctx, builder);
        } catch (Throwable var13) {
            LOG.warn("[FPS Test] recordExtra failed for {}", current.id(), var13);
        }

        BenchmarkResult r = builder.build();
        session.add(r);
        LOG.info(
            "[FPS Test] {} done — avg {} fps, 1%low {} fps, tick {} ms",
            current.id(), (int) r.fps().avg(), (int) com.fpstest.client.metrics.Stats.lowPercentFps(r.frameTimesMs(), 0.01), (int) r.tickTimeMs().avg()
        );
    }

    private void disconnectWorld(class_310 mc) {
        mc.method_1507(new net.minecraft.class_437(class_2561.method_43470("FPS Test — finishing " + current.displayName() + "…")) {
            @Override
            protected void method_25426() {
                this.method_37063(class_4185.method_46430(class_2561.method_43470("Back to Title"), b -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(null);
                    }
                }).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2, 200, 20).method_46431());
            }
        });
        CinematicState.holdPose = false;
        CinematicState.active = false;
        CinematicState.path = null;
        try {
            if (mc.field_1687 != null) {
                mc.field_1687.method_8525(class_2561.method_43470("FPS Test — finished"));
            }
            mc.method_1507(new net.minecraft.class_437(class_2561.method_43470("FPS Test")) {
                @Override
                protected void method_25426() {
                    this.method_37063(class_4185.method_46430(class_2561.method_43470("Back to Title"), b -> {
                        if (this.field_22787 != null) {
                            this.field_22787.method_1507(null);
                        }
                    }).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2, 200, 20).method_46431());
                }
            });
        } catch (Throwable var3) {
            LOG.warn("[FPS Test] disconnect failed", var3);
        }
        state = State.DISCONNECTING;
        waitTicks = 0;
    }

    private void finishSession() {
        class_310 mc = class_310.method_1551();
        state = State.IDLE;
        current = null;
        plan = null;
        phaseTicks = 0;
        waitTicks = 0;
        Runnable cb = onFinished;
        onFinished = null;
        mc.execute(() -> {
            if (cb != null) {
                cb.run();
            } else {
                mc.method_1507(null);
            }
        });
    }

    private void beginPrepare(class_310 mc) {
        ctx = new BenchContext(mc);
        ctx.setPlan(plan);
        builder = new BenchmarkResult.Builder(current.id(), current.displayName(), current.category());
        CinematicState.reset();
        CinematicState.active = true;
        CinematicState.holdPose = false;
        try {
            mc.field_1690.method_31043(class_5498.field_26664);
        } catch (Throwable ignored) {
        }
        try {
            current.prepare(ctx);
        } catch (Throwable t) {
            LOG.error("[FPS Test] prepare failed for {}", current.id(), t);
            abortCurrent("prepare failed: " + t.getMessage());
            return;
        }
        state = State.PREPARING;
    }

    private void resetSession() {
        sessionId = null;
        sessionLabel = null;
        totalQueued = 0;
        completedInQueue = 0;
    }

    @Environment(EnvType.CLIENT)
    public enum State {
        IDLE,
        WORLD_LOADING,
        READY_WAIT,
        PREPARING,
        CHUNK_PRELOAD,
        WARMUP,
        SAMPLING,
        COOLDOWN,
        DISCONNECTING,
        POST_RUN
    }
}