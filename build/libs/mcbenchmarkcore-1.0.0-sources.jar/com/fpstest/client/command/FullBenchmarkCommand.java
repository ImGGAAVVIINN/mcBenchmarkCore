package com.fpstest.client.command;

import com.fpstest.client.FpsTestClient;
import com.fpstest.client.gui.BenchmarkHub;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2561;

/**
 * Command to trigger the FULL BENCHMARK suite from in-game.
 * Usage: /fpstest fullbenchmark
 */
public class FullBenchmarkCommand {
    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("fpstest")
                .then(ClientCommandManager.literal("fullbenchmark")
                    .executes(FullBenchmarkCommand::runFullBenchmark))
            );
        });
    }

    private static int runFullBenchmark(CommandContext<FabricClientCommandSource> context) {
        FabricClientCommandSource source = context.getSource();
        if (FpsTestClient.RUNNER.busy()) {
            source.sendError(class_2561.method_43470("[MC Benchmark Core] Benchmark already running!"));
            return 0;
        }
        
        source.sendFeedback(class_2561.method_43470("[MC Benchmark Core] Starting FULL BENCHMARK suite..."));
        boolean started = BenchmarkHub.startFullBenchmark();
        
        if (started) {
            source.sendFeedback(class_2561.method_43470("[MC Benchmark Core] FULL BENCHMARK started successfully."));
        } else {
            source.sendError(class_2561.method_43470("[MC Benchmark Core] Failed to start FULL BENCHMARK."));
        }
        
        return started ? 1 : 0;
    }
}
