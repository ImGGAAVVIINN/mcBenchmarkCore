package com.fpstest.client.command;

import com.fpstest.client.FpsTestClient;
import com.fpstest.client.bench.WorldType;
import com.fpstest.client.bench.world.EphemeralWorld;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_1132;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5454;

public class EphemeralWorldCommand {
    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("fpstest")
                .then(ClientCommandManager.literal("ephemeral")
                    .then(ClientCommandManager.literal("create")
                        .executes(EphemeralWorldCommand::create))
                    .then(ClientCommandManager.literal("destroy")
                        .executes(EphemeralWorldCommand::destroy))
                    .then(ClientCommandManager.literal("enter")
                        .executes(EphemeralWorldCommand::enter))
                )
            );
        });
    }

    private static int create(CommandContext<FabricClientCommandSource> context) {
        // Cast to FabricClientCommandSource to access client-specific methods
        FabricClientCommandSource source = (FabricClientCommandSource) context.getSource();
        
        // Check if we have an integrated server (singleplayer)
        class_310 minecraft = source.getClient();
        if (minecraft == null || minecraft.method_1576() == null) {
            source.sendError(class_2561.method_43470("[MinecraftClient Benchmark Core] No integrated server running. Please load a singleplayer world first."));
            return 0;
        }
        
        // Create the ephemeral world with a deterministic test seed
        // This uses the normal singleplayer world creation flow
        long testSeed = 12345L;
        EphemeralWorld.create(testSeed, WorldType.OVERWORLD);
        
        source.sendFeedback(class_2561.method_43470("[MinecraftClient Benchmark Core] Ephemeral world created with seed " + testSeed + ". The client will now load the new world."));
        return 1;
    }

    private static int destroy(CommandContext<FabricClientCommandSource> context) {
        // Cast to FabricClientCommandSource to access client-specific methods
        FabricClientCommandSource source = (FabricClientCommandSource) context.getSource();
        
        // Check if we have an integrated server (singleplayer)
        class_310 minecraft = source.getClient();
        if (minecraft == null || minecraft.method_1576() == null) {
            source.sendError(class_2561.method_43470("[MinecraftClient Benchmark Core] No integrated server running. Please load a singleplayer world first."));
            return 0;
        }
        
        // Destroy the ephemeral world (deletes the save directory)
        EphemeralWorld.destroy();
        
        source.sendFeedback(class_2561.method_43470("[MinecraftClient Benchmark Core] Ephemeral world destroyed."));
        return 1;
    }

    private static int enter(CommandContext<FabricClientCommandSource> context) {
        // Cast to FabricClientCommandSource to access client-specific methods
        FabricClientCommandSource source = (FabricClientCommandSource) context.getSource();
        
        // Check if we have an integrated server (singleplayer)
        class_310 minecraft = source.getClient();
        if (minecraft == null || minecraft.method_1576() == null) {
            source.sendError(class_2561.method_43470("[MinecraftClient Benchmark Core] No integrated server running. Please load a singleplayer world first."));
            return 0;
        }
        
        class_1132 server = minecraft.method_1576();
        
        // Get the local player (client-side) to find the corresponding server-side player
        net.minecraft.class_746 localPlayer = source.getPlayer();
        if (localPlayer == null) {
            source.sendError(class_2561.method_43470("[MinecraftClient Benchmark Core] No local player found."));
            return 0;
        }
        
        // Get the server-side player from the integrated server using the local player's UUID
        class_3222 player = server.method_3760().method_14602(localPlayer.method_5667());
        if (player == null) {
            source.sendError(class_2561.method_43470("[MinecraftClient Benchmark Core] No server-side player found for local player."));
            return 0;
        }
        
        // Get the overworld dimension (the ephemeral world is the current singleplayer world)
        class_3218 overworld = server.method_3847(class_1937.field_25179);
        if (overworld == null) {
            source.sendError(class_2561.method_43470("[MinecraftClient Benchmark Core] Overworld not found in server."));
            return 0;
        }
        
        // Create TeleportTarget to move player to overworld at 0, 100, 0
        class_243 targetPos = new class_243(0, 100, 0);
        class_243 deltaMovement = class_243.field_1353;
        class_5454 transition = new class_5454(
            overworld,
            targetPos,
            deltaMovement,
            0.0f, // yRot
            0.0f, // xRot
            class_5454.field_52245
        );
        
        // Attempt to teleport the player
        boolean teleportResult = false;
        try {
            player.method_61275(transition);
            teleportResult = true;
        } catch (Exception e) {
            FpsTestClient.LOG.error("[MinecraftClient Benchmark Core] Teleport failed with exception", e);
        }
        
        source.sendFeedback(class_2561.method_43470("[MinecraftClient Benchmark Core] Attempted to teleport to overworld at 0, 100, 0. Teleport call success: " + teleportResult));
        return 1;
    }
}