package com.fpstest.client.control;

import net.minecraft.class_304;
import net.minecraft.class_310;

public class KeyboardInput {
    private static final class_310 mc = class_310.method_1551();

    public static boolean isKeyDown(class_304 key) {
        return key.method_1434();
    }

    public static boolean isKeyPressed(class_304 key) {
        return key.method_1436();
    }

    public static double getMouseX() {
        return mc.field_1729.method_1603();
    }

    public static double getMouseY() {
        return mc.field_1729.method_1604();
    }

    // Mouse delta tracking (Minecraft 1.21.11 doesn't expose getXVelocity/getYVelocity)
    private static double lastMouseX = 0;
    private static double lastMouseY = 0;
    private static boolean firstFrame = true;

    public static double getMouseDeltaX() {
        double currentX = mc.field_1729.method_1603();
        double delta = firstFrame ? 0 : currentX - lastMouseX;
        lastMouseX = currentX;
        firstFrame = false;
        return delta;
    }

    public static double getMouseDeltaY() {
        double currentY = mc.field_1729.method_1604();
        double delta = firstFrame ? 0 : currentY - lastMouseY;
        lastMouseY = currentY;
        return delta;
    }
}