package com.dgm.mcbc.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

public class PingCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(class_2170.method_9247("ping")
            .executes(PingCommand::execute));
    }

    private static int execute(CommandContext<class_2168> context) {
        context.getSource().method_9226(() -> class_2561.method_43470("Pong!"), false);
        return 1;
    }
}