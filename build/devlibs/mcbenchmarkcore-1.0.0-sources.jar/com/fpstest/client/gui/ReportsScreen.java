package com.fpstest.client.gui;

import com.fpstest.client.bench.BenchmarkResult;
import com.fpstest.client.report.ReportReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.MessageScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.client.gui.tooltip.Tooltip;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public final class ReportsScreen extends Screen {
    private static final Logger LOG = LoggerFactory.getLogger("mcbenchmarkcore-reports-screen");
    private final Screen parent;
    private final Set<String> selected = new LinkedHashSet<>();
    private List<Path> sessions = List.of();
    private int scroll = 0;

    public ReportsScreen(Screen parent) {
        super(I18n.t("fpstest.reports.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.sessions = listSessions();
        this.rebuild();
    }

    private void rebuild() {
        this.clearChildren();
        int pad = 8;
        int top = 30;
        int rowH = 22;
        int rowsAvail = Math.max(1, (this.height - top - 60) / rowH);
        int max = Math.max(0, this.sessions.size() - rowsAvail);
        if (this.scroll > max) {
            this.scroll = max;
        }

        this.addDrawableChild(
            FlatButton.flatBuilder(I18n.t("fpstest.reports.open_root"), b -> openRootInOs())
                .dimensions(this.width - 330, 4, 100, 20)
                .tooltip(Tooltip.of(I18n.t("fpstest.reports.open_root.tooltip")))
                .build()
        );
        FlatButton compareBtn = FlatButton.flatBuilder(I18n.t("fpstest.reports.compare"), b -> this.doCompare())
            .dimensions(this.width - 220, 4, 100, 20)
            .tooltip(Tooltip.of(this.selected.size() == 2 ? I18n.t("fpstest.reports.compare_pick") : I18n.t("fpstest.reports.compare_pick_hint")))
            .build();
        compareBtn.active = this.selected.size() == 2;
        this.addDrawableChild(compareBtn);
        this.addDrawableChild(
            FlatButton.flatBuilder(I18n.t("fpstest.settings.back"), b -> this.close()).dimensions(this.width - 110, 4, 100, 20).build()
        );
        if (this.sessions.isEmpty()) {
            this.addDrawable((ctx, mx, my, dt) -> ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(I18n.tr("fpstest.reports.empty")), this.width / 2, this.height / 2, -5592406));
        } else {
            for (int i = 0; i < Math.min(rowsAvail, this.sessions.size() - this.scroll); i++) {
                Path p = this.sessions.get(this.scroll + i);
                String name = p.getFileName().toString();
                int rowY = top + i * rowH;
                String btnLbl = (this.selected.contains(name) ? "\u00a7l[ \u2713 ] " : "[   ] ") + name;
                this.addDrawableChild(
                    FlatButton.flatBuilder(Text.literal(btnLbl), b -> this.toggleSelection(name))
                        .dimensions(pad, rowY, this.width - 254, 20)
                        .build()
                );
                this.addDrawableChild(
                    FlatButton.flatBuilder(I18n.t("fpstest.reports.open"), b -> openInOs(p)).dimensions(this.width - 220, rowY, 70, 20).build()
                );
                this.addDrawableChild(
                    FlatButton.flatBuilder(I18n.t("fpstest.reports.results"), b -> this.openResults(p)).dimensions(this.width - 145, rowY, 100, 20).accent(-7686401).build()
                );
            }
        }
    }

    private void toggleSelection(String name) {
        if (this.selected.contains(name)) {
            this.selected.remove(name);
        } else {
            if (this.selected.size() >= 2) {
                String oldest = this.selected.iterator().next();
                this.selected.remove(oldest);
            }

            this.selected.add(name);
        }

        this.rebuild();
    }

    private void doCompare() {
        if (this.selected.size() == 2) {
            List<Path> picks = new ArrayList<>();

            for (String name : this.selected) {
                for (Path p : this.sessions) {
                    if (p.getFileName().toString().equals(name)) {
                        picks.add(p);
                    }
                }
            }

            if (picks.size() == 2) {
                try {
                    Path out = ReportComparator.compare(picks.get(0), picks.get(1));
                    this.client.setScreen(new MessageScreen(Text.literal(String.format(I18n.tr("fpstest.reports.compare_done"), out.toString()))));
                    new Thread(() -> {
                        try {
                            Thread.sleep(1200L);
                        } catch (InterruptedException var2) {
                        }

                        this.client.execute(() -> this.client.setScreen(new ReportsScreen(this.parent)));
                    }, "mcbenchmarkcore-reports-compare-bounce").start();
                } catch (Throwable var6) {
                    LOG.error("[MinecraftClient Benchmark Core] compare failed", var6);
                }
            }
        }
    }

    private static void openInOs(Path p) {
        try {
            Files.createDirectories(p);
        } catch (IOException var2) {
        }

        try {
            java.awt.Desktop.getDesktop().open(p.toFile());
        } catch (IOException e) {
        }
    }

    private void openResults(Path p) {
        try {
            List<BenchmarkResult> results = ReportReader.read(p);
            if (results.isEmpty()) {
                LOG.warn("[MinecraftClient Benchmark Core] no results in {}", p);
                this.client.setScreen(new MessageScreen(Text.literal(I18n.tr("fpstest.reports.no_results"))));
                return;
            }
            String name = p.getFileName().toString();
            this.client.setScreen(new BenchmarkResultsScreen(results, p, name, "", this::close));
        } catch (Throwable t) {
            LOG.error("[MinecraftClient Benchmark Core] failed to load results from {}", p, t);
            this.client.setScreen(new MessageScreen(Text.literal(String.format(I18n.tr("fpstest.reports.load_failed"), t.getMessage()))));
        }
    }

    private static void openRootInOs() {
        Path root = MinecraftClient.getInstance().runDirectory.toPath().resolve("fpstest-reports");

        try {
            Files.createDirectories(root);
        } catch (IOException var2) {
        }

        try {
            java.awt.Desktop.getDesktop().open(root.toFile());
        } catch (IOException e) {
        }
    }

    private static List<Path> listSessions() {
        Path root = MinecraftClient.getInstance().runDirectory.toPath().resolve("fpstest-reports");
        if (!Files.isDirectory(root)) {
            return List.of();
        } else {
            try {
                List<Path> var2;
                try (Stream<Path> stream = Files.list(root)) {
                    var2 = stream.filter(x$0 -> Files.isDirectory(x$0)).sorted(Comparator.<Path, Instant>comparing(p -> {
                        try {
                            return Files.getLastModifiedTime(p).toInstant();
                        } catch (IOException var2x) {
                            return Instant.EPOCH;
                        }
                    }).reversed()).toList();
                }

                return var2;
            } catch (IOException var6) {
                LOG.warn("[MinecraftClient Benchmark Core] listSessions failed", var6);
                return List.of();
            }
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        if (deltaY < 0.0) {
            this.scroll++;
        } else if (deltaY > 0.0) {
            this.scroll = Math.max(0, this.scroll - 1);
        }

        this.rebuild();
        return true;
    }

    @Override
    public void close() {
        this.client.setScreen(this.parent);
        super.close();
    }

    @Override
    public void render(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }
}